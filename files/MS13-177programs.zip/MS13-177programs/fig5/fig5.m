% fig5.m
%
% This m-file plots Figure 5 in the paper.
% bmrtm.mod and bmeb.mod should be in the same folder.
% Figures are stored in the folder [HOME]/Figures.
%
% October 2014, Takeki Sunakawa

clear all;

cd ./eta/
dynare bmrtm.mod;
dynare bmeb.mod
cd ../bw/
dynare bmrtm.mod;
dynare bmeb.mod
cd ../

load ./eta/bmebpvec_eta;
bveceb_eta = bvec;
pveceb_eta = pvec;

load ./eta/bmrtmpvec_eta;
bvecrtm_eta = bvec;
pvecrtm_eta = pvec;

figure;

subplot(121);
plot(bvecrtm_eta,pvecrtm_eta,'r-','LineWidth',2.0);
hold on;
plot(bveceb_eta,pveceb_eta,'b--','LineWidth',2.0);
xlim([bveceb_eta(1) bveceb_eta(end)]);
legend('RTM, \gamma_w=0','EB, \gamma_w=0','Location','NorthEast');
legend('RTM','EB','Location','NorthEast');
xlabel('\eta');
ylabel('\sigma (\pi)');
ylim([0 0.12]);

load ./bw/bmebpvec_bw;
bveceb_bw = bvec;
pveceb_bw = pvec;

load ./bw/bmrtmpvec_bw;
bvecrtm_bw = bvec;
pvecrtm_bw = pvec;

subplot(122);
plot(bvecrtm_bw,pvecrtm_bw,'r-','LineWidth',2.0);
hold on;
plot(bveceb_bw,pveceb_bw,'b--','LineWidth',2.0);
xlim([bveceb_bw(1) bveceb_bw(end)]);
xlabel('b_w');
ylim([0 0.12]);

print -depsc2 ../Figures/MS13-177Fig5.eps