function [residual, g1, g2] = bmeb_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                    columns: equations in order of declaration
%                                                    rows: variables in declaration order
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: equations in order of declaration
%                                                       rows: variables in declaration order
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 39, 1);

%
% Model equations
%

T13 = params(18)^(-1);
T123 = (-(exp(y(4))*params(14)*exp(y(6)*(1+params(3)))/(1+params(3))))+y(39)*(-exp(y(4)+y(6)))+y(28)*(-exp(y(4)+y(15)+y(6)*params(9)))+y(27)*params(13)*(-exp(y(4)))+exp(y(4))*y(23)+params(18)*y(21)*(1-params(4))*exp(y(4))+params(18)*y(23)*(-((1-params(4))*exp(y(4))));
T154 = (-(exp(y(8))*(1-params(8))*(-(params(8)/(params(8)-1)*exp(y(5))))));
T155 = y(29)*T154;
T158 = y(32)*(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))))+exp(y(5)+y(16)-y(17))*y(31)+y(30)*(-exp(y(6)*params(9)+y(15)+y(5)))+T155;
T163 = (-(exp(y(4))*params(14)*(1+params(3))*exp(y(6)*(1+params(3)))/(1+params(3))));
T188 = params(14)/(1+params(3));
T195 = exp(y(6)+y(10))-(params(10)*params(9)*exp(y(6)*params(9)+y(15)+y(5))+(1-params(10))*T188*(1+params(3))*exp(y(6)*(1+params(3))+params(2)*y(7)));
T284 = exp(y(8))*(1-params(8))*(1+params(17)-params(8)/(params(8)-1)*exp(y(5)));
T356 = exp(y(14))*(exp(y(14))-1)*params(7)+exp(y(14))*exp(y(14))*params(7);
T362 = (-(params(7)/2*exp(y(14))*2*(exp(y(14))-1)));
T370 = exp(y(14))*(exp(y(14))-1)*params(1)*params(7)+exp(y(14))*exp(y(14))*params(1)*params(7);
T381 = y(32)*(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))))+y(28)*(-exp(y(4)+y(15)+y(6)*params(9)))+y(30)*(-exp(y(6)*params(9)+y(15)+y(5)));
T563 = y(35)*(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))))+y(32)*(-(params(10)*params(9)*exp(y(6)*params(9)+y(15)+y(5))))+y(28)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))))+y(30)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))));
residual(1) = exp(y(1))*y(22)+T13*y(32)*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)));
residual(2) = y(27)*(-(params(6)*exp(y(2))))+y(26)*(-(params(12)*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))))+exp(y(11)-y(2))*y(25)+y(22)*(-exp(y(2)-y(3)));
residual(3) = y(26)*(-(params(12)*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))))+exp(y(11)-y(3))*y(24)+y(22)*exp(y(2)-y(3))+exp(y(3))*y(21);
residual(4) = T123;
residual(5) = T158;
residual(6) = T163+y(39)*(-exp(y(4)+y(6)))+y(36)*(-(params(14)*params(3)*exp(params(2)*y(7)+y(6)*params(3))))+y(35)*(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))))+y(32)*T195+y(30)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))))+y(28)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
residual(7) = (1-params(2))*exp(y(7)*(1-params(2)))/(1-params(2))+y(36)*(-(params(14)*params(2)*exp(params(2)*y(7)+y(6)*params(3))))+y(32)*(-((1-params(10))*T188*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))+exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)*params(2)))+y(30)*(-(exp((-y(13)))*params(6)*params(2)*(1-params(4))*params(1)))+y(29)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*params(2)))+y(27)*(-exp(y(7)))+T13*y(29)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*(-params(2))))+T13*y(30)*(-(exp((-y(13)))*params(6)*(-params(2))*(1-params(4))*params(1)))+T13*y(32)*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)*(-params(2))));
residual(8) = y(29)*(-T284)+y(28)*exp(y(8))+y(27)*exp(y(8));
residual(9) = y(38)*(-exp(y(9)-y(17)))+exp(y(16)-y(9))*y(37)+exp(y(9))*y(33)+y(30)*exp(y(6)+y(9))+params(18)*y(33)*(-(exp(y(9))*params(11)));
residual(10) = y(33)*(-((1-params(11))*exp(y(10))))+y(32)*exp(y(6)+y(10));
residual(11) = y(26)*exp(y(11))+y(25)*(-exp(y(11)-y(2)))+y(24)*(-exp(y(11)-y(3)))+y(23)*(-exp(y(11)));
residual(12) = y(24)*exp(y(12));
residual(13) = y(30)*params(6)*(-exp((-y(13))))+y(25)*exp(y(13))+T13*y(30)*(-((-exp((-y(13))))*params(6)*(1-params(4))*params(1)));
residual(14) = y(29)*T356+y(27)*T362+T13*y(29)*(-T370);
residual(15) = y(35)*(-(params(9)*exp(y(15)+y(6)*(params(9)-1))))+y(34)+T381+params(18)*y(34)*(-params(15));
residual(16) = y(37)*(-exp(y(16)-y(9)))+exp(y(5)+y(16)-y(17))*y(31)+y(35)*exp(y(16));
residual(17) = y(38)*exp(y(9)-y(17))+y(36)*exp(y(17))+y(31)*(-exp(y(5)+y(16)-y(17)));
residual(18) = y(37)*exp(y(18));
residual(19) = y(38)*exp(y(19));
residual(20) = y(39)*exp(y(20));
residual(21) = exp(y(3))-(1-(1-params(4))*exp(y(4)));
residual(22) = exp(y(1))-exp(y(2)-y(3));
residual(23) = exp(y(4))-((1-params(4))*exp(y(4))+exp(y(11)));
residual(24) = exp(y(12))-exp(y(11)-y(3));
residual(25) = exp(y(13))-exp(y(11)-y(2));
residual(26) = exp(y(11))-params(12)*exp(params(5)*y(3)+y(2)*(1-params(5)));
residual(27) = exp(y(8))-(params(6)*exp(y(2))+exp(y(7))+params(16)+params(7)/2*(exp(y(14))-1)^2-params(13)*(1-exp(y(4))));
residual(28) = exp(y(8))-exp(y(4)+y(15)+y(6)*params(9));
residual(29) = exp(y(14))*(exp(y(14))-1)*params(7)-(T284+exp(y(14))*(exp(y(14))-1)*params(1)*params(7));
residual(30) = params(6)*exp((-y(13)))-(exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))+exp((-y(13)))*params(6)*(1-params(4))*params(1));
residual(31) = exp(y(5)+y(16)-y(17))-1;
residual(32) = exp(y(6)+y(10))-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)+params(10)*exp(y(6)*params(9)+y(15)+y(5))+(1-params(10))*(params(13)+T188*exp(y(6)*(1+params(3))+params(2)*y(7))));
residual(33) = exp(y(9))-(exp(y(9))*params(11)+(1-params(11))*exp(y(10)));
residual(34) = y(15)-(y(15)*params(15)+x(1));
residual(35) = exp(y(16))-params(9)*exp(y(15)+y(6)*(params(9)-1));
residual(36) = exp(y(17))-params(14)*exp(params(2)*y(7)+y(6)*params(3));
residual(37) = exp(y(18))-exp(y(16)-y(9));
residual(38) = exp(y(19))-exp(y(9)-y(17));
residual(39) = exp(y(20))-exp(y(4)+y(6));
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(39, 39);

  %
  % Jacobian matrix
  %

  g1(1,1)=exp(y(1))*y(22)+T13*y(32)*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)));
  g1(1,22)=exp(y(1));
  g1(1,32)=T13*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)));
  g1(2,2)=y(27)*(-(params(6)*exp(y(2))))+y(26)*(-(params(12)*(1-params(5))*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))))+y(22)*(-exp(y(2)-y(3)))+y(25)*(-exp(y(11)-y(2)));
  g1(2,3)=y(22)*exp(y(2)-y(3))+y(26)*(-(params(12)*(1-params(5))*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(2,11)=exp(y(11)-y(2))*y(25);
  g1(2,22)=(-exp(y(2)-y(3)));
  g1(2,25)=exp(y(11)-y(2));
  g1(2,26)=(-(params(12)*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(2,27)=(-(params(6)*exp(y(2))));
  g1(3,2)=y(22)*exp(y(2)-y(3))+y(26)*(-(params(12)*params(5)*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(3,3)=y(26)*(-(params(12)*params(5)*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))))+y(24)*(-exp(y(11)-y(3)))+y(22)*(-exp(y(2)-y(3)))+exp(y(3))*y(21);
  g1(3,11)=exp(y(11)-y(3))*y(24);
  g1(3,21)=exp(y(3));
  g1(3,22)=exp(y(2)-y(3));
  g1(3,24)=exp(y(11)-y(3));
  g1(3,26)=(-(params(12)*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(4,4)=T123;
  g1(4,6)=T163+y(39)*(-exp(y(4)+y(6)))+y(28)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(4,15)=y(28)*(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(4,21)=params(18)*(1-params(4))*exp(y(4));
  g1(4,23)=exp(y(4))+params(18)*(-((1-params(4))*exp(y(4))));
  g1(4,27)=params(13)*(-exp(y(4)));
  g1(4,28)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(4,39)=(-exp(y(4)+y(6)));
  g1(5,5)=T158;
  g1(5,6)=y(32)*(-(params(10)*params(9)*exp(y(6)*params(9)+y(15)+y(5))))+y(30)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(5,8)=T155;
  g1(5,15)=y(32)*(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))))+y(30)*(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(5,16)=exp(y(5)+y(16)-y(17))*y(31);
  g1(5,17)=y(31)*(-exp(y(5)+y(16)-y(17)));
  g1(5,29)=T154;
  g1(5,30)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(5,31)=exp(y(5)+y(16)-y(17));
  g1(5,32)=(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(6,4)=T163+y(39)*(-exp(y(4)+y(6)))+y(28)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(6,5)=y(32)*(-(params(10)*params(9)*exp(y(6)*params(9)+y(15)+y(5))))+y(30)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(6,6)=(-(exp(y(4))*params(14)*(1+params(3))*(1+params(3))*exp(y(6)*(1+params(3)))/(1+params(3))))+y(39)*(-exp(y(4)+y(6)))+y(36)*(-(params(14)*params(3)*params(3)*exp(params(2)*y(7)+y(6)*params(3))))+y(35)*(-(params(9)*(params(9)-1)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))))+y(32)*(exp(y(6)+y(10))-(params(10)*params(9)*params(9)*exp(y(6)*params(9)+y(15)+y(5))+(1-params(10))*T188*(1+params(3))*(1+params(3))*exp(y(6)*(1+params(3))+params(2)*y(7))))+y(30)*(-(params(9)*params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))))+y(28)*(-(params(9)*params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(6,7)=y(36)*(-(params(14)*params(3)*params(2)*exp(params(2)*y(7)+y(6)*params(3))))+y(32)*(-((1-params(10))*T188*(1+params(3))*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))));
  g1(6,9)=y(30)*exp(y(6)+y(9));
  g1(6,10)=y(32)*exp(y(6)+y(10));
  g1(6,15)=T563;
  g1(6,28)=(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(6,30)=(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))));
  g1(6,32)=T195;
  g1(6,35)=(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))));
  g1(6,36)=(-(params(14)*params(3)*exp(params(2)*y(7)+y(6)*params(3))));
  g1(6,39)=(-exp(y(4)+y(6)));
  g1(7,1)=T13*y(32)*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)*(-params(2))))+y(32)*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)*params(2)));
  g1(7,6)=y(36)*(-(params(14)*params(2)*params(3)*exp(params(2)*y(7)+y(6)*params(3))))+y(32)*(-((1-params(10))*T188*params(2)*(1+params(3))*exp(y(6)*(1+params(3))+params(2)*y(7))));
  g1(7,7)=(1-params(2))*(1-params(2))*exp(y(7)*(1-params(2)))/(1-params(2))+y(36)*(-(params(14)*params(2)*params(2)*exp(params(2)*y(7)+y(6)*params(3))))+y(27)*(-exp(y(7)))+y(32)*(-((1-params(10))*T188*params(2)*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))));
  g1(7,13)=y(30)*(-(params(6)*params(2)*(1-params(4))*params(1)*(-exp((-y(13))))))+T13*y(30)*(-(params(6)*(-params(2))*(1-params(4))*params(1)*(-exp((-y(13))))));
  g1(7,14)=y(29)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*params(2)+exp(y(14))*exp(y(14))*params(7)*params(1)*params(2)))+T13*y(29)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*(-params(2))+exp(y(14))*exp(y(14))*params(7)*params(1)*(-params(2))));
  g1(7,27)=(-exp(y(7)));
  g1(7,29)=(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*params(2)))+T13*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*(-params(2))));
  g1(7,30)=(-(exp((-y(13)))*params(6)*params(2)*(1-params(4))*params(1)))+T13*(-(exp((-y(13)))*params(6)*(-params(2))*(1-params(4))*params(1)));
  g1(7,32)=(-((1-params(10))*T188*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))+exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)*params(2)))+T13*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)*(-params(2))));
  g1(7,36)=(-(params(14)*params(2)*exp(params(2)*y(7)+y(6)*params(3))));
  g1(8,5)=T155;
  g1(8,8)=y(29)*(-T284)+y(28)*exp(y(8))+y(27)*exp(y(8));
  g1(8,27)=exp(y(8));
  g1(8,28)=exp(y(8));
  g1(8,29)=(-T284);
  g1(9,6)=y(30)*exp(y(6)+y(9));
  g1(9,9)=y(38)*(-exp(y(9)-y(17)))+exp(y(9))*y(33)+y(30)*exp(y(6)+y(9))+params(18)*y(33)*(-(exp(y(9))*params(11)))+y(37)*(-exp(y(16)-y(9)));
  g1(9,16)=exp(y(16)-y(9))*y(37);
  g1(9,17)=y(38)*exp(y(9)-y(17));
  g1(9,30)=exp(y(6)+y(9));
  g1(9,33)=exp(y(9))+params(18)*(-(exp(y(9))*params(11)));
  g1(9,37)=exp(y(16)-y(9));
  g1(9,38)=(-exp(y(9)-y(17)));
  g1(10,6)=y(32)*exp(y(6)+y(10));
  g1(10,10)=y(33)*(-((1-params(11))*exp(y(10))))+y(32)*exp(y(6)+y(10));
  g1(10,32)=exp(y(6)+y(10));
  g1(10,33)=(-((1-params(11))*exp(y(10))));
  g1(11,2)=exp(y(11)-y(2))*y(25);
  g1(11,3)=exp(y(11)-y(3))*y(24);
  g1(11,11)=y(26)*exp(y(11))+y(25)*(-exp(y(11)-y(2)))+y(24)*(-exp(y(11)-y(3)))+y(23)*(-exp(y(11)));
  g1(11,23)=(-exp(y(11)));
  g1(11,24)=(-exp(y(11)-y(3)));
  g1(11,25)=(-exp(y(11)-y(2)));
  g1(11,26)=exp(y(11));
  g1(12,12)=y(24)*exp(y(12));
  g1(12,24)=exp(y(12));
  g1(13,13)=y(25)*exp(y(13))+y(30)*params(6)*exp((-y(13)))+T13*y(30)*(-(exp((-y(13)))*params(6)*(1-params(4))*params(1)));
  g1(13,25)=exp(y(13));
  g1(13,30)=params(6)*(-exp((-y(13))))+T13*(-((-exp((-y(13))))*params(6)*(1-params(4))*params(1)));
  g1(14,14)=y(29)*(T356+exp(y(14))*exp(y(14))*params(7)+exp(y(14))*exp(y(14))*params(7))+y(27)*(-(params(7)/2*(exp(y(14))*2*(exp(y(14))-1)+exp(y(14))*2*exp(y(14)))))+T13*y(29)*(-(T370+exp(y(14))*exp(y(14))*params(1)*params(7)+exp(y(14))*exp(y(14))*params(1)*params(7)));
  g1(14,27)=T362;
  g1(14,29)=T356+T13*(-T370);
  g1(15,4)=y(28)*(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(15,5)=y(32)*(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))))+y(30)*(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(15,6)=T563;
  g1(15,15)=y(35)*(-(params(9)*exp(y(15)+y(6)*(params(9)-1))))+T381;
  g1(15,28)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(15,30)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(15,32)=(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(15,34)=1+params(18)*(-params(15));
  g1(15,35)=(-(params(9)*exp(y(15)+y(6)*(params(9)-1))));
  g1(16,5)=exp(y(5)+y(16)-y(17))*y(31);
  g1(16,9)=exp(y(16)-y(9))*y(37);
  g1(16,16)=y(37)*(-exp(y(16)-y(9)))+exp(y(5)+y(16)-y(17))*y(31)+y(35)*exp(y(16));
  g1(16,17)=y(31)*(-exp(y(5)+y(16)-y(17)));
  g1(16,31)=exp(y(5)+y(16)-y(17));
  g1(16,35)=exp(y(16));
  g1(16,37)=(-exp(y(16)-y(9)));
  g1(17,5)=y(31)*(-exp(y(5)+y(16)-y(17)));
  g1(17,9)=y(38)*exp(y(9)-y(17));
  g1(17,16)=y(31)*(-exp(y(5)+y(16)-y(17)));
  g1(17,17)=y(38)*(-exp(y(9)-y(17)))+exp(y(5)+y(16)-y(17))*y(31)+y(36)*exp(y(17));
  g1(17,31)=(-exp(y(5)+y(16)-y(17)));
  g1(17,36)=exp(y(17));
  g1(17,38)=exp(y(9)-y(17));
  g1(18,18)=y(37)*exp(y(18));
  g1(18,37)=exp(y(18));
  g1(19,19)=y(38)*exp(y(19));
  g1(19,38)=exp(y(19));
  g1(20,20)=y(39)*exp(y(20));
  g1(20,39)=exp(y(20));
  g1(21,3)=exp(y(3));
  g1(21,4)=(1-params(4))*exp(y(4));
  g1(22,1)=exp(y(1));
  g1(22,2)=(-exp(y(2)-y(3)));
  g1(22,3)=exp(y(2)-y(3));
  g1(23,4)=exp(y(4))-(1-params(4))*exp(y(4));
  g1(23,11)=(-exp(y(11)));
  g1(24,3)=exp(y(11)-y(3));
  g1(24,11)=(-exp(y(11)-y(3)));
  g1(24,12)=exp(y(12));
  g1(25,2)=exp(y(11)-y(2));
  g1(25,11)=(-exp(y(11)-y(2)));
  g1(25,13)=exp(y(13));
  g1(26,2)=(-(params(12)*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(26,3)=(-(params(12)*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(26,11)=exp(y(11));
  g1(27,2)=(-(params(6)*exp(y(2))));
  g1(27,4)=params(13)*(-exp(y(4)));
  g1(27,7)=(-exp(y(7)));
  g1(27,8)=exp(y(8));
  g1(27,14)=T362;
  g1(28,4)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(28,6)=(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(28,8)=exp(y(8));
  g1(28,15)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(29,5)=T154;
  g1(29,8)=(-T284);
  g1(29,14)=T356-T370;
  g1(30,5)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(30,6)=(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))));
  g1(30,9)=exp(y(6)+y(9));
  g1(30,13)=params(6)*(-exp((-y(13))))-(-exp((-y(13))))*params(6)*(1-params(4))*params(1);
  g1(30,15)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(31,5)=exp(y(5)+y(16)-y(17));
  g1(31,16)=exp(y(5)+y(16)-y(17));
  g1(31,17)=(-exp(y(5)+y(16)-y(17)));
  g1(32,1)=(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)));
  g1(32,5)=(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(32,6)=T195;
  g1(32,7)=(-((1-params(10))*T188*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))));
  g1(32,10)=exp(y(6)+y(10));
  g1(32,15)=(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(33,9)=exp(y(9))-exp(y(9))*params(11);
  g1(33,10)=(-((1-params(11))*exp(y(10))));
  g1(34,15)=1-params(15);
  g1(35,6)=(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))));
  g1(35,15)=(-(params(9)*exp(y(15)+y(6)*(params(9)-1))));
  g1(35,16)=exp(y(16));
  g1(36,6)=(-(params(14)*params(3)*exp(params(2)*y(7)+y(6)*params(3))));
  g1(36,7)=(-(params(14)*params(2)*exp(params(2)*y(7)+y(6)*params(3))));
  g1(36,17)=exp(y(17));
  g1(37,9)=exp(y(16)-y(9));
  g1(37,16)=(-exp(y(16)-y(9)));
  g1(37,18)=exp(y(18));
  g1(38,9)=(-exp(y(9)-y(17)));
  g1(38,17)=exp(y(9)-y(17));
  g1(38,19)=exp(y(19));
  g1(39,4)=(-exp(y(4)+y(6)));
  g1(39,6)=(-exp(y(4)+y(6)));
  g1(39,20)=exp(y(20));
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],39,1521);
end
end
