function [residual, g1, g2] = bmrtm_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                    columns: equations in order of declaration
%                                                    rows: variables in declaration order
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: equations in order of declaration
%                                                       rows: variables in declaration order
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 45, 1);

%
% Model equations
%

T13 = params(18)^(-1);
T20 = params(6)/params(12);
T43 = exp(y(1)*params(5))*T20*(1-params(4))*params(1)*exp(y(16))*(-(exp(y(18))*(-(params(12)*(1-params(5))*exp(y(1)*(1-params(5)))))));
T49 = T20*(1-params(4))*params(1)*exp(y(16))*(1-exp(y(18))*(1-params(12)*exp(y(1)*(1-params(5)))));
T55 = T13*y(35)*(-(T43+T49*params(5)*exp(y(1)*params(5))));
T146 = (-(exp(y(4))*params(14)*exp(y(6)*(1+params(3)))/(1+params(3))))+y(45)*(-exp(y(4)+y(6)))+y(31)*(-exp(y(4)+y(15)+y(6)*params(9)))+y(30)*params(13)*(-exp(y(4)))+exp(y(4))*y(26)+params(18)*y(24)*(1-params(4))*exp(y(4))+params(18)*y(26)*(-((1-params(4))*exp(y(4))));
T153 = (-(exp(y(16))*exp(y(6)*params(9)+y(15)+y(5))));
T154 = y(35)*T153;
T177 = (-(exp(y(8))*(1-params(8))*(-(params(8)/(params(8)-1)*exp(y(5))))));
T178 = y(32)*T177;
T181 = T154+exp(y(5)+y(19)-y(9))*y(34)+y(33)*(-exp(y(6)*params(9)+y(15)+y(5)))+T178;
T186 = (-(exp(y(4))*params(14)*(1+params(3))*exp(y(6)*(1+params(3)))/(1+params(3))));
T211 = params(14)/(1+params(3));
T218 = exp(y(6)+y(10))-(exp(y(16))*params(9)*exp(y(6)*params(9)+y(15)+y(5))+(1-exp(y(16)))*T211*(1+params(3))*exp(y(6)*(1+params(3))+params(2)*y(7)));
T250 = exp(y(1)*params(5))*T20*(1-exp(y(18))*(1-params(12)*exp(y(1)*(1-params(5)))))*params(2)*(1-params(4))*params(1)*exp(y(16));
T298 = (-(exp(y(1)*params(5))*T20*(1-exp(y(18))*(1-params(12)*exp(y(1)*(1-params(5)))))*(-params(2))*(1-params(4))*params(1)*exp(y(16))));
T300 = T13*y(35)*T298;
T308 = exp(y(8))*(1-params(8))*(1+params(17)-params(8)/(params(8)-1)*exp(y(5)));
T354 = (-((-exp(y(20)-y(10)))/(1-params(9))));
T355 = y(37)*T354;
T393 = exp(y(14))*(exp(y(14))-1)*params(7)+exp(y(14))*exp(y(14))*params(7);
T399 = (-(params(7)/2*exp(y(14))*2*(exp(y(14))-1)));
T407 = exp(y(14))*(exp(y(14))-1)*params(1)*params(7)+exp(y(14))*exp(y(14))*params(1)*params(7);
T418 = T154+y(31)*(-exp(y(4)+y(15)+y(6)*params(9)))+y(33)*(-exp(y(6)*params(9)+y(15)+y(5)));
T429 = exp(y(1)*params(5))*T49;
T436 = (-(T429+exp(y(16))*exp(y(6)*params(9)+y(15)+y(5))+(params(13)+T211*exp(y(6)*(1+params(3))+params(2)*y(7)))*(-exp(y(16)))));
T438 = exp(y(16))*y(36)+y(35)*T436;
T456 = (1-params(10)*(1-exp(y(17))))*(1-params(10)*(1-exp(y(17))));
T458 = (-((exp(y(17))*params(10)*(1-params(10)*(1-exp(y(17))))-exp(y(17))*params(10)*(-(params(10)*(-exp(y(17))))))/T456));
T470 = (-(exp(y(1)*params(5))*T20*(1-params(4))*params(1)*exp(y(16))*(-(exp(y(18))*(1-params(12)*exp(y(1)*(1-params(5))))))));
T471 = y(35)*T470;
T486 = (-(exp(y(20)-y(10))/(1-params(9))));
T488 = y(42)*exp(y(20))+y(37)*T486;
T582 = T20*(1-params(4))*params(1)*exp(y(16))*(-(exp(y(18))*(-(params(12)*(1-params(5))*exp(y(1)*(1-params(5)))))))*params(5)*exp(y(1)*params(5));
T613 = T13*y(35)*(-(T43+params(5)*exp(y(1)*params(5))*T20*(1-params(4))*params(1)*exp(y(16))*(-(exp(y(18))*(1-params(12)*exp(y(1)*(1-params(5))))))));
T692 = y(41)*(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))))+y(35)*(-(exp(y(16))*params(9)*exp(y(6)*params(9)+y(15)+y(5))))+y(31)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))))+y(33)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))));
T696 = y(35)*(-(exp(y(16))*params(9)*exp(y(6)*params(9)+y(15)+y(5))+T211*(1+params(3))*exp(y(6)*(1+params(3))+params(2)*y(7))*(-exp(y(16)))));
residual(1) = exp(y(1))*y(25)+T55;
residual(2) = y(30)*(-(params(6)*exp(y(2))))+y(29)*(-(params(12)*(1-params(5))*exp(params(5)*y(3)+(1-params(5))*y(2))))+exp(y(11)-y(2))*y(28)+y(25)*(-exp(y(2)-y(3)));
residual(3) = y(29)*(-(params(12)*params(5)*exp(params(5)*y(3)+(1-params(5))*y(2))))+exp(y(11)-y(3))*y(27)+y(25)*exp(y(2)-y(3))+exp(y(3))*y(24);
residual(4) = T146;
residual(5) = T181;
residual(6) = T186+y(45)*(-exp(y(4)+y(6)))+y(42)*(-(params(14)*params(3)*exp(params(2)*y(7)+y(6)*params(3))))+y(41)*(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))))+y(35)*T218+y(33)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))))+y(31)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
residual(7) = (1-params(2))*exp(y(7)*(1-params(2)))/(1-params(2))+y(42)*(-(params(14)*params(2)*exp(params(2)*y(7)+y(6)*params(3))))+y(35)*(-((1-exp(y(16)))*T211*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))+T250))+y(33)*(-(exp((-y(13)))*params(6)*params(2)*(1-params(4))*params(1)))+y(32)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(2)*params(1)))+y(30)*(-exp(y(7)))+T13*y(32)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*(-params(2))*params(1)))+T13*y(33)*(-(exp((-y(13)))*params(6)*(-params(2))*(1-params(4))*params(1)))+T300;
residual(8) = y(32)*(-T308)+y(31)*exp(y(8))+y(30)*exp(y(8));
residual(9) = y(44)*(-exp(y(9)-y(20)))+exp(y(19)-y(9))*y(43)+exp(y(9))*y(39)+y(34)*(-exp(y(5)+y(19)-y(9)))+y(33)*exp(y(6)+y(9))+params(18)*y(39)*(-(exp(y(9))*params(11)));
residual(10) = y(39)*(-((1-params(11))*exp(y(10))))+T355+y(35)*exp(y(6)+y(10));
residual(11) = y(29)*exp(y(11))+y(28)*(-exp(y(11)-y(2)))+y(27)*(-exp(y(11)-y(3)))+y(26)*(-exp(y(11)));
residual(12) = y(27)*exp(y(12));
residual(13) = y(33)*params(6)*(-exp((-y(13))))+y(28)*exp(y(13))+T13*y(33)*(-((-exp((-y(13))))*params(6)*(1-params(4))*params(1)));
residual(14) = y(32)*T393+y(30)*T399+T13*y(32)*(-T407);
residual(15) = y(41)*(-(params(9)*exp(y(15)+y(6)*(params(9)-1))))+y(40)+T418+params(18)*y(40)*(-params(15));
residual(16) = T438;
residual(17) = (-y(38))+y(37)*exp(y(17))+y(36)*T458+params(18)*y(38);
residual(18) = exp(y(18))*y(38)+T13*T471;
residual(19) = y(43)*(-exp(y(19)-y(9)))+exp(y(5)+y(19)-y(9))*y(34)+y(41)*exp(y(19));
residual(20) = y(44)*exp(y(9)-y(20))+T488;
residual(21) = y(43)*exp(y(21));
residual(22) = y(44)*exp(y(22));
residual(23) = y(45)*exp(y(23));
residual(24) = exp(y(3))-(1-(1-params(4))*exp(y(4)));
residual(25) = exp(y(1))-exp(y(2)-y(3));
residual(26) = exp(y(4))-((1-params(4))*exp(y(4))+exp(y(11)));
residual(27) = exp(y(12))-exp(y(11)-y(3));
residual(28) = exp(y(13))-exp(y(11)-y(2));
residual(29) = exp(y(11))-params(12)*exp(params(5)*y(3)+(1-params(5))*y(2));
residual(30) = exp(y(8))-(params(6)*exp(y(2))+exp(y(7))+params(16)+params(7)/2*(exp(y(14))-1)^2-params(13)*(1-exp(y(4))));
residual(31) = exp(y(8))-exp(y(4)+y(15)+y(6)*params(9));
residual(32) = exp(y(14))*(exp(y(14))-1)*params(7)-(T308+exp(y(14))*(exp(y(14))-1)*params(1)*params(7));
residual(33) = params(6)*exp((-y(13)))-(exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))+exp((-y(13)))*params(6)*(1-params(4))*params(1));
residual(34) = exp(y(5)+y(19)-y(9))-1;
residual(35) = exp(y(6)+y(10))-(T429+exp(y(16))*exp(y(6)*params(9)+y(15)+y(5))+(1-exp(y(16)))*(params(13)+T211*exp(y(6)*(1+params(3))+params(2)*y(7))));
residual(36) = exp(y(16))-exp(y(17))*params(10)/(1-params(10)*(1-exp(y(17))));
residual(37) = exp(y(17))-(exp(y(20)-y(10))-params(9))/(1-params(9));
residual(38) = exp(y(18))-1;
residual(39) = exp(y(9))-(exp(y(9))*params(11)+(1-params(11))*exp(y(10)));
residual(40) = y(15)-(y(15)*params(15)+x(1));
residual(41) = exp(y(19))-params(9)*exp(y(15)+y(6)*(params(9)-1));
residual(42) = exp(y(20))-params(14)*exp(params(2)*y(7)+y(6)*params(3));
residual(43) = exp(y(21))-exp(y(19)-y(9));
residual(44) = exp(y(22))-exp(y(9)-y(20));
residual(45) = exp(y(23))-exp(y(4)+y(6));
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(45, 45);

  %
  % Jacobian matrix
  %

  g1(1,1)=exp(y(1))*y(25)+T13*y(35)*(-(T582+exp(y(1)*params(5))*T20*(1-params(4))*params(1)*exp(y(16))*(-(exp(y(18))*(-(params(12)*(1-params(5))*(1-params(5))*exp(y(1)*(1-params(5)))))))+T582+T49*params(5)*params(5)*exp(y(1)*params(5))));
  g1(1,16)=T55;
  g1(1,18)=T613;
  g1(1,25)=exp(y(1));
  g1(1,35)=T13*(-(T43+T49*params(5)*exp(y(1)*params(5))));
  g1(2,2)=y(30)*(-(params(6)*exp(y(2))))+y(29)*(-(params(12)*(1-params(5))*(1-params(5))*exp(params(5)*y(3)+(1-params(5))*y(2))))+y(25)*(-exp(y(2)-y(3)))+y(28)*(-exp(y(11)-y(2)));
  g1(2,3)=y(25)*exp(y(2)-y(3))+y(29)*(-(params(12)*(1-params(5))*params(5)*exp(params(5)*y(3)+(1-params(5))*y(2))));
  g1(2,11)=exp(y(11)-y(2))*y(28);
  g1(2,25)=(-exp(y(2)-y(3)));
  g1(2,28)=exp(y(11)-y(2));
  g1(2,29)=(-(params(12)*(1-params(5))*exp(params(5)*y(3)+(1-params(5))*y(2))));
  g1(2,30)=(-(params(6)*exp(y(2))));
  g1(3,2)=y(25)*exp(y(2)-y(3))+y(29)*(-(params(12)*params(5)*(1-params(5))*exp(params(5)*y(3)+(1-params(5))*y(2))));
  g1(3,3)=y(29)*(-(params(12)*params(5)*params(5)*exp(params(5)*y(3)+(1-params(5))*y(2))))+y(27)*(-exp(y(11)-y(3)))+y(25)*(-exp(y(2)-y(3)))+exp(y(3))*y(24);
  g1(3,11)=exp(y(11)-y(3))*y(27);
  g1(3,24)=exp(y(3));
  g1(3,25)=exp(y(2)-y(3));
  g1(3,27)=exp(y(11)-y(3));
  g1(3,29)=(-(params(12)*params(5)*exp(params(5)*y(3)+(1-params(5))*y(2))));
  g1(4,4)=T146;
  g1(4,6)=T186+y(45)*(-exp(y(4)+y(6)))+y(31)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(4,15)=y(31)*(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(4,24)=params(18)*(1-params(4))*exp(y(4));
  g1(4,26)=exp(y(4))+params(18)*(-((1-params(4))*exp(y(4))));
  g1(4,30)=params(13)*(-exp(y(4)));
  g1(4,31)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(4,45)=(-exp(y(4)+y(6)));
  g1(5,5)=T181;
  g1(5,6)=y(35)*(-(exp(y(16))*params(9)*exp(y(6)*params(9)+y(15)+y(5))))+y(33)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(5,8)=T178;
  g1(5,9)=y(34)*(-exp(y(5)+y(19)-y(9)));
  g1(5,15)=T154+y(33)*(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(5,16)=T154;
  g1(5,19)=exp(y(5)+y(19)-y(9))*y(34);
  g1(5,32)=T177;
  g1(5,33)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(5,34)=exp(y(5)+y(19)-y(9));
  g1(5,35)=T153;
  g1(6,4)=T186+y(45)*(-exp(y(4)+y(6)))+y(31)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(6,5)=y(35)*(-(exp(y(16))*params(9)*exp(y(6)*params(9)+y(15)+y(5))))+y(33)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(6,6)=(-(exp(y(4))*params(14)*(1+params(3))*(1+params(3))*exp(y(6)*(1+params(3)))/(1+params(3))))+y(45)*(-exp(y(4)+y(6)))+y(42)*(-(params(14)*params(3)*params(3)*exp(params(2)*y(7)+y(6)*params(3))))+y(41)*(-(params(9)*(params(9)-1)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))))+y(35)*(exp(y(6)+y(10))-(exp(y(16))*params(9)*params(9)*exp(y(6)*params(9)+y(15)+y(5))+(1-exp(y(16)))*T211*(1+params(3))*(1+params(3))*exp(y(6)*(1+params(3))+params(2)*y(7))))+y(33)*(-(params(9)*params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))))+y(31)*(-(params(9)*params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(6,7)=y(42)*(-(params(14)*params(3)*params(2)*exp(params(2)*y(7)+y(6)*params(3))))+y(35)*(-((1-exp(y(16)))*T211*(1+params(3))*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))));
  g1(6,9)=y(33)*exp(y(6)+y(9));
  g1(6,10)=y(35)*exp(y(6)+y(10));
  g1(6,15)=T692;
  g1(6,16)=T696;
  g1(6,31)=(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(6,33)=(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))));
  g1(6,35)=T218;
  g1(6,41)=(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))));
  g1(6,42)=(-(params(14)*params(3)*exp(params(2)*y(7)+y(6)*params(3))));
  g1(6,45)=(-exp(y(4)+y(6)));
  g1(7,1)=y(35)*(-(params(5)*exp(y(1)*params(5))*T20*(1-exp(y(18))*(1-params(12)*exp(y(1)*(1-params(5)))))*params(2)*(1-params(4))*params(1)*exp(y(16))+exp(y(1)*params(5))*T20*(-(exp(y(18))*(-(params(12)*(1-params(5))*exp(y(1)*(1-params(5)))))))*params(2)*(1-params(4))*params(1)*exp(y(16))))+T13*y(35)*(-(params(5)*exp(y(1)*params(5))*T20*(1-exp(y(18))*(1-params(12)*exp(y(1)*(1-params(5)))))*(-params(2))*(1-params(4))*params(1)*exp(y(16))+exp(y(1)*params(5))*T20*(-(exp(y(18))*(-(params(12)*(1-params(5))*exp(y(1)*(1-params(5)))))))*(-params(2))*(1-params(4))*params(1)*exp(y(16))));
  g1(7,6)=y(42)*(-(params(14)*params(2)*params(3)*exp(params(2)*y(7)+y(6)*params(3))))+y(35)*(-((1-exp(y(16)))*T211*params(2)*(1+params(3))*exp(y(6)*(1+params(3))+params(2)*y(7))));
  g1(7,7)=(1-params(2))*(1-params(2))*exp(y(7)*(1-params(2)))/(1-params(2))+y(42)*(-(params(14)*params(2)*params(2)*exp(params(2)*y(7)+y(6)*params(3))))+y(30)*(-exp(y(7)))+y(35)*(-((1-exp(y(16)))*T211*params(2)*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))));
  g1(7,13)=y(33)*(-(params(6)*params(2)*(1-params(4))*params(1)*(-exp((-y(13))))))+T13*y(33)*(-(params(6)*(-params(2))*(1-params(4))*params(1)*(-exp((-y(13))))));
  g1(7,14)=y(32)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(2)*params(1)+exp(y(14))*exp(y(14))*params(7)*params(2)*params(1)))+T13*y(32)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*(-params(2))*params(1)+exp(y(14))*exp(y(14))*params(7)*(-params(2))*params(1)));
  g1(7,16)=T300+y(35)*(-(T250+T211*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))*(-exp(y(16)))));
  g1(7,18)=y(35)*(-(exp(y(1)*params(5))*T20*params(2)*(1-params(4))*params(1)*exp(y(16))*(-(exp(y(18))*(1-params(12)*exp(y(1)*(1-params(5))))))))+T13*y(35)*(-(exp(y(1)*params(5))*T20*(-params(2))*(1-params(4))*params(1)*exp(y(16))*(-(exp(y(18))*(1-params(12)*exp(y(1)*(1-params(5))))))));
  g1(7,30)=(-exp(y(7)));
  g1(7,32)=(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(2)*params(1)))+T13*(-(exp(y(14))*(exp(y(14))-1)*params(7)*(-params(2))*params(1)));
  g1(7,33)=(-(exp((-y(13)))*params(6)*params(2)*(1-params(4))*params(1)))+T13*(-(exp((-y(13)))*params(6)*(-params(2))*(1-params(4))*params(1)));
  g1(7,35)=(-((1-exp(y(16)))*T211*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))+T250))+T13*T298;
  g1(7,42)=(-(params(14)*params(2)*exp(params(2)*y(7)+y(6)*params(3))));
  g1(8,5)=T178;
  g1(8,8)=y(32)*(-T308)+y(31)*exp(y(8))+y(30)*exp(y(8));
  g1(8,30)=exp(y(8));
  g1(8,31)=exp(y(8));
  g1(8,32)=(-T308);
  g1(9,5)=y(34)*(-exp(y(5)+y(19)-y(9)));
  g1(9,6)=y(33)*exp(y(6)+y(9));
  g1(9,9)=y(44)*(-exp(y(9)-y(20)))+y(43)*(-exp(y(19)-y(9)))+exp(y(9))*y(39)+params(18)*y(39)*(-(exp(y(9))*params(11)))+exp(y(5)+y(19)-y(9))*y(34)+y(33)*exp(y(6)+y(9));
  g1(9,19)=exp(y(19)-y(9))*y(43)+y(34)*(-exp(y(5)+y(19)-y(9)));
  g1(9,20)=y(44)*exp(y(9)-y(20));
  g1(9,33)=exp(y(6)+y(9));
  g1(9,34)=(-exp(y(5)+y(19)-y(9)));
  g1(9,39)=exp(y(9))+params(18)*(-(exp(y(9))*params(11)));
  g1(9,43)=exp(y(19)-y(9));
  g1(9,44)=(-exp(y(9)-y(20)));
  g1(10,6)=y(35)*exp(y(6)+y(10));
  g1(10,10)=y(39)*(-((1-params(11))*exp(y(10))))+y(35)*exp(y(6)+y(10))+y(37)*T486;
  g1(10,20)=T355;
  g1(10,35)=exp(y(6)+y(10));
  g1(10,37)=T354;
  g1(10,39)=(-((1-params(11))*exp(y(10))));
  g1(11,2)=exp(y(11)-y(2))*y(28);
  g1(11,3)=exp(y(11)-y(3))*y(27);
  g1(11,11)=y(29)*exp(y(11))+y(28)*(-exp(y(11)-y(2)))+y(27)*(-exp(y(11)-y(3)))+y(26)*(-exp(y(11)));
  g1(11,26)=(-exp(y(11)));
  g1(11,27)=(-exp(y(11)-y(3)));
  g1(11,28)=(-exp(y(11)-y(2)));
  g1(11,29)=exp(y(11));
  g1(12,12)=y(27)*exp(y(12));
  g1(12,27)=exp(y(12));
  g1(13,13)=y(28)*exp(y(13))+y(33)*params(6)*exp((-y(13)))+T13*y(33)*(-(exp((-y(13)))*params(6)*(1-params(4))*params(1)));
  g1(13,28)=exp(y(13));
  g1(13,33)=params(6)*(-exp((-y(13))))+T13*(-((-exp((-y(13))))*params(6)*(1-params(4))*params(1)));
  g1(14,14)=y(32)*(T393+exp(y(14))*exp(y(14))*params(7)+exp(y(14))*exp(y(14))*params(7))+y(30)*(-(params(7)/2*(exp(y(14))*2*(exp(y(14))-1)+exp(y(14))*2*exp(y(14)))))+T13*y(32)*(-(T407+exp(y(14))*exp(y(14))*params(1)*params(7)+exp(y(14))*exp(y(14))*params(1)*params(7)));
  g1(14,30)=T399;
  g1(14,32)=T393+T13*(-T407);
  g1(15,4)=y(31)*(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(15,5)=T154+y(33)*(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(15,6)=T692;
  g1(15,15)=y(41)*(-(params(9)*exp(y(15)+y(6)*(params(9)-1))))+T418;
  g1(15,16)=T154;
  g1(15,31)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(15,33)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(15,35)=T153;
  g1(15,40)=1+params(18)*(-params(15));
  g1(15,41)=(-(params(9)*exp(y(15)+y(6)*(params(9)-1))));
  g1(16,1)=y(35)*(-(T43+T49*params(5)*exp(y(1)*params(5))));
  g1(16,5)=T154;
  g1(16,6)=T696;
  g1(16,7)=y(35)*(-(T211*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))*(-exp(y(16)))));
  g1(16,15)=T154;
  g1(16,16)=T438;
  g1(16,18)=T471;
  g1(16,35)=T436;
  g1(16,36)=exp(y(16));
  g1(17,17)=y(37)*exp(y(17))+y(36)*(-((T456*(exp(y(17))*params(10)*(1-params(10)*(1-exp(y(17))))+exp(y(17))*params(10)*(-(params(10)*(-exp(y(17)))))-(exp(y(17))*params(10)*(-(params(10)*(-exp(y(17)))))+exp(y(17))*params(10)*(-(params(10)*(-exp(y(17)))))))-(exp(y(17))*params(10)*(1-params(10)*(1-exp(y(17))))-exp(y(17))*params(10)*(-(params(10)*(-exp(y(17))))))*((1-params(10)*(1-exp(y(17))))*(-(params(10)*(-exp(y(17)))))+(1-params(10)*(1-exp(y(17))))*(-(params(10)*(-exp(y(17)))))))/(T456*T456)));
  g1(17,36)=T458;
  g1(17,37)=exp(y(17));
  g1(17,38)=(-1)+params(18);
  g1(18,1)=T613;
  g1(18,16)=T13*T471;
  g1(18,18)=exp(y(18))*y(38)+T13*T471;
  g1(18,35)=T13*T470;
  g1(18,38)=exp(y(18));
  g1(19,5)=exp(y(5)+y(19)-y(9))*y(34);
  g1(19,9)=exp(y(19)-y(9))*y(43)+y(34)*(-exp(y(5)+y(19)-y(9)));
  g1(19,19)=y(43)*(-exp(y(19)-y(9)))+exp(y(5)+y(19)-y(9))*y(34)+y(41)*exp(y(19));
  g1(19,34)=exp(y(5)+y(19)-y(9));
  g1(19,41)=exp(y(19));
  g1(19,43)=(-exp(y(19)-y(9)));
  g1(20,9)=y(44)*exp(y(9)-y(20));
  g1(20,10)=T355;
  g1(20,20)=y(44)*(-exp(y(9)-y(20)))+T488;
  g1(20,37)=T486;
  g1(20,42)=exp(y(20));
  g1(20,44)=exp(y(9)-y(20));
  g1(21,21)=y(43)*exp(y(21));
  g1(21,43)=exp(y(21));
  g1(22,22)=y(44)*exp(y(22));
  g1(22,44)=exp(y(22));
  g1(23,23)=y(45)*exp(y(23));
  g1(23,45)=exp(y(23));
  g1(24,3)=exp(y(3));
  g1(24,4)=(1-params(4))*exp(y(4));
  g1(25,1)=exp(y(1));
  g1(25,2)=(-exp(y(2)-y(3)));
  g1(25,3)=exp(y(2)-y(3));
  g1(26,4)=exp(y(4))-(1-params(4))*exp(y(4));
  g1(26,11)=(-exp(y(11)));
  g1(27,3)=exp(y(11)-y(3));
  g1(27,11)=(-exp(y(11)-y(3)));
  g1(27,12)=exp(y(12));
  g1(28,2)=exp(y(11)-y(2));
  g1(28,11)=(-exp(y(11)-y(2)));
  g1(28,13)=exp(y(13));
  g1(29,2)=(-(params(12)*(1-params(5))*exp(params(5)*y(3)+(1-params(5))*y(2))));
  g1(29,3)=(-(params(12)*params(5)*exp(params(5)*y(3)+(1-params(5))*y(2))));
  g1(29,11)=exp(y(11));
  g1(30,2)=(-(params(6)*exp(y(2))));
  g1(30,4)=params(13)*(-exp(y(4)));
  g1(30,7)=(-exp(y(7)));
  g1(30,8)=exp(y(8));
  g1(30,14)=T399;
  g1(31,4)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(31,6)=(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(31,8)=exp(y(8));
  g1(31,15)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(32,5)=T177;
  g1(32,8)=(-T308);
  g1(32,14)=T393-T407;
  g1(33,5)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(33,6)=(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))));
  g1(33,9)=exp(y(6)+y(9));
  g1(33,13)=params(6)*(-exp((-y(13))))-(-exp((-y(13))))*params(6)*(1-params(4))*params(1);
  g1(33,15)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(34,5)=exp(y(5)+y(19)-y(9));
  g1(34,9)=(-exp(y(5)+y(19)-y(9)));
  g1(34,19)=exp(y(5)+y(19)-y(9));
  g1(35,1)=(-(T43+T49*params(5)*exp(y(1)*params(5))));
  g1(35,5)=T153;
  g1(35,6)=T218;
  g1(35,7)=(-((1-exp(y(16)))*T211*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))));
  g1(35,10)=exp(y(6)+y(10));
  g1(35,15)=T153;
  g1(35,16)=T436;
  g1(35,18)=T470;
  g1(36,16)=exp(y(16));
  g1(36,17)=T458;
  g1(37,10)=T354;
  g1(37,17)=exp(y(17));
  g1(37,20)=T486;
  g1(38,18)=exp(y(18));
  g1(39,9)=exp(y(9))-exp(y(9))*params(11);
  g1(39,10)=(-((1-params(11))*exp(y(10))));
  g1(40,15)=1-params(15);
  g1(41,6)=(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))));
  g1(41,15)=(-(params(9)*exp(y(15)+y(6)*(params(9)-1))));
  g1(41,19)=exp(y(19));
  g1(42,6)=(-(params(14)*params(3)*exp(params(2)*y(7)+y(6)*params(3))));
  g1(42,7)=(-(params(14)*params(2)*exp(params(2)*y(7)+y(6)*params(3))));
  g1(42,20)=exp(y(20));
  g1(43,9)=exp(y(19)-y(9));
  g1(43,19)=(-exp(y(19)-y(9)));
  g1(43,21)=exp(y(21));
  g1(44,9)=(-exp(y(9)-y(20)));
  g1(44,20)=exp(y(9)-y(20));
  g1(44,22)=exp(y(22));
  g1(45,4)=(-exp(y(4)+y(6)));
  g1(45,6)=(-exp(y(4)+y(6)));
  g1(45,23)=exp(y(23));
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],45,2025);
end
end
