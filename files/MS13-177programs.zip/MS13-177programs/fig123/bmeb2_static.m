function [residual, g1, g2] = bmeb2_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                    columns: equations in order of declaration
%                                                    rows: variables in declaration order
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: equations in order of declaration
%                                                       rows: variables in declaration order
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 41, 1);

%
% Model equations
%

T13 = params(19)^(-1);
T123 = (-(exp(y(4))*params(14)*exp(y(6)*(1+params(3)))/(1+params(3))))+y(41)*(-exp(y(4)+y(6)))+y(29)*(-exp(y(4)+y(15)+y(6)*params(9)))+y(28)*params(13)*(-exp(y(4)))+exp(y(4))*y(24)+params(19)*y(22)*(1-params(4))*exp(y(4))+params(19)*y(24)*(-((1-params(4))*exp(y(4))));
T154 = (-(exp(y(8))*(1-params(8))*(-(params(8)/(params(8)-1)*exp(y(5))))));
T155 = y(30)*T154;
T158 = y(33)*(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))))+exp(y(5)+y(16)-y(17))*y(32)+y(31)*(-exp(y(6)*params(9)+y(15)+y(5)))+T155;
T163 = (-(exp(y(4))*params(14)*(1+params(3))*exp(y(6)*(1+params(3)))/(1+params(3))));
T188 = params(14)/(1+params(3));
T195 = exp(y(6)+y(10))-(params(10)*params(9)*exp(y(6)*params(9)+y(15)+y(5))+(1-params(10))*T188*(1+params(3))*exp(y(6)*(1+params(3))+params(2)*y(7)));
T284 = exp(y(8))*(1-params(8))*(1+params(18)-params(8)/(params(8)-1)*exp(y(5)));
T356 = exp(y(14))*(exp(y(14))-1)*params(7)+exp(y(14))*exp(y(14))*params(7);
T362 = (-(params(7)/2*exp(y(14))*2*(exp(y(14))-1)));
T370 = exp(y(14))*(exp(y(14))-1)*params(1)*params(7)+exp(y(14))*exp(y(14))*params(1)*params(7);
T381 = y(33)*(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))))+y(29)*(-exp(y(4)+y(15)+y(6)*params(9)))+y(31)*(-exp(y(6)*params(9)+y(15)+y(5)));
T584 = y(37)*(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))))+y(33)*(-(params(10)*params(9)*exp(y(6)*params(9)+y(15)+y(5))))+y(29)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))))+y(31)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))));
residual(1) = exp(y(1))*y(23)+T13*y(33)*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)));
residual(2) = y(28)*(-(params(6)*exp(y(2))))+y(27)*(-(params(12)*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))))+exp(y(11)-y(2))*y(26)+y(23)*(-exp(y(2)-y(3)));
residual(3) = y(27)*(-(params(12)*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))))+exp(y(11)-y(3))*y(25)+y(23)*exp(y(2)-y(3))+exp(y(3))*y(22);
residual(4) = T123;
residual(5) = T158;
residual(6) = T163+y(41)*(-exp(y(4)+y(6)))+y(38)*(-(params(14)*params(3)*exp(params(2)*y(7)+y(6)*params(3))))+y(37)*(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))))+y(33)*T195+y(31)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))))+y(29)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
residual(7) = (1-params(2))*exp(y(7)*(1-params(2)))/(1-params(2))+y(38)*(-(params(14)*params(2)*exp(params(2)*y(7)+y(6)*params(3))))+y(33)*(-((1-params(10))*T188*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))+exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)*params(2)))+y(31)*(-(exp((-y(13)))*params(6)*params(2)*(1-params(4))*params(1)))+y(30)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*params(2)))+y(28)*(-exp(y(7)))+T13*y(30)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*(-params(2))))+T13*y(31)*(-(exp((-y(13)))*params(6)*(-params(2))*(1-params(4))*params(1)))+T13*y(33)*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)*(-params(2))));
residual(8) = y(30)*(-T284)+y(29)*exp(y(8))+y(28)*exp(y(8));
residual(9) = y(40)*(-exp(y(9)-y(17)))+exp(y(16)-y(9))*y(39)+exp(y(9))*y(34)+y(31)*exp(y(6)+y(9))+params(19)*y(34)*(-(exp(y(9))*params(11)));
residual(10) = y(34)*(-((1-params(11))*exp(y(10))))+y(33)*exp(y(6)+y(10));
residual(11) = y(27)*exp(y(11))+y(26)*(-exp(y(11)-y(2)))+y(25)*(-exp(y(11)-y(3)))+y(24)*(-exp(y(11)));
residual(12) = y(25)*exp(y(12));
residual(13) = y(31)*params(6)*(-exp((-y(13))))+y(26)*exp(y(13))+T13*y(31)*(-((-exp((-y(13))))*params(6)*(1-params(4))*params(1)));
residual(14) = y(30)*T356+y(28)*T362+T13*y(30)*(-T370);
residual(15) = y(37)*(-(params(9)*exp(y(15)+y(6)*(params(9)-1))))+y(35)+T381+params(19)*y(35)*(-params(15));
residual(16) = y(39)*(-exp(y(16)-y(9)))+exp(y(5)+y(16)-y(17))*y(32)+y(37)*exp(y(16));
residual(17) = y(40)*exp(y(9)-y(17))+y(38)*exp(y(17))+y(32)*(-exp(y(5)+y(16)-y(17)));
residual(18) = y(39)*exp(y(18));
residual(19) = y(40)*exp(y(19));
residual(20) = y(41)*exp(y(20));
residual(21) = y(36)+y(28)*(-exp(y(21)))+params(19)*y(36)*(-params(16));
residual(22) = exp(y(3))-(1-(1-params(4))*exp(y(4)));
residual(23) = exp(y(1))-exp(y(2)-y(3));
residual(24) = exp(y(4))-((1-params(4))*exp(y(4))+exp(y(11)));
residual(25) = exp(y(12))-exp(y(11)-y(3));
residual(26) = exp(y(13))-exp(y(11)-y(2));
residual(27) = exp(y(11))-params(12)*exp(params(5)*y(3)+y(2)*(1-params(5)));
residual(28) = exp(y(8))-(params(6)*exp(y(2))+exp(y(7))+exp(y(21))+params(7)/2*(exp(y(14))-1)^2-params(13)*(1-exp(y(4))));
residual(29) = exp(y(8))-exp(y(4)+y(15)+y(6)*params(9));
residual(30) = exp(y(14))*(exp(y(14))-1)*params(7)-(T284+exp(y(14))*(exp(y(14))-1)*params(1)*params(7));
residual(31) = params(6)*exp((-y(13)))-(exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))+exp((-y(13)))*params(6)*(1-params(4))*params(1));
residual(32) = exp(y(5)+y(16)-y(17))-1;
residual(33) = exp(y(6)+y(10))-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)+params(10)*exp(y(6)*params(9)+y(15)+y(5))+(1-params(10))*(params(13)+T188*exp(y(6)*(1+params(3))+params(2)*y(7))));
residual(34) = exp(y(9))-(exp(y(9))*params(11)+(1-params(11))*exp(y(10)));
residual(35) = y(15)-(y(15)*params(15)+x(1));
residual(36) = y(21)-((1-params(16))*log(params(17))+y(21)*params(16)+x(2));
residual(37) = exp(y(16))-params(9)*exp(y(15)+y(6)*(params(9)-1));
residual(38) = exp(y(17))-params(14)*exp(params(2)*y(7)+y(6)*params(3));
residual(39) = exp(y(18))-exp(y(16)-y(9));
residual(40) = exp(y(19))-exp(y(9)-y(17));
residual(41) = exp(y(20))-exp(y(4)+y(6));
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(41, 41);

  %
  % Jacobian matrix
  %

  g1(1,1)=exp(y(1))*y(23)+T13*y(33)*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)));
  g1(1,23)=exp(y(1));
  g1(1,33)=T13*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)));
  g1(2,2)=y(28)*(-(params(6)*exp(y(2))))+y(27)*(-(params(12)*(1-params(5))*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))))+y(23)*(-exp(y(2)-y(3)))+y(26)*(-exp(y(11)-y(2)));
  g1(2,3)=y(23)*exp(y(2)-y(3))+y(27)*(-(params(12)*(1-params(5))*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(2,11)=exp(y(11)-y(2))*y(26);
  g1(2,23)=(-exp(y(2)-y(3)));
  g1(2,26)=exp(y(11)-y(2));
  g1(2,27)=(-(params(12)*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(2,28)=(-(params(6)*exp(y(2))));
  g1(3,2)=y(23)*exp(y(2)-y(3))+y(27)*(-(params(12)*params(5)*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(3,3)=y(27)*(-(params(12)*params(5)*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))))+y(25)*(-exp(y(11)-y(3)))+y(23)*(-exp(y(2)-y(3)))+exp(y(3))*y(22);
  g1(3,11)=exp(y(11)-y(3))*y(25);
  g1(3,22)=exp(y(3));
  g1(3,23)=exp(y(2)-y(3));
  g1(3,25)=exp(y(11)-y(3));
  g1(3,27)=(-(params(12)*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(4,4)=T123;
  g1(4,6)=T163+y(41)*(-exp(y(4)+y(6)))+y(29)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(4,15)=y(29)*(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(4,22)=params(19)*(1-params(4))*exp(y(4));
  g1(4,24)=exp(y(4))+params(19)*(-((1-params(4))*exp(y(4))));
  g1(4,28)=params(13)*(-exp(y(4)));
  g1(4,29)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(4,41)=(-exp(y(4)+y(6)));
  g1(5,5)=T158;
  g1(5,6)=y(33)*(-(params(10)*params(9)*exp(y(6)*params(9)+y(15)+y(5))))+y(31)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(5,8)=T155;
  g1(5,15)=y(33)*(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))))+y(31)*(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(5,16)=exp(y(5)+y(16)-y(17))*y(32);
  g1(5,17)=y(32)*(-exp(y(5)+y(16)-y(17)));
  g1(5,30)=T154;
  g1(5,31)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(5,32)=exp(y(5)+y(16)-y(17));
  g1(5,33)=(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(6,4)=T163+y(41)*(-exp(y(4)+y(6)))+y(29)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(6,5)=y(33)*(-(params(10)*params(9)*exp(y(6)*params(9)+y(15)+y(5))))+y(31)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(6,6)=(-(exp(y(4))*params(14)*(1+params(3))*(1+params(3))*exp(y(6)*(1+params(3)))/(1+params(3))))+y(41)*(-exp(y(4)+y(6)))+y(38)*(-(params(14)*params(3)*params(3)*exp(params(2)*y(7)+y(6)*params(3))))+y(37)*(-(params(9)*(params(9)-1)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))))+y(33)*(exp(y(6)+y(10))-(params(10)*params(9)*params(9)*exp(y(6)*params(9)+y(15)+y(5))+(1-params(10))*T188*(1+params(3))*(1+params(3))*exp(y(6)*(1+params(3))+params(2)*y(7))))+y(31)*(-(params(9)*params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))))+y(29)*(-(params(9)*params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(6,7)=y(38)*(-(params(14)*params(3)*params(2)*exp(params(2)*y(7)+y(6)*params(3))))+y(33)*(-((1-params(10))*T188*(1+params(3))*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))));
  g1(6,9)=y(31)*exp(y(6)+y(9));
  g1(6,10)=y(33)*exp(y(6)+y(10));
  g1(6,15)=T584;
  g1(6,29)=(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(6,31)=(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))));
  g1(6,33)=T195;
  g1(6,37)=(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))));
  g1(6,38)=(-(params(14)*params(3)*exp(params(2)*y(7)+y(6)*params(3))));
  g1(6,41)=(-exp(y(4)+y(6)));
  g1(7,1)=T13*y(33)*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)*(-params(2))))+y(33)*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)*params(2)));
  g1(7,6)=y(38)*(-(params(14)*params(2)*params(3)*exp(params(2)*y(7)+y(6)*params(3))))+y(33)*(-((1-params(10))*T188*params(2)*(1+params(3))*exp(y(6)*(1+params(3))+params(2)*y(7))));
  g1(7,7)=(1-params(2))*(1-params(2))*exp(y(7)*(1-params(2)))/(1-params(2))+y(38)*(-(params(14)*params(2)*params(2)*exp(params(2)*y(7)+y(6)*params(3))))+y(28)*(-exp(y(7)))+y(33)*(-((1-params(10))*T188*params(2)*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))));
  g1(7,13)=y(31)*(-(params(6)*params(2)*(1-params(4))*params(1)*(-exp((-y(13))))))+T13*y(31)*(-(params(6)*(-params(2))*(1-params(4))*params(1)*(-exp((-y(13))))));
  g1(7,14)=y(30)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*params(2)+exp(y(14))*exp(y(14))*params(7)*params(1)*params(2)))+T13*y(30)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*(-params(2))+exp(y(14))*exp(y(14))*params(7)*params(1)*(-params(2))));
  g1(7,28)=(-exp(y(7)));
  g1(7,30)=(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*params(2)))+T13*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*(-params(2))));
  g1(7,31)=(-(exp((-y(13)))*params(6)*params(2)*(1-params(4))*params(1)))+T13*(-(exp((-y(13)))*params(6)*(-params(2))*(1-params(4))*params(1)));
  g1(7,33)=(-((1-params(10))*T188*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))+exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)*params(2)))+T13*(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)*(-params(2))));
  g1(7,38)=(-(params(14)*params(2)*exp(params(2)*y(7)+y(6)*params(3))));
  g1(8,5)=T155;
  g1(8,8)=y(30)*(-T284)+y(29)*exp(y(8))+y(28)*exp(y(8));
  g1(8,28)=exp(y(8));
  g1(8,29)=exp(y(8));
  g1(8,30)=(-T284);
  g1(9,6)=y(31)*exp(y(6)+y(9));
  g1(9,9)=y(40)*(-exp(y(9)-y(17)))+exp(y(9))*y(34)+y(31)*exp(y(6)+y(9))+params(19)*y(34)*(-(exp(y(9))*params(11)))+y(39)*(-exp(y(16)-y(9)));
  g1(9,16)=exp(y(16)-y(9))*y(39);
  g1(9,17)=y(40)*exp(y(9)-y(17));
  g1(9,31)=exp(y(6)+y(9));
  g1(9,34)=exp(y(9))+params(19)*(-(exp(y(9))*params(11)));
  g1(9,39)=exp(y(16)-y(9));
  g1(9,40)=(-exp(y(9)-y(17)));
  g1(10,6)=y(33)*exp(y(6)+y(10));
  g1(10,10)=y(34)*(-((1-params(11))*exp(y(10))))+y(33)*exp(y(6)+y(10));
  g1(10,33)=exp(y(6)+y(10));
  g1(10,34)=(-((1-params(11))*exp(y(10))));
  g1(11,2)=exp(y(11)-y(2))*y(26);
  g1(11,3)=exp(y(11)-y(3))*y(25);
  g1(11,11)=y(27)*exp(y(11))+y(26)*(-exp(y(11)-y(2)))+y(25)*(-exp(y(11)-y(3)))+y(24)*(-exp(y(11)));
  g1(11,24)=(-exp(y(11)));
  g1(11,25)=(-exp(y(11)-y(3)));
  g1(11,26)=(-exp(y(11)-y(2)));
  g1(11,27)=exp(y(11));
  g1(12,12)=y(25)*exp(y(12));
  g1(12,25)=exp(y(12));
  g1(13,13)=y(26)*exp(y(13))+y(31)*params(6)*exp((-y(13)))+T13*y(31)*(-(exp((-y(13)))*params(6)*(1-params(4))*params(1)));
  g1(13,26)=exp(y(13));
  g1(13,31)=params(6)*(-exp((-y(13))))+T13*(-((-exp((-y(13))))*params(6)*(1-params(4))*params(1)));
  g1(14,14)=y(30)*(T356+exp(y(14))*exp(y(14))*params(7)+exp(y(14))*exp(y(14))*params(7))+y(28)*(-(params(7)/2*(exp(y(14))*2*(exp(y(14))-1)+exp(y(14))*2*exp(y(14)))))+T13*y(30)*(-(T370+exp(y(14))*exp(y(14))*params(1)*params(7)+exp(y(14))*exp(y(14))*params(1)*params(7)));
  g1(14,28)=T362;
  g1(14,30)=T356+T13*(-T370);
  g1(15,4)=y(29)*(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(15,5)=y(33)*(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))))+y(31)*(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(15,6)=T584;
  g1(15,15)=y(37)*(-(params(9)*exp(y(15)+y(6)*(params(9)-1))))+T381;
  g1(15,29)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(15,31)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(15,33)=(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(15,35)=1+params(19)*(-params(15));
  g1(15,37)=(-(params(9)*exp(y(15)+y(6)*(params(9)-1))));
  g1(16,5)=exp(y(5)+y(16)-y(17))*y(32);
  g1(16,9)=exp(y(16)-y(9))*y(39);
  g1(16,16)=y(39)*(-exp(y(16)-y(9)))+exp(y(5)+y(16)-y(17))*y(32)+y(37)*exp(y(16));
  g1(16,17)=y(32)*(-exp(y(5)+y(16)-y(17)));
  g1(16,32)=exp(y(5)+y(16)-y(17));
  g1(16,37)=exp(y(16));
  g1(16,39)=(-exp(y(16)-y(9)));
  g1(17,5)=y(32)*(-exp(y(5)+y(16)-y(17)));
  g1(17,9)=y(40)*exp(y(9)-y(17));
  g1(17,16)=y(32)*(-exp(y(5)+y(16)-y(17)));
  g1(17,17)=y(40)*(-exp(y(9)-y(17)))+exp(y(5)+y(16)-y(17))*y(32)+y(38)*exp(y(17));
  g1(17,32)=(-exp(y(5)+y(16)-y(17)));
  g1(17,38)=exp(y(17));
  g1(17,40)=exp(y(9)-y(17));
  g1(18,18)=y(39)*exp(y(18));
  g1(18,39)=exp(y(18));
  g1(19,19)=y(40)*exp(y(19));
  g1(19,40)=exp(y(19));
  g1(20,20)=y(41)*exp(y(20));
  g1(20,41)=exp(y(20));
  g1(21,21)=y(28)*(-exp(y(21)));
  g1(21,28)=(-exp(y(21)));
  g1(21,36)=1+params(19)*(-params(16));
  g1(22,3)=exp(y(3));
  g1(22,4)=(1-params(4))*exp(y(4));
  g1(23,1)=exp(y(1));
  g1(23,2)=(-exp(y(2)-y(3)));
  g1(23,3)=exp(y(2)-y(3));
  g1(24,4)=exp(y(4))-(1-params(4))*exp(y(4));
  g1(24,11)=(-exp(y(11)));
  g1(25,3)=exp(y(11)-y(3));
  g1(25,11)=(-exp(y(11)-y(3)));
  g1(25,12)=exp(y(12));
  g1(26,2)=exp(y(11)-y(2));
  g1(26,11)=(-exp(y(11)-y(2)));
  g1(26,13)=exp(y(13));
  g1(27,2)=(-(params(12)*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(27,3)=(-(params(12)*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(27,11)=exp(y(11));
  g1(28,2)=(-(params(6)*exp(y(2))));
  g1(28,4)=params(13)*(-exp(y(4)));
  g1(28,7)=(-exp(y(7)));
  g1(28,8)=exp(y(8));
  g1(28,14)=T362;
  g1(28,21)=(-exp(y(21)));
  g1(29,4)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(29,6)=(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(29,8)=exp(y(8));
  g1(29,15)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(30,5)=T154;
  g1(30,8)=(-T284);
  g1(30,14)=T356-T370;
  g1(31,5)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(31,6)=(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))));
  g1(31,9)=exp(y(6)+y(9));
  g1(31,13)=params(6)*(-exp((-y(13))))-(-exp((-y(13))))*params(6)*(1-params(4))*params(1);
  g1(31,15)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(32,5)=exp(y(5)+y(16)-y(17));
  g1(32,16)=exp(y(5)+y(16)-y(17));
  g1(32,17)=(-exp(y(5)+y(16)-y(17)));
  g1(33,1)=(-(exp(y(1))*params(6)*(1-params(4))*params(1)*params(10)));
  g1(33,5)=(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(33,6)=T195;
  g1(33,7)=(-((1-params(10))*T188*params(2)*exp(y(6)*(1+params(3))+params(2)*y(7))));
  g1(33,10)=exp(y(6)+y(10));
  g1(33,15)=(-(params(10)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(34,9)=exp(y(9))-exp(y(9))*params(11);
  g1(34,10)=(-((1-params(11))*exp(y(10))));
  g1(35,15)=1-params(15);
  g1(36,21)=1-params(16);
  g1(37,6)=(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))));
  g1(37,15)=(-(params(9)*exp(y(15)+y(6)*(params(9)-1))));
  g1(37,16)=exp(y(16));
  g1(38,6)=(-(params(14)*params(3)*exp(params(2)*y(7)+y(6)*params(3))));
  g1(38,7)=(-(params(14)*params(2)*exp(params(2)*y(7)+y(6)*params(3))));
  g1(38,17)=exp(y(17));
  g1(39,9)=exp(y(16)-y(9));
  g1(39,16)=(-exp(y(16)-y(9)));
  g1(39,18)=exp(y(18));
  g1(40,9)=(-exp(y(9)-y(17)));
  g1(40,17)=exp(y(9)-y(17));
  g1(40,19)=exp(y(19));
  g1(41,4)=(-exp(y(4)+y(6)));
  g1(41,6)=(-exp(y(4)+y(6)));
  g1(41,20)=exp(y(20));
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],41,1681);
end
end
