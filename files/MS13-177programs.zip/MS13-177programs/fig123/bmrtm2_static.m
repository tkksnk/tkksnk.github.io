function [residual, g1, g2] = bmrtm2_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                    columns: equations in order of declaration
%                                                    rows: variables in declaration order
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: equations in order of declaration
%                                                       rows: variables in declaration order
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 47, 1);

%
% Model equations
%

T108 = (-(exp(y(4))*params(14)*exp(y(6)*(1+params(3)))/(1+params(3))))+y(47)*(-exp(y(4)+y(6)))+y(32)*(-exp(y(4)+y(15)+y(6)*params(9)))+y(31)*params(13)*(-exp(y(4)))+exp(y(4))*y(27)+params(19)*y(25)*exp(y(4))*(1-params(4))+params(19)*y(27)*(-(exp(y(4))*(1-params(4))));
T118 = (-(exp(y(6)*params(9)+y(15)+y(5))*exp(y(16))));
T119 = y(36)*T118;
T142 = (-(exp(y(8))*(1-params(8))*(-(params(8)/(params(8)-1)*exp(y(5))))));
T143 = y(33)*T142;
T146 = T119+exp(y(5)+y(19)-y(9))*y(35)+y(34)*(-exp(y(6)*params(9)+y(15)+y(5)))+T143;
T151 = (-(exp(y(4))*params(14)*(1+params(3))*exp(y(6)*(1+params(3)))/(1+params(3))));
T178 = params(14)/(1+params(3));
T185 = exp(y(6)+y(10))-(exp(y(16))*params(9)*exp(y(6)*params(9)+y(15)+y(5))+(1-exp(y(16)))*T178*(1+params(3))*exp(y(6)*(1+params(3))+y(7)*params(2)));
T233 = (-((1-exp(y(16)))*T178*params(2)*exp(y(6)*(1+params(3))+y(7)*params(2))+exp((-y(13)))*params(6)*(1-exp(y(18))*(1-exp(y(12))))*params(2)*(1-params(4))*exp(y(16))*params(1)));
T255 = params(19)^(-1);
T279 = T255*y(36)*(-(exp((-y(13)))*params(6)*(1-exp(y(18))*(1-exp(y(12))))*(1-params(4))*exp(y(16))*params(1)*(-params(2))));
T287 = exp(y(8))*(1-params(8))*(1+params(18)-params(8)/(params(8)-1)*exp(y(5)));
T333 = (-((-exp(y(20)-y(10)))/(1-params(9))));
T334 = y(38)*T333;
T358 = (-(exp((-y(13)))*params(6)*(1-params(4))*exp(y(16))*params(1)*(-(exp(y(18))*(-exp(y(12)))))));
T360 = T255*y(36)*T358;
T361 = y(28)*exp(y(12))+T360;
T378 = (-((-exp((-y(13))))*params(6)*(1-exp(y(18))*(1-exp(y(12))))*(1-params(4))*exp(y(16))*params(1)));
T380 = T255*y(36)*T378;
T387 = exp(y(14))*(exp(y(14))-1)*params(7)+exp(y(14))*exp(y(14))*params(7);
T393 = (-(params(7)/2*exp(y(14))*2*(exp(y(14))-1)));
T401 = exp(y(14))*(exp(y(14))-1)*params(1)*params(7)+exp(y(14))*exp(y(14))*params(1)*params(7);
T412 = T119+y(32)*(-exp(y(4)+y(15)+y(6)*params(9)))+y(34)*(-exp(y(6)*params(9)+y(15)+y(5)));
T423 = exp((-y(13)))*params(6)*(1-exp(y(18))*(1-exp(y(12))))*(1-params(4))*exp(y(16))*params(1);
T430 = (-(T423+exp(y(6)*params(9)+y(15)+y(5))*exp(y(16))+(params(13)+T178*exp(y(6)*(1+params(3))+y(7)*params(2)))*(-exp(y(16)))));
T432 = exp(y(16))*y(37)+y(36)*T430;
T450 = (1-params(10)*(1-exp(y(17))))*(1-params(10)*(1-exp(y(17))));
T452 = (-((exp(y(17))*params(10)*(1-params(10)*(1-exp(y(17))))-exp(y(17))*params(10)*(-(params(10)*(-exp(y(17))))))/T450));
T464 = (-(exp((-y(13)))*params(6)*(1-params(4))*exp(y(16))*params(1)*(-(exp(y(18))*(1-exp(y(12)))))));
T467 = exp(y(18))*y(39)+T255*y(36)*T464;
T480 = (-(exp(y(20)-y(10))/(1-params(9))));
T482 = y(44)*exp(y(20))+y(38)*T480;
T668 = y(43)*(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))))+y(36)*(-(exp(y(16))*params(9)*exp(y(6)*params(9)+y(15)+y(5))))+y(32)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))))+y(34)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))));
T672 = y(36)*(-(exp(y(16))*params(9)*exp(y(6)*params(9)+y(15)+y(5))+T178*(1+params(3))*exp(y(6)*(1+params(3))+y(7)*params(2))*(-exp(y(16)))));
T757 = T255*y(36)*(-((-exp((-y(13))))*params(6)*(1-params(4))*exp(y(16))*params(1)*(-(exp(y(18))*(1-exp(y(12)))))));
residual(1) = exp(y(1))*y(26);
residual(2) = y(31)*(-(params(6)*exp(y(2))))+y(30)*(-(params(12)*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))))+exp(y(11)-y(2))*y(29)+y(26)*(-exp(y(2)-y(3)));
residual(3) = y(30)*(-(params(12)*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))))+exp(y(11)-y(3))*y(28)+y(26)*exp(y(2)-y(3))+exp(y(3))*y(25);
residual(4) = T108;
residual(5) = T146;
residual(6) = T151+y(47)*(-exp(y(4)+y(6)))+y(44)*(-(params(14)*params(3)*exp(y(7)*params(2)+y(6)*params(3))))+y(43)*(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))))+y(36)*T185+y(34)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))))+y(32)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
residual(7) = (1-params(2))*exp(y(7)*(1-params(2)))/(1-params(2))+y(44)*(-(params(14)*params(2)*exp(y(7)*params(2)+y(6)*params(3))))+y(36)*T233+y(34)*(-(exp((-y(13)))*params(6)*params(2)*(1-params(4))*params(1)))+y(33)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(2)*params(1)))+y(31)*(-exp(y(7)))+T255*y(33)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*(-params(2))))+T255*y(34)*(-(exp((-y(13)))*params(6)*(-params(2))*(1-params(4))*params(1)))+T279;
residual(8) = y(33)*(-T287)+y(32)*exp(y(8))+y(31)*exp(y(8));
residual(9) = y(46)*(-exp(y(9)-y(20)))+exp(y(19)-y(9))*y(45)+exp(y(9))*y(40)+y(35)*(-exp(y(5)+y(19)-y(9)))+y(34)*exp(y(6)+y(9))+params(19)*y(40)*(-(exp(y(9))*params(11)));
residual(10) = y(40)*(-((1-params(11))*exp(y(10))))+T334+y(36)*exp(y(6)+y(10));
residual(11) = y(30)*exp(y(11))+y(29)*(-exp(y(11)-y(2)))+y(28)*(-exp(y(11)-y(3)))+y(27)*(-exp(y(11)));
residual(12) = T361;
residual(13) = y(34)*params(6)*(-exp((-y(13))))+y(29)*exp(y(13))+T255*y(34)*(-((-exp((-y(13))))*params(6)*(1-params(4))*params(1)))+T380;
residual(14) = y(33)*T387+y(31)*T393+T255*y(33)*(-T401);
residual(15) = y(43)*(-(params(9)*exp(y(15)+y(6)*(params(9)-1))))+y(41)+T412+params(19)*y(41)*(-params(15));
residual(16) = T432;
residual(17) = (-y(39))+y(38)*exp(y(17))+y(37)*T452+params(19)*y(39);
residual(18) = T467;
residual(19) = y(45)*(-exp(y(19)-y(9)))+exp(y(5)+y(19)-y(9))*y(35)+y(43)*exp(y(19));
residual(20) = y(46)*exp(y(9)-y(20))+T482;
residual(21) = y(45)*exp(y(21));
residual(22) = y(46)*exp(y(22));
residual(23) = y(47)*exp(y(23));
residual(24) = y(42)+y(31)*(-exp(y(24)))+params(19)*y(42)*(-params(16));
residual(25) = exp(y(3))-(1-exp(y(4))*(1-params(4)));
residual(26) = exp(y(1))-exp(y(2)-y(3));
residual(27) = exp(y(4))-(exp(y(4))*(1-params(4))+exp(y(11)));
residual(28) = exp(y(12))-exp(y(11)-y(3));
residual(29) = exp(y(13))-exp(y(11)-y(2));
residual(30) = exp(y(11))-params(12)*exp(params(5)*y(3)+y(2)*(1-params(5)));
residual(31) = exp(y(8))-(params(6)*exp(y(2))+exp(y(7))+exp(y(24))+params(7)/2*(exp(y(14))-1)^2-params(13)*(1-exp(y(4))));
residual(32) = exp(y(8))-exp(y(4)+y(15)+y(6)*params(9));
residual(33) = exp(y(14))*(exp(y(14))-1)*params(7)-(T287+exp(y(14))*(exp(y(14))-1)*params(1)*params(7));
residual(34) = params(6)*exp((-y(13)))-(exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))+exp((-y(13)))*params(6)*(1-params(4))*params(1));
residual(35) = exp(y(5)+y(19)-y(9))-1;
residual(36) = exp(y(6)+y(10))-(T423+exp(y(6)*params(9)+y(15)+y(5))*exp(y(16))+(1-exp(y(16)))*(params(13)+T178*exp(y(6)*(1+params(3))+y(7)*params(2))));
residual(37) = exp(y(16))-exp(y(17))*params(10)/(1-params(10)*(1-exp(y(17))));
residual(38) = exp(y(17))-(exp(y(20)-y(10))-params(9))/(1-params(9));
residual(39) = exp(y(18))-1;
residual(40) = exp(y(9))-(exp(y(9))*params(11)+(1-params(11))*exp(y(10)));
residual(41) = y(15)-(y(15)*params(15)+x(1));
residual(42) = y(24)-((1-params(16))*log(params(17))+y(24)*params(16)+x(2));
residual(43) = exp(y(19))-params(9)*exp(y(15)+y(6)*(params(9)-1));
residual(44) = exp(y(20))-params(14)*exp(y(7)*params(2)+y(6)*params(3));
residual(45) = exp(y(21))-exp(y(19)-y(9));
residual(46) = exp(y(22))-exp(y(9)-y(20));
residual(47) = exp(y(23))-exp(y(4)+y(6));
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(47, 47);

  %
  % Jacobian matrix
  %

  g1(1,1)=exp(y(1))*y(26);
  g1(1,26)=exp(y(1));
  g1(2,2)=y(31)*(-(params(6)*exp(y(2))))+y(30)*(-(params(12)*(1-params(5))*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))))+y(26)*(-exp(y(2)-y(3)))+y(29)*(-exp(y(11)-y(2)));
  g1(2,3)=y(26)*exp(y(2)-y(3))+y(30)*(-(params(12)*(1-params(5))*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(2,11)=exp(y(11)-y(2))*y(29);
  g1(2,26)=(-exp(y(2)-y(3)));
  g1(2,29)=exp(y(11)-y(2));
  g1(2,30)=(-(params(12)*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(2,31)=(-(params(6)*exp(y(2))));
  g1(3,2)=y(26)*exp(y(2)-y(3))+y(30)*(-(params(12)*params(5)*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(3,3)=y(30)*(-(params(12)*params(5)*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))))+y(28)*(-exp(y(11)-y(3)))+y(26)*(-exp(y(2)-y(3)))+exp(y(3))*y(25);
  g1(3,11)=exp(y(11)-y(3))*y(28);
  g1(3,25)=exp(y(3));
  g1(3,26)=exp(y(2)-y(3));
  g1(3,28)=exp(y(11)-y(3));
  g1(3,30)=(-(params(12)*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(4,4)=T108;
  g1(4,6)=T151+y(47)*(-exp(y(4)+y(6)))+y(32)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(4,15)=y(32)*(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(4,25)=params(19)*exp(y(4))*(1-params(4));
  g1(4,27)=exp(y(4))+params(19)*(-(exp(y(4))*(1-params(4))));
  g1(4,31)=params(13)*(-exp(y(4)));
  g1(4,32)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(4,47)=(-exp(y(4)+y(6)));
  g1(5,5)=T146;
  g1(5,6)=y(36)*(-(exp(y(16))*params(9)*exp(y(6)*params(9)+y(15)+y(5))))+y(34)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(5,8)=T143;
  g1(5,9)=y(35)*(-exp(y(5)+y(19)-y(9)));
  g1(5,15)=T119+y(34)*(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(5,16)=T119;
  g1(5,19)=exp(y(5)+y(19)-y(9))*y(35);
  g1(5,33)=T142;
  g1(5,34)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(5,35)=exp(y(5)+y(19)-y(9));
  g1(5,36)=T118;
  g1(6,4)=T151+y(47)*(-exp(y(4)+y(6)))+y(32)*(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(6,5)=y(36)*(-(exp(y(16))*params(9)*exp(y(6)*params(9)+y(15)+y(5))))+y(34)*(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))));
  g1(6,6)=(-(exp(y(4))*params(14)*(1+params(3))*(1+params(3))*exp(y(6)*(1+params(3)))/(1+params(3))))+y(47)*(-exp(y(4)+y(6)))+y(44)*(-(params(14)*params(3)*params(3)*exp(y(7)*params(2)+y(6)*params(3))))+y(43)*(-(params(9)*(params(9)-1)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))))+y(36)*(exp(y(6)+y(10))-(exp(y(16))*params(9)*params(9)*exp(y(6)*params(9)+y(15)+y(5))+(1-exp(y(16)))*T178*(1+params(3))*(1+params(3))*exp(y(6)*(1+params(3))+y(7)*params(2))))+y(34)*(-(params(9)*params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))))+y(32)*(-(params(9)*params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(6,7)=y(44)*(-(params(14)*params(3)*params(2)*exp(y(7)*params(2)+y(6)*params(3))))+y(36)*(-((1-exp(y(16)))*T178*(1+params(3))*params(2)*exp(y(6)*(1+params(3))+y(7)*params(2))));
  g1(6,9)=y(34)*exp(y(6)+y(9));
  g1(6,10)=y(36)*exp(y(6)+y(10));
  g1(6,15)=T668;
  g1(6,16)=T672;
  g1(6,32)=(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(6,34)=(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))));
  g1(6,36)=T185;
  g1(6,43)=(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))));
  g1(6,44)=(-(params(14)*params(3)*exp(y(7)*params(2)+y(6)*params(3))));
  g1(6,47)=(-exp(y(4)+y(6)));
  g1(7,6)=y(44)*(-(params(14)*params(2)*params(3)*exp(y(7)*params(2)+y(6)*params(3))))+y(36)*(-((1-exp(y(16)))*T178*params(2)*(1+params(3))*exp(y(6)*(1+params(3))+y(7)*params(2))));
  g1(7,7)=(1-params(2))*(1-params(2))*exp(y(7)*(1-params(2)))/(1-params(2))+y(44)*(-(params(14)*params(2)*params(2)*exp(y(7)*params(2)+y(6)*params(3))))+y(31)*(-exp(y(7)))+y(36)*(-((1-exp(y(16)))*T178*params(2)*params(2)*exp(y(6)*(1+params(3))+y(7)*params(2))));
  g1(7,12)=y(36)*(-(exp((-y(13)))*params(6)*params(2)*(1-params(4))*exp(y(16))*params(1)*(-(exp(y(18))*(-exp(y(12)))))))+T255*y(36)*(-(exp((-y(13)))*params(6)*(1-params(4))*exp(y(16))*params(1)*(-params(2))*(-(exp(y(18))*(-exp(y(12)))))));
  g1(7,13)=y(36)*(-(params(6)*(1-exp(y(18))*(1-exp(y(12))))*params(2)*(1-params(4))*exp(y(16))*params(1)*(-exp((-y(13))))))+y(34)*(-(params(6)*params(2)*(1-params(4))*params(1)*(-exp((-y(13))))))+T255*y(34)*(-(params(6)*(-params(2))*(1-params(4))*params(1)*(-exp((-y(13))))))+T255*y(36)*(-(params(6)*(1-exp(y(18))*(1-exp(y(12))))*(1-params(4))*exp(y(16))*params(1)*(-params(2))*(-exp((-y(13))))));
  g1(7,14)=y(33)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(2)*params(1)+exp(y(14))*exp(y(14))*params(7)*params(2)*params(1)))+T255*y(33)*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*(-params(2))+exp(y(14))*exp(y(14))*params(7)*params(1)*(-params(2))));
  g1(7,16)=T279+y(36)*(-(exp((-y(13)))*params(6)*(1-exp(y(18))*(1-exp(y(12))))*params(2)*(1-params(4))*exp(y(16))*params(1)+T178*params(2)*exp(y(6)*(1+params(3))+y(7)*params(2))*(-exp(y(16)))));
  g1(7,18)=y(36)*(-(exp((-y(13)))*params(6)*params(2)*(1-params(4))*exp(y(16))*params(1)*(-(exp(y(18))*(1-exp(y(12)))))))+T255*y(36)*(-(exp((-y(13)))*params(6)*(1-params(4))*exp(y(16))*params(1)*(-params(2))*(-(exp(y(18))*(1-exp(y(12)))))));
  g1(7,31)=(-exp(y(7)));
  g1(7,33)=(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(2)*params(1)))+T255*(-(exp(y(14))*(exp(y(14))-1)*params(7)*params(1)*(-params(2))));
  g1(7,34)=(-(exp((-y(13)))*params(6)*params(2)*(1-params(4))*params(1)))+T255*(-(exp((-y(13)))*params(6)*(-params(2))*(1-params(4))*params(1)));
  g1(7,36)=T233+T255*(-(exp((-y(13)))*params(6)*(1-exp(y(18))*(1-exp(y(12))))*(1-params(4))*exp(y(16))*params(1)*(-params(2))));
  g1(7,44)=(-(params(14)*params(2)*exp(y(7)*params(2)+y(6)*params(3))));
  g1(8,5)=T143;
  g1(8,8)=y(33)*(-T287)+y(32)*exp(y(8))+y(31)*exp(y(8));
  g1(8,31)=exp(y(8));
  g1(8,32)=exp(y(8));
  g1(8,33)=(-T287);
  g1(9,5)=y(35)*(-exp(y(5)+y(19)-y(9)));
  g1(9,6)=y(34)*exp(y(6)+y(9));
  g1(9,9)=y(46)*(-exp(y(9)-y(20)))+y(45)*(-exp(y(19)-y(9)))+exp(y(9))*y(40)+params(19)*y(40)*(-(exp(y(9))*params(11)))+exp(y(5)+y(19)-y(9))*y(35)+y(34)*exp(y(6)+y(9));
  g1(9,19)=exp(y(19)-y(9))*y(45)+y(35)*(-exp(y(5)+y(19)-y(9)));
  g1(9,20)=y(46)*exp(y(9)-y(20));
  g1(9,34)=exp(y(6)+y(9));
  g1(9,35)=(-exp(y(5)+y(19)-y(9)));
  g1(9,40)=exp(y(9))+params(19)*(-(exp(y(9))*params(11)));
  g1(9,45)=exp(y(19)-y(9));
  g1(9,46)=(-exp(y(9)-y(20)));
  g1(10,6)=y(36)*exp(y(6)+y(10));
  g1(10,10)=y(40)*(-((1-params(11))*exp(y(10))))+y(36)*exp(y(6)+y(10))+y(38)*T480;
  g1(10,20)=T334;
  g1(10,36)=exp(y(6)+y(10));
  g1(10,38)=T333;
  g1(10,40)=(-((1-params(11))*exp(y(10))));
  g1(11,2)=exp(y(11)-y(2))*y(29);
  g1(11,3)=exp(y(11)-y(3))*y(28);
  g1(11,11)=y(30)*exp(y(11))+y(29)*(-exp(y(11)-y(2)))+y(28)*(-exp(y(11)-y(3)))+y(27)*(-exp(y(11)));
  g1(11,27)=(-exp(y(11)));
  g1(11,28)=(-exp(y(11)-y(3)));
  g1(11,29)=(-exp(y(11)-y(2)));
  g1(11,30)=exp(y(11));
  g1(12,12)=T361;
  g1(12,13)=T255*y(36)*(-(params(6)*(1-params(4))*exp(y(16))*params(1)*(-(exp(y(18))*(-exp(y(12)))))*(-exp((-y(13))))));
  g1(12,16)=T360;
  g1(12,18)=T360;
  g1(12,28)=exp(y(12));
  g1(12,36)=T255*T358;
  g1(13,12)=T255*y(36)*(-(params(6)*(1-params(4))*exp(y(16))*params(1)*(-(exp(y(18))*(-exp(y(12)))))*(-exp((-y(13))))));
  g1(13,13)=y(29)*exp(y(13))+y(34)*params(6)*exp((-y(13)))+T255*y(34)*(-(exp((-y(13)))*params(6)*(1-params(4))*params(1)))+T255*y(36)*(-T423);
  g1(13,16)=T380;
  g1(13,18)=T757;
  g1(13,29)=exp(y(13));
  g1(13,34)=params(6)*(-exp((-y(13))))+T255*(-((-exp((-y(13))))*params(6)*(1-params(4))*params(1)));
  g1(13,36)=T255*T378;
  g1(14,14)=y(33)*(T387+exp(y(14))*exp(y(14))*params(7)+exp(y(14))*exp(y(14))*params(7))+y(31)*(-(params(7)/2*(exp(y(14))*2*(exp(y(14))-1)+exp(y(14))*2*exp(y(14)))))+T255*y(33)*(-(T401+exp(y(14))*exp(y(14))*params(1)*params(7)+exp(y(14))*exp(y(14))*params(1)*params(7)));
  g1(14,31)=T393;
  g1(14,33)=T387+T255*(-T401);
  g1(15,4)=y(32)*(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(15,5)=T119+y(34)*(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(15,6)=T668;
  g1(15,15)=y(43)*(-(params(9)*exp(y(15)+y(6)*(params(9)-1))))+T412;
  g1(15,16)=T119;
  g1(15,32)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(15,34)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(15,36)=T118;
  g1(15,41)=1+params(19)*(-params(15));
  g1(15,43)=(-(params(9)*exp(y(15)+y(6)*(params(9)-1))));
  g1(16,5)=T119;
  g1(16,6)=T672;
  g1(16,7)=y(36)*(-(T178*params(2)*exp(y(6)*(1+params(3))+y(7)*params(2))*(-exp(y(16)))));
  g1(16,12)=y(36)*T358;
  g1(16,13)=y(36)*T378;
  g1(16,15)=T119;
  g1(16,16)=T432;
  g1(16,18)=y(36)*T464;
  g1(16,36)=T430;
  g1(16,37)=exp(y(16));
  g1(17,17)=y(38)*exp(y(17))+y(37)*(-((T450*(exp(y(17))*params(10)*(1-params(10)*(1-exp(y(17))))+exp(y(17))*params(10)*(-(params(10)*(-exp(y(17)))))-(exp(y(17))*params(10)*(-(params(10)*(-exp(y(17)))))+exp(y(17))*params(10)*(-(params(10)*(-exp(y(17)))))))-(exp(y(17))*params(10)*(1-params(10)*(1-exp(y(17))))-exp(y(17))*params(10)*(-(params(10)*(-exp(y(17))))))*((1-params(10)*(1-exp(y(17))))*(-(params(10)*(-exp(y(17)))))+(1-params(10)*(1-exp(y(17))))*(-(params(10)*(-exp(y(17)))))))/(T450*T450)));
  g1(17,37)=T452;
  g1(17,38)=exp(y(17));
  g1(17,39)=(-1)+params(19);
  g1(18,12)=T360;
  g1(18,13)=T757;
  g1(18,16)=T255*y(36)*T464;
  g1(18,18)=T467;
  g1(18,36)=T255*T464;
  g1(18,39)=exp(y(18));
  g1(19,5)=exp(y(5)+y(19)-y(9))*y(35);
  g1(19,9)=exp(y(19)-y(9))*y(45)+y(35)*(-exp(y(5)+y(19)-y(9)));
  g1(19,19)=y(45)*(-exp(y(19)-y(9)))+exp(y(5)+y(19)-y(9))*y(35)+y(43)*exp(y(19));
  g1(19,35)=exp(y(5)+y(19)-y(9));
  g1(19,43)=exp(y(19));
  g1(19,45)=(-exp(y(19)-y(9)));
  g1(20,9)=y(46)*exp(y(9)-y(20));
  g1(20,10)=T334;
  g1(20,20)=y(46)*(-exp(y(9)-y(20)))+T482;
  g1(20,38)=T480;
  g1(20,44)=exp(y(20));
  g1(20,46)=exp(y(9)-y(20));
  g1(21,21)=y(45)*exp(y(21));
  g1(21,45)=exp(y(21));
  g1(22,22)=y(46)*exp(y(22));
  g1(22,46)=exp(y(22));
  g1(23,23)=y(47)*exp(y(23));
  g1(23,47)=exp(y(23));
  g1(24,24)=y(31)*(-exp(y(24)));
  g1(24,31)=(-exp(y(24)));
  g1(24,42)=1+params(19)*(-params(16));
  g1(25,3)=exp(y(3));
  g1(25,4)=exp(y(4))*(1-params(4));
  g1(26,1)=exp(y(1));
  g1(26,2)=(-exp(y(2)-y(3)));
  g1(26,3)=exp(y(2)-y(3));
  g1(27,4)=exp(y(4))-exp(y(4))*(1-params(4));
  g1(27,11)=(-exp(y(11)));
  g1(28,3)=exp(y(11)-y(3));
  g1(28,11)=(-exp(y(11)-y(3)));
  g1(28,12)=exp(y(12));
  g1(29,2)=exp(y(11)-y(2));
  g1(29,11)=(-exp(y(11)-y(2)));
  g1(29,13)=exp(y(13));
  g1(30,2)=(-(params(12)*(1-params(5))*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(30,3)=(-(params(12)*params(5)*exp(params(5)*y(3)+y(2)*(1-params(5)))));
  g1(30,11)=exp(y(11));
  g1(31,2)=(-(params(6)*exp(y(2))));
  g1(31,4)=params(13)*(-exp(y(4)));
  g1(31,7)=(-exp(y(7)));
  g1(31,8)=exp(y(8));
  g1(31,14)=T393;
  g1(31,24)=(-exp(y(24)));
  g1(32,4)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(32,6)=(-(params(9)*exp(y(4)+y(15)+y(6)*params(9))));
  g1(32,8)=exp(y(8));
  g1(32,15)=(-exp(y(4)+y(15)+y(6)*params(9)));
  g1(33,5)=T142;
  g1(33,8)=(-T287);
  g1(33,14)=T387-T401;
  g1(34,5)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(34,6)=(-(params(9)*exp(y(6)*params(9)+y(15)+y(5))-exp(y(6)+y(9))));
  g1(34,9)=exp(y(6)+y(9));
  g1(34,13)=params(6)*(-exp((-y(13))))-(-exp((-y(13))))*params(6)*(1-params(4))*params(1);
  g1(34,15)=(-exp(y(6)*params(9)+y(15)+y(5)));
  g1(35,5)=exp(y(5)+y(19)-y(9));
  g1(35,9)=(-exp(y(5)+y(19)-y(9)));
  g1(35,19)=exp(y(5)+y(19)-y(9));
  g1(36,5)=T118;
  g1(36,6)=T185;
  g1(36,7)=(-((1-exp(y(16)))*T178*params(2)*exp(y(6)*(1+params(3))+y(7)*params(2))));
  g1(36,10)=exp(y(6)+y(10));
  g1(36,12)=T358;
  g1(36,13)=T378;
  g1(36,15)=T118;
  g1(36,16)=T430;
  g1(36,18)=T464;
  g1(37,16)=exp(y(16));
  g1(37,17)=T452;
  g1(38,10)=T333;
  g1(38,17)=exp(y(17));
  g1(38,20)=T480;
  g1(39,18)=exp(y(18));
  g1(40,9)=exp(y(9))-exp(y(9))*params(11);
  g1(40,10)=(-((1-params(11))*exp(y(10))));
  g1(41,15)=1-params(15);
  g1(42,24)=1-params(16);
  g1(43,6)=(-(params(9)*(params(9)-1)*exp(y(15)+y(6)*(params(9)-1))));
  g1(43,15)=(-(params(9)*exp(y(15)+y(6)*(params(9)-1))));
  g1(43,19)=exp(y(19));
  g1(44,6)=(-(params(14)*params(3)*exp(y(7)*params(2)+y(6)*params(3))));
  g1(44,7)=(-(params(14)*params(2)*exp(y(7)*params(2)+y(6)*params(3))));
  g1(44,20)=exp(y(20));
  g1(45,9)=exp(y(19)-y(9));
  g1(45,19)=(-exp(y(19)-y(9)));
  g1(45,21)=exp(y(21));
  g1(46,9)=(-exp(y(9)-y(20)));
  g1(46,20)=exp(y(9)-y(20));
  g1(46,22)=exp(y(22));
  g1(47,4)=(-exp(y(4)+y(6)));
  g1(47,6)=(-exp(y(4)+y(6)));
  g1(47,23)=exp(y(23));
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],47,2209);
end
end
