% fig123.m
%
% This m-file plots Figure 1-3 in the paper.
% bmrtm2.mod, bmeb2.mod and bmcomp2.mod should be in the same folder.
% Figures are stored in the folder [HOME]/Figures.
%
% October 2014, Takeki Sunakawa

clear all;
% close all;

dynare bmrtm2.mod
dynare bmeb2.mod
dynare bmcomp2.mod

load irramrtm
theta_path1a = ltheta_ua;
nn_path1a = lna_ua;
ww_path1a = lw_ua;
hh_path1a = lh_ua;
pai_path1a = lpai_ua;
mup_path1a = lmup_ua;
muw_path1a = lmuw_ua;
mup_ss1a = mup_ss;
muw_ss1a = muw_ss;

load irramrtm_rwr
theta_path2a = ltheta_ua;
nn_path2a = lna_ua;
ww_path2a = lw_ua;
hh_path2a = lh_ua;
pai_path2a = lpai_ua;
mup_path2a = lmup_ua;
muw_path2a = lmuw_ua;
mup_ss2a = mup_ss;
muw_ss2a = muw_ss;

load irrameb;
theta_path1b = ltheta_ua;
nn_path1b = lna_ua;
ww_path1b = lw_ua;
hh_path1b = lh_ua;
pai_path1b = lpai_ua;
mup_path1b = lmup_ua;
muw_path1b = lmuw_ua;
mup_ss1b = mup_ss;
muw_ss1b = muw_ss;

load irrameb_rwr;
theta_path2b = ltheta_ua;
nn_path2b = lna_ua;
ww_path2b = lw_ua;
hh_path2b = lh_ua;
pai_path2b = lpai_ua;
mup_path2b = lmup_ua;
muw_path2b = lmuw_ua;
mup_ss2b = mup_ss;
muw_ss2b = muw_ss;

load irramcomp;
ww_path1c = lw_ua;
hh_path1c = lh_ua;
pai_path1c = lpai_ua;
mup_path1c = lmup_ua;
muw_path1c = lmuw_ua;
mup_ss1c = mup_ss;
muw_ss1c = muw_ss;

load irramcomp_rwr;
ww_path2c = lw_ua;
hh_path2c = lh_ua;
pai_path2c = lpai_ua;
mup_path2c = lmup_ua;
muw_path2c = lmuw_ua;
mup_ss2c = mup_ss;
muw_ss2c = muw_ss;

T = 31;
time = [0:T-1]';

% Figure 1
figure;

subplot(4,2,1)
plot(time,ww_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,ww_path1b,'b--','LineWidth',2.0);
% plot(time,ww_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Real wages');
ylim([0.0 1.0]);

subplot(4,2,2)
plot(time,theta_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,theta_path1b,'b--','LineWidth',2.0);
% plot([0 T-1],[100 100],'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Labor market tightness');
legend('RTM','EB','Location','NorthEast');
ylim([0.0 8.0]);

subplot(4,2,3)
plot(time,nn_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,nn_path1b,'b--','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Employment');
ylim([0.0 1.0]);

subplot(4,2,4)
plot(time,hh_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,hh_path1b,'b--','LineWidth',2.0);
% plot(time,hh_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Hours per worker');
ylim([-1.0 1.0]);

subplot(4,2,5)
plot(time,mup_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,mup_path1b,'b--','LineWidth',2.0);
% plot(time,mup_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Price markup');
ylim([-0.2 0.2]);

subplot(4,2,6)
plot(time,muw_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,muw_path1b,'b--','LineWidth',2.0);
% plot(time,muw_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Wage markup');
ylim([-0.2 0.2]);

subplot(4,2,7)
plot(time,hh_path1a+nn_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,hh_path1b+nn_path1b,'b--','LineWidth',2.0);
% plot(time,hh_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Hours worked');
ylim([-1.0 1.0]);

subplot(4,2,8)
plot(time,pai_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,pai_path1b,'b--','LineWidth',2.0);
% plot(time,pai_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Inflation');
ylim([-0.05 0.05]);

print -depsc2 ../Figures/MS13-177Fig1.eps

% Figure 2
figure;

subplot(3,2,1);
plot(time,muw_path1b+mup_path1b,'m-','LineWidth',2.0);
hold on;
plot(time,mup_path1b,'r:','LineWidth',2.0);
plot(time,muw_path1b,'b-.','LineWidth',2.0);
plot([0 T-1],[0 0],'k-');
ylim([-0.2 0.2]);
title('EB, {\gamma_w}=0');

subplot(3,2,2);
plot(time,muw_path2b+mup_path2b,'m-','LineWidth',2.0);
hold on;
plot(time,mup_path2b,'r:','LineWidth',2.0);
plot(time,muw_path2b,'b-.','LineWidth',2.0);
plot([0 T-1],[0 0],'k-');
ylim([-1.0 1.0]);
title('EB, {\gamma_w}=0.6');
legend('Gap','Price markup','Wage markup');

subplot(3,2,3);
plot(time,muw_path1a+mup_path1a,'m-','LineWidth',2.0);
hold on;
plot(time,mup_path1a,'r:','LineWidth',2.0);
plot(time,muw_path1a,'b-.','LineWidth',2.0);
plot([0 T-1],[0 0],'k-');
ylim([-0.2 0.2]);
title('RTM, {\gamma_w}=0');

subplot(3,2,4);
plot(time,muw_path2a+mup_path2a,'m-','LineWidth',2.0);
hold on;
plot(time,mup_path2a,'r:','LineWidth',2.0);
plot(time,muw_path2a,'b-.','LineWidth',2.0);
plot([0 T-1],[0 0],'k-');
ylim([-3.0 1.0]);
title('RTM, {\gamma_w}=0.9');

subplot(3,2,5);
plot(time,muw_path1c+mup_path1c,'m-','LineWidth',2.0);
hold on;
plot(time,mup_path1c,'r:','LineWidth',2.0);
plot(time,muw_path1c,'b-.','LineWidth',2.0);
plot([0 T-1],[0 0],'k-');
ylim([-0.2 0.2]);
title('Warlasian, {\gamma_w}=0');

subplot(3,2,6);
plot(time,muw_path2c+mup_path2c,'m-','LineWidth',2.0);
hold on;
plot(time,mup_path2c,'r:','LineWidth',2.0);
plot(time,muw_path2c,'b-.','LineWidth',2.0);
plot([0 T-1],[0 0],'k-');
ylim([-3.0 1.0]);
title('Warlasian, {\gamma_w}=0.9');

print -depsc2 ../Figures/MS13-177Fig2.eps

% Figure 3
figure;

subplot(4,2,1)
plot(time,ww_path2a,'r-','LineWidth',2.0);
hold on;
plot(time,ww_path2b,'b--','LineWidth',2.0);
% plot(time,ww_path2c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Real wages');
ylim([0.0 1.0]);

subplot(4,2,2)
plot(time,theta_path2a,'r-','LineWidth',2.0);
hold on;
plot(time,theta_path2b,'b--','LineWidth',2.0);
% plot([0 T-1],[100 100],'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Labor market tightness');
legend('RTM','EB','Location','NorthEast');
% legend('RTM','EB','Warlasian','Location','NorthEast');
ylim([0.0 8.0]);

subplot(4,2,3)
plot(time,nn_path2a,'r-','LineWidth',2.0);
hold on;
plot(time,nn_path2b,'b--','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Employment');
ylim([0.0 1.0]);

subplot(4,2,4)
plot(time,hh_path2a,'r-','LineWidth',2.0);
hold on;
plot(time,hh_path2b,'b--','LineWidth',2.0);
% plot(time,hh_path2c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Hours per worker');
ylim([-1.0 1.0]);

subplot(4,2,5)
plot(time,mup_path2a,'r-','LineWidth',2.0);
hold on;
plot(time,mup_path2b,'b--','LineWidth',2.0);
% plot(time,mup_path2c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Price markup');
ylim([-1.0 1.0]);

subplot(4,2,6)
plot(time,muw_path2a,'r-','LineWidth',2.0);
hold on;
plot(time,muw_path2b,'b--','LineWidth',2.0);
% plot(time,muw_path2c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Wage markup');
ylim([-2.5 2.5]);

subplot(4,2,7)
plot(time,hh_path2a+nn_path2a,'r-','LineWidth',2.0);
hold on;
plot(time,hh_path2b+nn_path2b,'b--','LineWidth',2.0);
% plot(time,hh_path2c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Hours worked');
ylim([-1.0 1.0]);

subplot(4,2,8)
plot(time,pai_path2a,'r-','LineWidth',2.0);
hold on;
plot(time,pai_path2b,'b--','LineWidth',2.0);
% plot(time,pai_path2c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Inflation');
ylim([-0.2 0.2]);

print -depsc2 ../Figures/MS13-177Fig3.eps