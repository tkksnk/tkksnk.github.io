function [residual, g1, g2, g3] = bmrtmlin2_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Inputs :
%   y         [#dynamic variables by 1] double    vector of endogenous variables in the order stored
%                                                 in M_.lead_lag_incidence; see the Manual
%   x         [M_.exo_nbr by nperiods] double     matrix of exogenous variables (in declaration order)
%                                                 for all simulation periods
%   params    [M_.param_nbr by 1] double          vector of parameter values in declaration order
%   it_       scalar double                       time period for exogenous variables for which to evaluate the model
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the dynamic model equations in order of 
%                                          declaration of the equations
%   g1        [M_.endo_nbr by #dynamic variables] double    Jacobian matrix of the dynamic model equations;
%                                                           columns: equations in order of declaration
%                                                           rows: variables in order stored in M_.lead_lag_incidence
%   g2        [M_.endo_nbr by (#dynamic variables)^2] double   Hessian matrix of the dynamic model equations;
%                                                              columns: equations in order of declaration
%                                                              rows: variables in order stored in M_.lead_lag_incidence
%   g3        [M_.endo_nbr by (#dynamic variables)^3] double   Third order derivative matrix of the dynamic model equations;
%                                                              columns: equations in order of declaration
%                                                              rows: variables in order stored in M_.lead_lag_incidence
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(45, 1);
T86 = params(6)/params(19)*(1-params(4))*params(1);
T106 = params(25)*params(28)/params(24);
T118 = params(20)*(1-params(28))/params(30)/(1+params(3));
T134 = (1-params(4))*params(1)*params(28)*params(18)*params(6)/params(19);
T158 = (1-params(9))*params(29)/(1-(1-params(9))*(1-params(29)));
T197 = params(31)^(-1);
T205 = params(6)*params(23)/params(21)/(1-params(5));
T235 = 1/params(21);
T240 = params(9)/params(21)/(1+params(3));
T254 = (-((-(1-params(4)))/params(4)*params(18)));
T272 = (-(params(25)/params(24)));
T297 = (-(params(9)*params(25)/params(24)-params(20)));
T418 = (-(T134+T106+T118*(-(params(28)/(1-params(28))))-params(13)*params(28)));
T429 = (-(T134*(-(1-1/params(18)))));
T432 = (-(T134*(1-1/params(18))));
residual(1) = y(32)+T197*y(7)*(-T134);
residual(2) = (-(T205*(1-params(5))*2*y(9)))+y(37)*(-(params(6)*params(23)))+y(36)*(-(1-params(5)))+y(35)-y(32);
residual(3) = (-(T205*params(5)*2*y(10)))+y(36)*(-params(5))+y(34)+y(32)+y(31);
residual(4) = T235*(-(2*y(11)))+T240*(2*y(11)-2*(y(11)+y(13)*(1+params(3))))+(-y(52))+(-y(38))+y(37)*(-(params(13)*params(24)))+y(33)+params(31)*y(58)*T254+params(31)*(-(1-params(4)))*y(59);
residual(5) = y(42)*(-T106)+y(41)+y(40)*T272+y(39)*(-params(26));
residual(6) = T240*(-((1+params(3))*2*(y(11)+y(13)*(1+params(3)))))+(-y(52))+y(49)*(-params(3))+y(48)*(-(params(9)-1))+y(42)*(params(20)-(params(9)*T106+(1+params(3))*T118))+y(40)*T297+y(38)*(-params(9));
residual(7) = (-(params(2)*2*y(14)))+(-params(2))*y(49)+y(42)*(-(params(2)*T118+params(2)*T134))+y(40)*(-(T86*params(2)))+y(37)*(-params(21))+T197*y(6)*(-(T86*(-params(2))))+T197*y(7)*(-((-params(2))*T134));
residual(8) = T235*2*y(15)+y(37)+y(38);
residual(9) = (-y(51))+y(50)+y(46)+(-y(41))+params(20)*y(40)+params(31)*y(61)*(-params(11));
residual(10) = y(46)*(-(1-params(11)))+y(44)+params(20)*y(42);
residual(11) = (-(T205*(-(2*y(18)))))+y(36)+(-y(35))+(-y(34))+y(33)*(-params(4));
residual(12) = y(34);
residual(13) = y(35)+y(40)*(-(params(6)/params(19)))+T197*T86*y(6);
residual(14) = (-params(7))/params(27)*2*y(21)+y(39)+T197*y(5)*(-params(1));
residual(15) = (-y(48))+y(47)+y(42)*(-T106)+y(40)*T272-y(38)+params(31)*y(62)*(-params(15));
residual(16) = y(43)+y(42)*T418;
residual(17) = (-y(45))+T158*y(44)+y(43)*(-(1-params(28)))+y(42)*T429+T197*y(7)*T432+params(31)*y(60);
residual(18) = y(45);
residual(19) = (-y(50))+y(41)+y(48);
residual(20) = y(51)+y(49)-y(44);
residual(21) = y(50);
residual(22) = y(51);
residual(23) = y(52);
residual(24) = y(10)-(-(1-params(4)))/params(4)*params(18)*y(1);
residual(25) = y(8)-(y(9)-y(10));
residual(26) = y(11)-((1-params(4))*y(1)+params(4)*y(18));
residual(27) = y(19)-(y(18)-y(10));
residual(28) = y(20)-(y(18)-y(9));
residual(29) = y(18)-(y(10)*params(5)+y(9)*(1-params(5)));
residual(30) = y(15)-(params(21)*y(14)+y(9)*params(6)*params(23)+y(11)*params(13)*params(24));
residual(31) = y(15)-(y(11)+y(22)+params(9)*y(13));
residual(32) = y(21)-(params(26)*y(12)+params(1)*y(56));
residual(33) = params(6)/params(19)*(-y(20))-(params(25)/params(24)*(params(9)*y(13)+y(22)+y(12))-params(20)*(y(13)+y(16))+T86*((-params(2))*(y(54)-y(14))-y(55)));
residual(34) = y(12)+y(26)-y(16);
residual(35) = params(20)*(y(13)+y(17))-(T106*(params(9)*y(13)+y(22)+y(12)+y(23))+T118*(y(13)*(1+params(3))+y(14)*params(2)-y(23)*params(28)/(1-params(28)))-y(23)*params(13)*params(28)+T134*(y(23)+(1-1/params(18))*(y(57)-y(24))-params(2)*(y(54)-y(14))+y(53)));
residual(36) = y(23)-(1-params(28))*y(24);
residual(37) = y(17)-(y(27)-y(24)*T158);
residual(38) = y(25)-(y(24)-y(4));
residual(39) = y(16)-(params(11)*y(2)+y(17)*(1-params(11)));
residual(40) = y(22)-(params(15)*y(3)+x(it_, 1));
residual(41) = y(26)-(y(22)+y(13)*(params(9)-1));
residual(42) = y(27)-(y(14)*params(2)+y(13)*params(3));
residual(43) = y(28)-(y(26)-y(16));
residual(44) = y(29)-(y(16)-y(27));
residual(45) = y(30)-(y(11)+y(13));
if nargout >= 2,
  g1 = zeros(45, 63);

  %
  % Jacobian matrix
  %

  g1(1,32)=1;
  g1(1,7)=T197*(-T134);
  g1(2,9)=(-(T205*2*(1-params(5))));
  g1(2,32)=(-1);
  g1(2,35)=1;
  g1(2,36)=(-(1-params(5)));
  g1(2,37)=(-(params(6)*params(23)));
  g1(3,10)=(-(T205*2*params(5)));
  g1(3,31)=1;
  g1(3,32)=1;
  g1(3,34)=1;
  g1(3,36)=(-params(5));
  g1(4,11)=T235*(-2);
  g1(4,13)=T240*(-(2*(1+params(3))));
  g1(4,58)=params(31)*T254;
  g1(4,33)=1;
  g1(4,59)=(-(1-params(4)))*params(31);
  g1(4,37)=(-(params(13)*params(24)));
  g1(4,38)=(-1);
  g1(4,52)=(-1);
  g1(5,39)=(-params(26));
  g1(5,40)=T272;
  g1(5,41)=1;
  g1(5,42)=(-T106);
  g1(6,11)=T240*(-(2*(1+params(3))));
  g1(6,13)=T240*(-((1+params(3))*2*(1+params(3))));
  g1(6,38)=(-params(9));
  g1(6,40)=T297;
  g1(6,42)=params(20)-(params(9)*T106+(1+params(3))*T118);
  g1(6,48)=(-(params(9)-1));
  g1(6,49)=(-params(3));
  g1(6,52)=(-1);
  g1(7,14)=(-(2*params(2)));
  g1(7,37)=(-params(21));
  g1(7,6)=T197*(-(T86*(-params(2))));
  g1(7,40)=(-(T86*params(2)));
  g1(7,7)=T197*(-((-params(2))*T134));
  g1(7,42)=(-(params(2)*T118+params(2)*T134));
  g1(7,49)=(-params(2));
  g1(8,15)=2*T235;
  g1(8,37)=1;
  g1(8,38)=1;
  g1(9,40)=params(20);
  g1(9,41)=(-1);
  g1(9,46)=1;
  g1(9,61)=params(31)*(-params(11));
  g1(9,50)=1;
  g1(9,51)=(-1);
  g1(10,42)=params(20);
  g1(10,44)=1;
  g1(10,46)=(-(1-params(11)));
  g1(11,18)=(-(T205*(-2)));
  g1(11,33)=(-params(4));
  g1(11,34)=(-1);
  g1(11,35)=(-1);
  g1(11,36)=1;
  g1(12,34)=1;
  g1(13,35)=1;
  g1(13,6)=T86*T197;
  g1(13,40)=(-(params(6)/params(19)));
  g1(14,21)=2*(-params(7))/params(27);
  g1(14,5)=T197*(-params(1));
  g1(14,39)=1;
  g1(15,38)=(-1);
  g1(15,40)=T272;
  g1(15,42)=(-T106);
  g1(15,47)=1;
  g1(15,62)=params(31)*(-params(15));
  g1(15,48)=(-1);
  g1(16,42)=T418;
  g1(16,43)=1;
  g1(17,7)=T197*T432;
  g1(17,42)=T429;
  g1(17,43)=(-(1-params(28)));
  g1(17,44)=T158;
  g1(17,45)=(-1);
  g1(17,60)=params(31);
  g1(18,45)=1;
  g1(19,41)=1;
  g1(19,48)=1;
  g1(19,50)=(-1);
  g1(20,44)=(-1);
  g1(20,49)=1;
  g1(20,51)=1;
  g1(21,50)=1;
  g1(22,51)=1;
  g1(23,52)=1;
  g1(24,10)=1;
  g1(24,1)=T254;
  g1(25,8)=1;
  g1(25,9)=(-1);
  g1(25,10)=1;
  g1(26,1)=(-(1-params(4)));
  g1(26,11)=1;
  g1(26,18)=(-params(4));
  g1(27,10)=1;
  g1(27,18)=(-1);
  g1(27,19)=1;
  g1(28,9)=1;
  g1(28,18)=(-1);
  g1(28,20)=1;
  g1(29,9)=(-(1-params(5)));
  g1(29,10)=(-params(5));
  g1(29,18)=1;
  g1(30,9)=(-(params(6)*params(23)));
  g1(30,11)=(-(params(13)*params(24)));
  g1(30,14)=(-params(21));
  g1(30,15)=1;
  g1(31,11)=(-1);
  g1(31,13)=(-params(9));
  g1(31,15)=1;
  g1(31,22)=(-1);
  g1(32,12)=(-params(26));
  g1(32,21)=1;
  g1(32,56)=(-params(1));
  g1(33,12)=T272;
  g1(33,13)=T297;
  g1(33,14)=(-(T86*params(2)));
  g1(33,54)=(-(T86*(-params(2))));
  g1(33,16)=params(20);
  g1(33,20)=(-(params(6)/params(19)));
  g1(33,55)=T86;
  g1(33,22)=T272;
  g1(34,12)=1;
  g1(34,16)=(-1);
  g1(34,26)=1;
  g1(35,53)=(-T134);
  g1(35,12)=(-T106);
  g1(35,13)=params(20)-(params(9)*T106+(1+params(3))*T118);
  g1(35,14)=(-(params(2)*T118+params(2)*T134));
  g1(35,54)=(-((-params(2))*T134));
  g1(35,17)=params(20);
  g1(35,22)=(-T106);
  g1(35,23)=T418;
  g1(35,24)=T429;
  g1(35,57)=T432;
  g1(36,23)=1;
  g1(36,24)=(-(1-params(28)));
  g1(37,17)=1;
  g1(37,24)=T158;
  g1(37,27)=(-1);
  g1(38,4)=1;
  g1(38,24)=(-1);
  g1(38,25)=1;
  g1(39,2)=(-params(11));
  g1(39,16)=1;
  g1(39,17)=(-(1-params(11)));
  g1(40,3)=(-params(15));
  g1(40,22)=1;
  g1(40,63)=(-1);
  g1(41,13)=(-(params(9)-1));
  g1(41,22)=(-1);
  g1(41,26)=1;
  g1(42,13)=(-params(3));
  g1(42,14)=(-params(2));
  g1(42,27)=1;
  g1(43,16)=1;
  g1(43,26)=(-1);
  g1(43,28)=1;
  g1(44,16)=(-1);
  g1(44,27)=1;
  g1(44,29)=1;
  g1(45,11)=(-1);
  g1(45,13)=(-1);
  g1(45,30)=1;
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],45,3969);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],45,250047);
end
end
