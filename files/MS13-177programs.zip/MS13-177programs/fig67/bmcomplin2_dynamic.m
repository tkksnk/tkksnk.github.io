function [residual, g1, g2, g3] = bmcomplin2_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Inputs :
%   y         [#dynamic variables by 1] double    vector of endogenous variables in the order stored
%                                                 in M_.lead_lag_incidence; see the Manual
%   x         [M_.exo_nbr by nperiods] double     matrix of exogenous variables (in declaration order)
%                                                 for all simulation periods
%   params    [M_.param_nbr by 1] double          vector of parameter values in declaration order
%   it_       scalar double                       time period for exogenous variables for which to evaluate the model
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the dynamic model equations in order of 
%                                          declaration of the equations
%   g1        [M_.endo_nbr by #dynamic variables] double    Jacobian matrix of the dynamic model equations;
%                                                           columns: equations in order of declaration
%                                                           rows: variables in order stored in M_.lead_lag_incidence
%   g2        [M_.endo_nbr by (#dynamic variables)^2] double   Hessian matrix of the dynamic model equations;
%                                                              columns: equations in order of declaration
%                                                              rows: variables in order stored in M_.lead_lag_incidence
%   g3        [M_.endo_nbr by (#dynamic variables)^3] double   Third order derivative matrix of the dynamic model equations;
%                                                              columns: equations in order of declaration
%                                                              rows: variables in order stored in M_.lead_lag_incidence
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(25, 1);
T74 = 1/params(13);
residual(1) = y(20)+y(19)*(-params(16));
residual(2) = T74*(-(params(6)*(1+params(3))*2*y(5)))+(-y(28))+y(25)*(-params(3))+y(24)*(-(params(6)-1))+y(18)*(-params(6));
residual(3) = (-(params(2)*2*y(6)))+y(25)*(-params(2))+y(17)*(-params(13));
residual(4) = T74*2*y(7)+y(18)+y(17);
residual(5) = (-y(27))+y(26)+y(22)+(-y(20))+params(19)*y(30)*(-params(7));
residual(6) = y(22)*(-(1-params(7)))-y(21);
residual(7) = (-params(4))/params(17)*2*y(10)+y(19)+params(19)^(-1)*y(3)*(-params(1));
residual(8) = (-y(24))+y(23)+(-y(18))+params(19)*y(31)*(-params(9));
residual(9) = (-y(26))+y(20)+y(24);
residual(10) = y(27)+y(25)+y(21);
residual(11) = y(26);
residual(12) = y(27);
residual(13) = y(28);
residual(14) = y(7)-params(13)*y(6);
residual(15) = y(7)-(y(11)+params(6)*y(5));
residual(16) = y(10)-(params(16)*y(4)+params(1)*y(29));
residual(17) = y(4)+y(12)-y(8);
residual(18) = y(13)-y(9);
residual(19) = y(8)-(params(7)*y(1)+y(9)*(1-params(7)));
residual(20) = y(11)-(params(9)*y(2)+x(it_, 1));
residual(21) = y(12)-(y(11)+y(5)*(params(6)-1));
residual(22) = y(13)-(y(5)*params(3)+y(6)*params(2));
residual(23) = y(14)-(y(12)-y(8));
residual(24) = y(15)-(y(8)-y(13));
residual(25) = y(16)-y(5);
if nargout >= 2,
  g1 = zeros(25, 32);

  %
  % Jacobian matrix
  %

  g1(1,19)=(-params(16));
  g1(1,20)=1;
  g1(2,5)=T74*(-(2*params(6)*(1+params(3))));
  g1(2,18)=(-params(6));
  g1(2,24)=(-(params(6)-1));
  g1(2,25)=(-params(3));
  g1(2,28)=(-1);
  g1(3,6)=(-(2*params(2)));
  g1(3,17)=(-params(13));
  g1(3,25)=(-params(2));
  g1(4,7)=2*T74;
  g1(4,17)=1;
  g1(4,18)=1;
  g1(5,20)=(-1);
  g1(5,22)=1;
  g1(5,30)=params(19)*(-params(7));
  g1(5,26)=1;
  g1(5,27)=(-1);
  g1(6,21)=(-1);
  g1(6,22)=(-(1-params(7)));
  g1(7,10)=2*(-params(4))/params(17);
  g1(7,3)=params(19)^(-1)*(-params(1));
  g1(7,19)=1;
  g1(8,18)=(-1);
  g1(8,23)=1;
  g1(8,31)=params(19)*(-params(9));
  g1(8,24)=(-1);
  g1(9,20)=1;
  g1(9,24)=1;
  g1(9,26)=(-1);
  g1(10,21)=1;
  g1(10,25)=1;
  g1(10,27)=1;
  g1(11,26)=1;
  g1(12,27)=1;
  g1(13,28)=1;
  g1(14,6)=(-params(13));
  g1(14,7)=1;
  g1(15,5)=(-params(6));
  g1(15,7)=1;
  g1(15,11)=(-1);
  g1(16,4)=(-params(16));
  g1(16,10)=1;
  g1(16,29)=(-params(1));
  g1(17,4)=1;
  g1(17,8)=(-1);
  g1(17,12)=1;
  g1(18,9)=(-1);
  g1(18,13)=1;
  g1(19,1)=(-params(7));
  g1(19,8)=1;
  g1(19,9)=(-(1-params(7)));
  g1(20,2)=(-params(9));
  g1(20,11)=1;
  g1(20,32)=(-1);
  g1(21,5)=(-(params(6)-1));
  g1(21,11)=(-1);
  g1(21,12)=1;
  g1(22,5)=(-params(3));
  g1(22,6)=(-params(2));
  g1(22,13)=1;
  g1(23,8)=1;
  g1(23,12)=(-1);
  g1(23,14)=1;
  g1(24,8)=(-1);
  g1(24,13)=1;
  g1(24,15)=1;
  g1(25,5)=(-1);
  g1(25,16)=1;
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],25,1024);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],25,32768);
end
end
