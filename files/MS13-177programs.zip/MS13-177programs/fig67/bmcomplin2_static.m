function [residual, g1, g2] = bmcomplin2_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                    columns: equations in order of declaration
%                                                    rows: variables in declaration order
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: equations in order of declaration
%                                                       rows: variables in declaration order
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 25, 1);

%
% Model equations
%

T16 = 1/params(13);
residual(1) = y(17)+y(16)*(-params(16));
residual(2) = T16*(-(params(6)*(1+params(3))*2*y(2)))+(-y(25))+y(22)*(-params(3))+y(21)*(-(params(6)-1))+y(15)*(-params(6));
residual(3) = (-(params(2)*2*y(3)))+y(22)*(-params(2))+y(14)*(-params(13));
residual(4) = T16*2*y(4)+y(15)+y(14);
residual(5) = (-y(24))+y(23)+y(19)+(-y(17))+params(19)*y(19)*(-params(7));
residual(6) = y(19)*(-(1-params(7)))-y(18);
residual(7) = (-params(4))/params(17)*2*y(7)+y(16)+params(19)^(-1)*y(16)*(-params(1));
residual(8) = (-y(21))+y(20)+(-y(15))+params(19)*y(20)*(-params(9));
residual(9) = (-y(23))+y(17)+y(21);
residual(10) = y(24)+y(22)+y(18);
residual(11) = y(23);
residual(12) = y(24);
residual(13) = y(25);
residual(14) = y(4)-params(13)*y(3);
residual(15) = y(4)-(y(8)+params(6)*y(2));
residual(16) = y(7)-(params(16)*y(1)+y(7)*params(1));
residual(17) = y(1)+y(9)-y(5);
residual(18) = y(10)-y(6);
residual(19) = y(5)-(params(7)*y(5)+(1-params(7))*y(6));
residual(20) = y(8)-(params(9)*y(8)+x(1));
residual(21) = y(9)-(y(8)+y(2)*(params(6)-1));
residual(22) = y(10)-(params(3)*y(2)+params(2)*y(3));
residual(23) = y(11)-(y(9)-y(5));
residual(24) = y(12)-(y(5)-y(10));
residual(25) = y(13)-y(2);
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(25, 25);

  %
  % Jacobian matrix
  %

  g1(1,16)=(-params(16));
  g1(1,17)=1;
  g1(2,2)=T16*(-(2*params(6)*(1+params(3))));
  g1(2,15)=(-params(6));
  g1(2,21)=(-(params(6)-1));
  g1(2,22)=(-params(3));
  g1(2,25)=(-1);
  g1(3,3)=(-(2*params(2)));
  g1(3,14)=(-params(13));
  g1(3,22)=(-params(2));
  g1(4,4)=2*T16;
  g1(4,14)=1;
  g1(4,15)=1;
  g1(5,17)=(-1);
  g1(5,19)=1+params(19)*(-params(7));
  g1(5,23)=1;
  g1(5,24)=(-1);
  g1(6,18)=(-1);
  g1(6,19)=(-(1-params(7)));
  g1(7,7)=2*(-params(4))/params(17);
  g1(7,16)=1+params(19)^(-1)*(-params(1));
  g1(8,15)=(-1);
  g1(8,20)=1+params(19)*(-params(9));
  g1(8,21)=(-1);
  g1(9,17)=1;
  g1(9,21)=1;
  g1(9,23)=(-1);
  g1(10,18)=1;
  g1(10,22)=1;
  g1(10,24)=1;
  g1(11,23)=1;
  g1(12,24)=1;
  g1(13,25)=1;
  g1(14,3)=(-params(13));
  g1(14,4)=1;
  g1(15,2)=(-params(6));
  g1(15,4)=1;
  g1(15,8)=(-1);
  g1(16,1)=(-params(16));
  g1(16,7)=1-params(1);
  g1(17,1)=1;
  g1(17,5)=(-1);
  g1(17,9)=1;
  g1(18,6)=(-1);
  g1(18,10)=1;
  g1(19,5)=1-params(7);
  g1(19,6)=(-(1-params(7)));
  g1(20,8)=1-params(9);
  g1(21,2)=(-(params(6)-1));
  g1(21,8)=(-1);
  g1(21,9)=1;
  g1(22,2)=(-params(3));
  g1(22,3)=(-params(2));
  g1(22,10)=1;
  g1(23,5)=1;
  g1(23,9)=(-1);
  g1(23,11)=1;
  g1(24,5)=(-1);
  g1(24,10)=1;
  g1(24,12)=1;
  g1(25,2)=(-1);
  g1(25,13)=1;
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],25,625);
end
end
