function [residual, g1, g2] = bmeblin2_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                    columns: equations in order of declaration
%                                                    rows: variables in declaration order
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: equations in order of declaration
%                                                       rows: variables in declaration order
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 39, 1);

%
% Model equations
%

T10 = params(28)^(-1);
T23 = (1-params(4))*params(1)*params(10)*params(18)*params(6)/params(19);
T35 = params(6)*params(23)/params(21)/(1-params(5));
T67 = 1/params(21);
T76 = params(9)/params(21)/(1+params(3));
T97 = (-(params(18)*(-(1-params(4)))/params(4)));
T112 = (-(params(10)*params(25)/params(24)));
T117 = (-(params(25)/params(24)));
T143 = params(25)*params(9)*(1-params(10))/params(24)/(1+params(3));
T146 = params(20)-(params(9)*params(10)*params(25)/params(24)+(1+params(3))*T143);
T150 = (-(params(9)*params(25)/params(24)-params(20)));
T175 = params(6)/params(19)*(1-params(4))*params(1);
residual(1) = y(22)+T10*y(32)*(-T23);
residual(2) = (-(T35*(1-params(5))*2*y(2)))+y(27)*(-(params(6)*params(23)))+y(26)*(-(1-params(5)))+y(25)-y(22);
residual(3) = (-(T35*params(5)*2*y(3)))+y(26)*(-params(5))+y(24)+y(22)+y(21);
residual(4) = T67*(-(2*y(4)))+T76*(2*y(4)-2*(y(4)+(1+params(3))*y(6)))+(-y(39))+(-y(28))+y(27)*(-(params(13)*params(24)))+y(23)+params(28)*y(21)*T97+params(28)*y(23)*(-(1-params(4)));
residual(5) = y(32)*T112+y(31)+y(30)*T117+y(29)*(-params(26));
residual(6) = T76*(-((1+params(3))*2*(y(4)+(1+params(3))*y(6))))+(-y(39))+y(36)*(-params(3))+y(35)*(-(params(9)-1))+y(32)*T146+y(30)*T150+y(28)*(-params(9));
residual(7) = (-(params(2)*2*y(7)))+y(36)*(-params(2))+y(32)*(-(T143*params(2)+T23*params(2)))+y(30)*(-(params(2)*T175))+y(27)*(-params(21))+T10*y(30)*(-((-params(2))*T175))+T10*y(32)*(-(T23*(-params(2))));
residual(8) = T67*2*y(8)+y(27)+y(28);
residual(9) = (-y(38))+y(37)+y(33)+y(30)*params(20)+params(28)*y(33)*(-params(11));
residual(10) = y(33)*(-(1-params(11)))+y(32)*params(20);
residual(11) = (-(T35*(-(2*y(11)))))+y(26)+(-y(25))+(-y(24))+y(23)*(-params(4));
residual(12) = y(24);
residual(13) = y(25)+y(30)*(-(params(6)/params(19)))+T10*y(30)*T175;
residual(14) = (-params(7))/params(27)*2*y(14)+y(29)+T10*y(29)*(-params(1));
residual(15) = (-y(35))+y(34)+y(32)*T112+y(30)*T117-y(28)+params(28)*y(34)*(-params(15));
residual(16) = (-y(37))+y(31)+y(35);
residual(17) = y(38)+y(36)-y(31);
residual(18) = y(37);
residual(19) = y(38);
residual(20) = y(39);
residual(21) = y(3)-y(4)*params(18)*(-(1-params(4)))/params(4);
residual(22) = y(1)-(y(2)-y(3));
residual(23) = y(4)-((1-params(4))*y(4)+params(4)*y(11));
residual(24) = y(12)-(y(11)-y(3));
residual(25) = y(13)-(y(11)-y(2));
residual(26) = y(11)-(params(5)*y(3)+(1-params(5))*y(2));
residual(27) = y(8)-(params(21)*y(7)+params(6)*params(23)*y(2)+y(4)*params(13)*params(24));
residual(28) = y(8)-(y(4)+y(15)+params(9)*y(6));
residual(29) = y(14)-(params(26)*y(5)+params(1)*y(14));
residual(30) = params(6)/params(19)*(-y(13))-(params(25)/params(24)*(params(9)*y(6)+y(15)+y(5))-params(20)*(y(6)+y(9))+T175*(-y(13)));
residual(31) = y(5)+y(16)-y(17);
residual(32) = params(20)*(y(6)+y(10))-(params(10)*params(25)/params(24)*(params(9)*y(6)+y(15)+y(5))+T143*((1+params(3))*y(6)+params(2)*y(7))+T23*y(1));
residual(33) = y(9)-(params(11)*y(9)+(1-params(11))*y(10));
residual(34) = y(15)-(params(15)*y(15)+x(1));
residual(35) = y(16)-(y(15)+y(6)*(params(9)-1));
residual(36) = y(17)-(params(2)*y(7)+params(3)*y(6));
residual(37) = y(18)-(y(16)-y(9));
residual(38) = y(19)-(y(9)-y(17));
residual(39) = y(20)-(y(4)+y(6));
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(39, 39);

  %
  % Jacobian matrix
  %

  g1(1,22)=1;
  g1(1,32)=T10*(-T23);
  g1(2,2)=(-(T35*2*(1-params(5))));
  g1(2,22)=(-1);
  g1(2,25)=1;
  g1(2,26)=(-(1-params(5)));
  g1(2,27)=(-(params(6)*params(23)));
  g1(3,3)=(-(T35*2*params(5)));
  g1(3,21)=1;
  g1(3,22)=1;
  g1(3,24)=1;
  g1(3,26)=(-params(5));
  g1(4,4)=T67*(-2);
  g1(4,6)=T76*(-(2*(1+params(3))));
  g1(4,21)=params(28)*T97;
  g1(4,23)=1+params(28)*(-(1-params(4)));
  g1(4,27)=(-(params(13)*params(24)));
  g1(4,28)=(-1);
  g1(4,39)=(-1);
  g1(5,29)=(-params(26));
  g1(5,30)=T117;
  g1(5,31)=1;
  g1(5,32)=T112;
  g1(6,4)=T76*(-(2*(1+params(3))));
  g1(6,6)=T76*(-((1+params(3))*2*(1+params(3))));
  g1(6,28)=(-params(9));
  g1(6,30)=T150;
  g1(6,32)=T146;
  g1(6,35)=(-(params(9)-1));
  g1(6,36)=(-params(3));
  g1(6,39)=(-1);
  g1(7,7)=(-(2*params(2)));
  g1(7,27)=(-params(21));
  g1(7,30)=(-(params(2)*T175))+T10*(-((-params(2))*T175));
  g1(7,32)=(-(T143*params(2)+T23*params(2)))+T10*(-(T23*(-params(2))));
  g1(7,36)=(-params(2));
  g1(8,8)=2*T67;
  g1(8,27)=1;
  g1(8,28)=1;
  g1(9,30)=params(20);
  g1(9,33)=1+params(28)*(-params(11));
  g1(9,37)=1;
  g1(9,38)=(-1);
  g1(10,32)=params(20);
  g1(10,33)=(-(1-params(11)));
  g1(11,11)=(-(T35*(-2)));
  g1(11,23)=(-params(4));
  g1(11,24)=(-1);
  g1(11,25)=(-1);
  g1(11,26)=1;
  g1(12,24)=1;
  g1(13,25)=1;
  g1(13,30)=(-(params(6)/params(19)))+T10*T175;
  g1(14,14)=2*(-params(7))/params(27);
  g1(14,29)=1+T10*(-params(1));
  g1(15,28)=(-1);
  g1(15,30)=T117;
  g1(15,32)=T112;
  g1(15,34)=1+params(28)*(-params(15));
  g1(15,35)=(-1);
  g1(16,31)=1;
  g1(16,35)=1;
  g1(16,37)=(-1);
  g1(17,31)=(-1);
  g1(17,36)=1;
  g1(17,38)=1;
  g1(18,37)=1;
  g1(19,38)=1;
  g1(20,39)=1;
  g1(21,3)=1;
  g1(21,4)=T97;
  g1(22,1)=1;
  g1(22,2)=(-1);
  g1(22,3)=1;
  g1(23,4)=1-(1-params(4));
  g1(23,11)=(-params(4));
  g1(24,3)=1;
  g1(24,11)=(-1);
  g1(24,12)=1;
  g1(25,2)=1;
  g1(25,11)=(-1);
  g1(25,13)=1;
  g1(26,2)=(-(1-params(5)));
  g1(26,3)=(-params(5));
  g1(26,11)=1;
  g1(27,2)=(-(params(6)*params(23)));
  g1(27,4)=(-(params(13)*params(24)));
  g1(27,7)=(-params(21));
  g1(27,8)=1;
  g1(28,4)=(-1);
  g1(28,6)=(-params(9));
  g1(28,8)=1;
  g1(28,15)=(-1);
  g1(29,5)=(-params(26));
  g1(29,14)=1-params(1);
  g1(30,5)=T117;
  g1(30,6)=T150;
  g1(30,9)=params(20);
  g1(30,13)=(-(params(6)/params(19)))-(-T175);
  g1(30,15)=T117;
  g1(31,5)=1;
  g1(31,16)=1;
  g1(31,17)=(-1);
  g1(32,1)=(-T23);
  g1(32,5)=T112;
  g1(32,6)=T146;
  g1(32,7)=(-(T143*params(2)));
  g1(32,10)=params(20);
  g1(32,15)=T112;
  g1(33,9)=1-params(11);
  g1(33,10)=(-(1-params(11)));
  g1(34,15)=1-params(15);
  g1(35,6)=(-(params(9)-1));
  g1(35,15)=(-1);
  g1(35,16)=1;
  g1(36,6)=(-params(3));
  g1(36,7)=(-params(2));
  g1(36,17)=1;
  g1(37,9)=1;
  g1(37,16)=(-1);
  g1(37,18)=1;
  g1(38,9)=(-1);
  g1(38,17)=1;
  g1(38,19)=1;
  g1(39,4)=(-1);
  g1(39,6)=(-1);
  g1(39,20)=1;
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],39,1521);
end
end
