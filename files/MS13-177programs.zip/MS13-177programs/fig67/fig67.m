% fig67.m
%
% This m-file plots Figure 6 and 7 in the paper.
% bmrtmlin2.mod and bmeblin2.mod should be in the same folder.
% Figures are stored in the folder [HOME]/Figures.
%
% October 2014, Takeki Sunakawa

clear all;
% close all;

dynare bmrtmlin2.mod
dynare bmeblin2.mod
dynare bmcomplin2.mod

load irramrtm_lq
theta_path1a = ltheta_ua;
nn_path1a = lna_ua;
ww_path1a = lw_ua;
hh_path1a = lh_ua;
pai_path1a = lpai_ua;
mup_path1a = lmup_ua;
muw_path1a = lmuw_ua;

load irramrtm_rwr_lq
theta_path2a = ltheta_ua;
nn_path2a = lna_ua;
ww_path2a = lw_ua;
hh_path2a = lh_ua;
pai_path2a = lpai_ua;
mup_path2a = lmup_ua;
muw_path2a = lmuw_ua;

load irrameb_lq;
theta_path1b = ltheta_ua;
nn_path1b = lna_ua;
ww_path1b = lw_ua;
hh_path1b = lh_ua;
pai_path1b = lpai_ua;
mup_path1b = lmup_ua;
muw_path1b = lmuw_ua;

load irrameb_rwr_lq
theta_path2b = ltheta_ua;
nn_path2b = lna_ua;
ww_path2b = lw_ua;
hh_path2b = lh_ua;
pai_path2b = lpai_ua;
mup_path2b = lmup_ua;
muw_path2b = lmuw_ua;

load irramcomp_lq;
ww_path1c = lw_ua;
hh_path1c = lh_ua;
pai_path1c = lpai_ua;
mup_path1c = lmup_ua;
muw_path1c = lmuw_ua;

load irramcomp_rwr_lq;
ww_path2c = lw_ua;
hh_path2c = lh_ua;
pai_path2c = lpai_ua;
mup_path2c = lmup_ua;
muw_path2c = lmuw_ua;

T = 31;
time = [0:T-1]';

% Figure 6
figure;

subplot(4,2,1)
plot(time,ww_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,ww_path1b,'b--','LineWidth',2.0);
% plot(time,ww_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Real wages');
ylim([0.0 1.0]);

subplot(4,2,2)
plot(time,theta_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,theta_path1b,'b--','LineWidth',2.0);
% plot([0 T-1],[100 100],'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Labor market tightness');
legend('RTM','EB','Location','NorthEast');
ylim([0.0 5.0]);

subplot(4,2,3)
plot(time,nn_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,nn_path1b,'b--','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Employment');
ylim([0.0 2.0]);

subplot(4,2,4)
plot(time,hh_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,hh_path1b,'b--','LineWidth',2.0);
% plot(time,hh_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Hours per worker');
ylim([-.4 0.0]);

subplot(4,2,5)
plot(time,mup_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,mup_path1b,'b--','LineWidth',2.0);
% plot(time,mup_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Price markup');
ylim([-.5 .5]);

subplot(4,2,6)
plot(time,muw_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,muw_path1b,'b--','LineWidth',2.0);
% plot(time,muw_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Wage markup');
ylim([-0.5 0.5]);

subplot(4,2,7)
plot(time,hh_path1a+nn_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,hh_path1b+nn_path1b,'b--','LineWidth',2.0);
% plot(time,hh_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Hours worked');
ylim([0.0 1.0]);

subplot(4,2,8)
plot(time,pai_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,pai_path1b,'b--','LineWidth',2.0);
% plot(time,pai_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Inflation');
ylim([-0.02 0.02]);

print -depsc2 ../Figures/MS13-177Fig6.eps

% Figure 7
figure;

subplot(3,2,1);
plot(time,muw_path1b+mup_path1b,'m-','LineWidth',2.0);
hold on;
plot(time,mup_path1b,'r:','LineWidth',2.0);
plot(time,muw_path1b,'b-.','LineWidth',2.0);
plot([0 T-1],[0 0],'k-');
ylim([-1.0 1.0]);
title('EB, {\gamma_w}=0');

subplot(3,2,2);
plot(time,muw_path2b+mup_path2b,'m-','LineWidth',2.0);
hold on;
plot(time,mup_path2b,'r:','LineWidth',2.0);
plot(time,muw_path2b,'b-.','LineWidth',2.0);
plot([0 T-1],[0 0],'k-');
ylim([-1.0 1.0]);
title('EB, {\gamma_w}=0.6');
legend('Gap','Price markup','Wage markup');

subplot(3,2,3);
plot(time,muw_path1a+mup_path1a,'m-','LineWidth',2.0);
hold on;
plot(time,mup_path1a,'r:','LineWidth',2.0);
plot(time,muw_path1a,'b-.','LineWidth',2.0);
plot([0 T-1],[0 0],'k-');
ylim([-1.0 1.0]);
title('RTM, {\gamma_w}=0');

subplot(3,2,4);
plot(time,muw_path2a+mup_path2a,'m-','LineWidth',2.0);
hold on;
plot(time,mup_path2a,'r:','LineWidth',2.0);
plot(time,muw_path2a,'b-.','LineWidth',2.0);
plot([0 T-1],[0 0],'k-');
ylim([-4.0 2.0]);
title('RTM, {\gamma_w}=0.9');

subplot(3,2,5);
plot(time,muw_path1c+mup_path1c,'m-','LineWidth',2.0);
hold on;
plot(time,mup_path1c,'r:','LineWidth',2.0);
plot(time,muw_path1c,'b-.','LineWidth',2.0);
plot([0 T-1],[0 0],'k-');
ylim([-0.2 0.2]);
title('Warlasian, {\gamma_w}=0');

subplot(3,2,6);
plot(time,muw_path2c+mup_path2c,'m-','LineWidth',2.0);
hold on;
plot(time,mup_path2c,'r:','LineWidth',2.0);
plot(time,muw_path2c,'b-.','LineWidth',2.0);
plot([0 T-1],[0 0],'k-');
ylim([-4.0 2.0]);
title('Warlasian, {\gamma_w}=0.9');

print -depsc2 ../Figures/MS13-177Fig7.eps