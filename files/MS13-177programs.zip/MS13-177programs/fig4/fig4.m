% fig4.m
%
% This m-file plots Figure 4 in the paper.
% bmrtm2.mod and bmeb2.mod should be in the same folder.
% Figures are stored in the folder [HOME]/Figures.
%
% October 2014, Takeki Sunakawa

clear all;
% close all;

dynare bmrtm2.mod
dynare bmeb2.mod

load irramrtm_ug
theta_path1a = ltheta_ug;
nn_path1a = lna_ug;
ww_path1a = lw_ug;
hh_path1a = lh_ug;
pai_path1a = lpai_ug;
mup_path1a = lmup_ug;
muw_path1a = lmuw_ug;
yy_path1a = ly_ug;
cc_path1a = lc_ug;

load irrameb_ug;
theta_path1b = ltheta_ug;
nn_path1b = lna_ug;
ww_path1b = lw_ug;
hh_path1b = lh_ug;
pai_path1b = lpai_ug;
mup_path1b = lmup_ug;
muw_path1b = lmuw_ug;
yy_path1b = ly_ug;
cc_path1b = lc_ug;

load irrameb_ug_phi100;
theta_path1c = ltheta_ug;
nn_path1c = lna_ug;
ww_path1c = lw_ug;
hh_path1c = lh_ug;
pai_path1c = lpai_ug;
mup_path1c = lmup_ug;
muw_path1c = lmuw_ug;
yy_path1c = ly_ug;
cc_path1c = lc_ug;

T = 31;
time = [0:T-1]';

% Figure 4
figure;

subplot(4,2,1)
plot(time,cc_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,cc_path1b,'b--','LineWidth',2.0);
plot(time,cc_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
ylim([-.2 0]);
title('Consumption');

subplot(4,2,2)
plot(time,nn_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,nn_path1b,'b--','LineWidth',2.0);
plot(time,nn_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
ylim([-.1 .1]);
title('Employment');
legend('RTM','EB','EB (\phi=10^4)','Location','NorthEast');

subplot(4,2,3)
plot(time,hh_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,hh_path1b,'b--','LineWidth',2.0);
plot(time,hh_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
ylim([0 .1]);
title('Hours per worker');

subplot(4,2,4)
plot(time,pai_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,pai_path1b,'b--','LineWidth',2.0);
plot(time,pai_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
ylim([-.01 .01]);
title('Inflation');

subplot(4,2,5)
plot(time,mup_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,mup_path1b,'b--','LineWidth',2.0);
plot(time,mup_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Price markup');
ylim([-0.05 0.05]);

subplot(4,2,6)
plot(time,muw_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,muw_path1b,'b--','LineWidth',2.0);
plot(time,muw_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
title('Wage markup');
ylim([-0.05 0.05]);

subplot(4,2,7)
plot(time,ww_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,ww_path1b,'b--','LineWidth',2.0);
plot(time,ww_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
ylim([-.04 0]);
title('Real wages');

subplot(4,2,8)
plot(time,theta_path1a,'r-','LineWidth',2.0);
hold on;
plot(time,theta_path1b,'b--','LineWidth',2.0);
plot(time,theta_path1c,'m:','LineWidth',2.0);
plot([0 T-1],[0 0],'r-');
xlim([0 T-1]);
ylim([-.5 .5]);
title('Labor market tightness');

print -depsc2 ../Figures/MS13-177Fig4.eps