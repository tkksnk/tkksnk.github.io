Replication files for "Optimal Monetary Policy with Labor Market Frictions: The Role of the Wage Channel."
for publication in Journal of Money, Credit and Banking.

To run the program files (Matlab .m files and Dynare .mod files), you must have Dynare for Matlab, which is available at http://www.dynare.org/.
The program files are checked by the author with Matlab R2012b and Dynare 4.4.2 under Windows 8.1.

To replicate Figures 1-8 in the paper, do the followings:

- Let [HOME] be the folder which contains this readme file.
- Run fig123.m in the folder [HOME]/fig123.  This creates Fig1.eps, Fig2.eps and Fig3.eps in the folder [HOME]/Figures.
- Similarly, run fig4.m in the folder [HOME]/fig4, run fig5.m in the folder [HOME]/fig5, run fig67.m in the folder [HOME]/fig67, and run fig8.m in the folder [HOME]/fig8.
- Each m-file needs dynare .mod files, which are in each folder.

October 2014, Takeki Sunakawa







