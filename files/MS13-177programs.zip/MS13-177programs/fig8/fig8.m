% fig8.m
%
% This m-file plots Figure 8 in the paper.
% bmrtm.mod, bmeb.mod, bmrtmlin.mod and bmeblin.mod should be in the same folder.
% Figures are stored in the folder [HOME]/Figures.
%
% October 2014, Takeki Sunakawa

clear all;

dynare bmrtm.mod
dynare bmeb.mod
dynare bmrtmlin.mod
dynare bmeblin.mod

load bmebpvec_eta_subs;
bveceb = bvec;
pveceb = pvec;

load bmrtmpvec_eta_subs;
bvecrtm = bvec;
pvecrtm = pvec;

load bmeblinpvec_eta_subs;
bveceblin = bvec;
pveceblin = pvec;

load bmrtmlinpvec_eta_subs;
bvecrtmlin = bvec;
pvecrtmlin = pvec;

% Figure 8
figure;

plot(bvecrtm,pvecrtm,'r-','LineWidth',2.0);
hold on;
plot(bveceb,pveceb,'b--','LineWidth',2.0);
plot(bvecrtmlin,pvecrtmlin,'m-','LineWidth',2.0,'Color',[.8 .8 .8]);
plot(bveceblin,pveceblin,'m--','LineWidth',2.0,'Color',[.8 .8 .8]);
plot([eta_star eta_star],[0 0.08],'g-');
xlim([bvec(1) bvec(end)]);
ylim([0 0.08]);
legend('RTM','EB','Location','NorthEast');
xlabel('\eta');
ylabel('\sigma (\pi)');

print -depsc2 ../Figures/MS13-177Fig8.eps