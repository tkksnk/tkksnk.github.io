function [residual, g1, g2, g3] = bmeblin_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Inputs :
%   y         [#dynamic variables by 1] double    vector of endogenous variables in the order stored
%                                                 in M_.lead_lag_incidence; see the Manual
%   x         [M_.exo_nbr by nperiods] double     matrix of exogenous variables (in declaration order)
%                                                 for all simulation periods
%   params    [M_.param_nbr by 1] double          vector of parameter values in declaration order
%   it_       scalar double                       time period for exogenous variables for which to evaluate the model
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the dynamic model equations in order of 
%                                          declaration of the equations
%   g1        [M_.endo_nbr by #dynamic variables] double    Jacobian matrix of the dynamic model equations;
%                                                           columns: equations in order of declaration
%                                                           rows: variables in order stored in M_.lead_lag_incidence
%   g2        [M_.endo_nbr by (#dynamic variables)^2] double   Hessian matrix of the dynamic model equations;
%                                                              columns: equations in order of declaration
%                                                              rows: variables in order stored in M_.lead_lag_incidence
%   g3        [M_.endo_nbr by (#dynamic variables)^3] double   Third order derivative matrix of the dynamic model equations;
%                                                              columns: equations in order of declaration
%                                                              rows: variables in order stored in M_.lead_lag_incidence
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(39, 1);
T86 = params(6)/params(19)*(1-params(4))*params(1);
T115 = params(25)*params(9)*(1-params(10))/params(24)/(1+params(3));
T125 = (1-params(4))*params(1)*params(10)*params(18)*params(6)/params(19);
T162 = params(28)^(-1);
T170 = params(6)*params(23)/params(21)/(1-params(5));
T200 = 1/params(21);
T205 = params(9)/params(21)/(1+params(3));
T219 = (-((-(1-params(4)))/params(4)*params(18)));
T233 = (-(params(25)*params(10)/params(24)));
T237 = (-(params(25)/params(24)));
T258 = params(20)-(params(9)*params(25)*params(10)/params(24)+(1+params(3))*T115);
T262 = (-(params(9)*params(25)/params(24)-params(20)));
residual(1) = y(28)+T162*y(6)*(-T125);
residual(2) = (-(T170*(1-params(5))*2*y(8)))+y(33)*(-(params(6)*params(23)))+y(32)*(-(1-params(5)))+y(31)-y(28);
residual(3) = (-(T170*params(5)*2*y(9)))+y(32)*(-params(5))+y(30)+y(28)+y(27);
residual(4) = T200*(-(2*y(10)))+T205*(2*y(10)-2*(y(10)+y(12)*(1+params(3))))+(-y(45))+(-y(34))+y(33)*(-(params(13)*params(24)))+y(29)+params(28)*y(50)*T219+params(28)*(-(1-params(4)))*y(51);
residual(5) = y(38)*T233+y(37)+y(36)*T237+y(35)*(-params(26));
residual(6) = T205*(-((1+params(3))*2*(y(10)+y(12)*(1+params(3)))))+(-y(45))+y(42)*(-params(3))+y(41)*(-(params(9)-1))+y(38)*T258+y(36)*T262+y(34)*(-params(9));
residual(7) = (-(params(2)*2*y(13)))+(-params(2))*y(42)+y(38)*(-(params(2)*T115+params(2)*T125))+y(36)*(-(T86*params(2)))+y(33)*(-params(21))+T162*y(5)*(-(T86*(-params(2))))+T162*y(6)*(-((-params(2))*T125));
residual(8) = T200*2*y(14)+y(33)+y(34);
residual(9) = (-y(44))+y(43)+y(39)+params(20)*y(36)+params(28)*y(52)*(-params(11));
residual(10) = y(39)*(-(1-params(11)))+params(20)*y(38);
residual(11) = (-(T170*(-(2*y(17)))))+y(32)+(-y(31))+(-y(30))+y(29)*(-params(4));
residual(12) = y(30);
residual(13) = y(31)+y(36)*(-(params(6)/params(19)))+T162*T86*y(5);
residual(14) = (-params(7))/params(27)*2*y(20)+y(35)+T162*y(4)*(-params(1));
residual(15) = (-y(41))+y(40)+y(38)*T233+y(36)*T237-y(34)+params(28)*y(53)*(-params(15));
residual(16) = (-y(43))+y(37)+y(41);
residual(17) = y(44)+y(42)-y(37);
residual(18) = y(43);
residual(19) = y(44);
residual(20) = y(45);
residual(21) = y(9)-(-(1-params(4)))/params(4)*params(18)*y(1);
residual(22) = y(7)-(y(8)-y(9));
residual(23) = y(10)-((1-params(4))*y(1)+params(4)*y(17));
residual(24) = y(18)-(y(17)-y(9));
residual(25) = y(19)-(y(17)-y(8));
residual(26) = y(17)-(y(9)*params(5)+y(8)*(1-params(5)));
residual(27) = y(14)-(params(21)*y(13)+y(8)*params(6)*params(23)+y(10)*params(13)*params(24));
residual(28) = y(14)-(y(10)+y(21)+params(9)*y(12));
residual(29) = y(20)-(params(26)*y(11)+params(1)*y(49));
residual(30) = params(6)/params(19)*(-y(19))-(params(25)/params(24)*(params(9)*y(12)+y(21)+y(11))-params(20)*(y(12)+y(15))+T86*((-params(2))*(y(47)-y(13))-y(48)));
residual(31) = y(11)+y(22)-y(23);
residual(32) = params(20)*(y(12)+y(16))-((params(9)*y(12)+y(21)+y(11))*params(25)*params(10)/params(24)+T115*(y(12)*(1+params(3))+y(13)*params(2))+T125*((-params(2))*(y(47)-y(13))+y(46)));
residual(33) = y(15)-(params(11)*y(2)+y(16)*(1-params(11)));
residual(34) = y(21)-(params(15)*y(3)+x(it_, 1));
residual(35) = y(22)-(y(21)+y(12)*(params(9)-1));
residual(36) = y(23)-(y(13)*params(2)+y(12)*params(3));
residual(37) = y(24)-(y(22)-y(15));
residual(38) = y(25)-(y(15)-y(23));
residual(39) = y(26)-(y(10)+y(12));
if nargout >= 2,
  g1 = zeros(39, 54);

  %
  % Jacobian matrix
  %

  g1(1,28)=1;
  g1(1,6)=T162*(-T125);
  g1(2,8)=(-(T170*2*(1-params(5))));
  g1(2,28)=(-1);
  g1(2,31)=1;
  g1(2,32)=(-(1-params(5)));
  g1(2,33)=(-(params(6)*params(23)));
  g1(3,9)=(-(T170*2*params(5)));
  g1(3,27)=1;
  g1(3,28)=1;
  g1(3,30)=1;
  g1(3,32)=(-params(5));
  g1(4,10)=T200*(-2);
  g1(4,12)=T205*(-(2*(1+params(3))));
  g1(4,50)=params(28)*T219;
  g1(4,29)=1;
  g1(4,51)=(-(1-params(4)))*params(28);
  g1(4,33)=(-(params(13)*params(24)));
  g1(4,34)=(-1);
  g1(4,45)=(-1);
  g1(5,35)=(-params(26));
  g1(5,36)=T237;
  g1(5,37)=1;
  g1(5,38)=T233;
  g1(6,10)=T205*(-(2*(1+params(3))));
  g1(6,12)=T205*(-((1+params(3))*2*(1+params(3))));
  g1(6,34)=(-params(9));
  g1(6,36)=T262;
  g1(6,38)=T258;
  g1(6,41)=(-(params(9)-1));
  g1(6,42)=(-params(3));
  g1(6,45)=(-1);
  g1(7,13)=(-(2*params(2)));
  g1(7,33)=(-params(21));
  g1(7,5)=T162*(-(T86*(-params(2))));
  g1(7,36)=(-(T86*params(2)));
  g1(7,6)=T162*(-((-params(2))*T125));
  g1(7,38)=(-(params(2)*T115+params(2)*T125));
  g1(7,42)=(-params(2));
  g1(8,14)=2*T200;
  g1(8,33)=1;
  g1(8,34)=1;
  g1(9,36)=params(20);
  g1(9,39)=1;
  g1(9,52)=params(28)*(-params(11));
  g1(9,43)=1;
  g1(9,44)=(-1);
  g1(10,38)=params(20);
  g1(10,39)=(-(1-params(11)));
  g1(11,17)=(-(T170*(-2)));
  g1(11,29)=(-params(4));
  g1(11,30)=(-1);
  g1(11,31)=(-1);
  g1(11,32)=1;
  g1(12,30)=1;
  g1(13,31)=1;
  g1(13,5)=T86*T162;
  g1(13,36)=(-(params(6)/params(19)));
  g1(14,20)=2*(-params(7))/params(27);
  g1(14,4)=T162*(-params(1));
  g1(14,35)=1;
  g1(15,34)=(-1);
  g1(15,36)=T237;
  g1(15,38)=T233;
  g1(15,40)=1;
  g1(15,53)=params(28)*(-params(15));
  g1(15,41)=(-1);
  g1(16,37)=1;
  g1(16,41)=1;
  g1(16,43)=(-1);
  g1(17,37)=(-1);
  g1(17,42)=1;
  g1(17,44)=1;
  g1(18,43)=1;
  g1(19,44)=1;
  g1(20,45)=1;
  g1(21,9)=1;
  g1(21,1)=T219;
  g1(22,7)=1;
  g1(22,8)=(-1);
  g1(22,9)=1;
  g1(23,1)=(-(1-params(4)));
  g1(23,10)=1;
  g1(23,17)=(-params(4));
  g1(24,9)=1;
  g1(24,17)=(-1);
  g1(24,18)=1;
  g1(25,8)=1;
  g1(25,17)=(-1);
  g1(25,19)=1;
  g1(26,8)=(-(1-params(5)));
  g1(26,9)=(-params(5));
  g1(26,17)=1;
  g1(27,8)=(-(params(6)*params(23)));
  g1(27,10)=(-(params(13)*params(24)));
  g1(27,13)=(-params(21));
  g1(27,14)=1;
  g1(28,10)=(-1);
  g1(28,12)=(-params(9));
  g1(28,14)=1;
  g1(28,21)=(-1);
  g1(29,11)=(-params(26));
  g1(29,20)=1;
  g1(29,49)=(-params(1));
  g1(30,11)=T237;
  g1(30,12)=T262;
  g1(30,13)=(-(T86*params(2)));
  g1(30,47)=(-(T86*(-params(2))));
  g1(30,15)=params(20);
  g1(30,19)=(-(params(6)/params(19)));
  g1(30,48)=T86;
  g1(30,21)=T237;
  g1(31,11)=1;
  g1(31,22)=1;
  g1(31,23)=(-1);
  g1(32,46)=(-T125);
  g1(32,11)=T233;
  g1(32,12)=T258;
  g1(32,13)=(-(params(2)*T115+params(2)*T125));
  g1(32,47)=(-((-params(2))*T125));
  g1(32,16)=params(20);
  g1(32,21)=T233;
  g1(33,2)=(-params(11));
  g1(33,15)=1;
  g1(33,16)=(-(1-params(11)));
  g1(34,3)=(-params(15));
  g1(34,21)=1;
  g1(34,54)=(-1);
  g1(35,12)=(-(params(9)-1));
  g1(35,21)=(-1);
  g1(35,22)=1;
  g1(36,12)=(-params(3));
  g1(36,13)=(-params(2));
  g1(36,23)=1;
  g1(37,15)=1;
  g1(37,22)=(-1);
  g1(37,24)=1;
  g1(38,15)=(-1);
  g1(38,23)=1;
  g1(38,25)=1;
  g1(39,10)=(-1);
  g1(39,12)=(-1);
  g1(39,26)=1;
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],39,2916);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],39,157464);
end
end
