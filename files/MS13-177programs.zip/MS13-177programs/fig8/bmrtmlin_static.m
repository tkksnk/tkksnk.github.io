function [residual, g1, g2] = bmrtmlin_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                    columns: equations in order of declaration
%                                                    rows: variables in declaration order
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: equations in order of declaration
%                                                       rows: variables in declaration order
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 45, 1);

%
% Model equations
%

T10 = params(31)^(-1);
T23 = (1-params(4))*params(1)*params(28)*params(18)*params(6)/params(19);
T35 = params(6)*params(23)/params(21)/(1-params(5));
T67 = 1/params(21);
T76 = params(9)/params(21)/(1+params(3));
T97 = (-(params(18)*(-(1-params(4)))/params(4)));
T111 = params(28)*params(25)/params(24);
T117 = (-(params(25)/params(24)));
T141 = params(20)*(1-params(28))/(1+params(3));
T148 = (-(params(9)*params(25)/params(24)-params(20)));
T173 = params(6)/params(19)*(1-params(4))*params(1);
T279 = (-(T23+T111+T141*(-(params(28)/(1-params(28))))-params(28)*params(13)));
T291 = (1-params(9))*params(29)/(1-(1-params(9))*(1-params(29)));
residual(1) = y(25)+T10*y(35)*(-T23);
residual(2) = (-(T35*(1-params(5))*2*y(2)))+y(30)*(-(params(6)*params(23)))+y(29)*(-(1-params(5)))+y(28)-y(25);
residual(3) = (-(T35*params(5)*2*y(3)))+y(29)*(-params(5))+y(27)+y(25)+y(24);
residual(4) = T67*(-(2*y(4)))+T76*(2*y(4)-2*(y(4)+(1+params(3))*y(6)))+(-y(45))+(-y(31))+y(30)*(-(params(13)*params(24)))+y(26)+params(31)*y(24)*T97+params(31)*y(26)*(-(1-params(4)));
residual(5) = y(35)*(-T111)+y(34)+y(33)*T117+y(32)*(-params(26));
residual(6) = T76*(-((1+params(3))*2*(y(4)+(1+params(3))*y(6))))+(-y(45))+y(42)*(-params(3))+y(41)*(-(params(9)-1))+y(35)*(params(20)-(params(9)*T111+(1+params(3))*T141))+y(33)*T148+y(31)*(-params(9));
residual(7) = (-(params(2)*2*y(7)))+y(42)*(-params(2))+y(35)*(-(T141*params(2)+T23*params(2)))+y(33)*(-(params(2)*T173))+y(30)*(-params(21))+T10*y(33)*(-((-params(2))*T173))+T10*y(35)*(-(T23*(-params(2))));
residual(8) = T67*2*y(8)+y(30)+y(31);
residual(9) = (-y(44))+y(43)+y(39)+(-y(34))+y(33)*params(20)+params(31)*y(39)*(-params(11));
residual(10) = y(39)*(-(1-params(11)))+y(37)+y(35)*params(20);
residual(11) = (-(T35*(-(2*y(11)))))+y(29)+(-y(28))+(-y(27))+y(26)*(-params(4));
residual(12) = y(27);
residual(13) = y(28)+y(33)*(-(params(6)/params(19)))+T10*y(33)*T173;
residual(14) = (-params(7))/params(27)*2*y(14)+y(32)+T10*y(32)*(-params(1));
residual(15) = (-y(41))+y(40)+y(35)*(-T111)+y(33)*T117-y(31)+params(31)*y(40)*(-params(15));
residual(16) = y(36)+y(35)*T279;
residual(17) = (-y(38))+y(37)*T291+y(36)*(-(1-params(28)))+y(35)*(-(T23*(-(1-1/params(18)))))+T10*y(35)*(-(T23*(1-1/params(18))))+params(31)*y(38);
residual(18) = y(38);
residual(19) = (-y(43))+y(34)+y(41);
residual(20) = y(44)+y(42)-y(37);
residual(21) = y(43);
residual(22) = y(44);
residual(23) = y(45);
residual(24) = y(3)-y(4)*params(18)*(-(1-params(4)))/params(4);
residual(25) = y(1)-(y(2)-y(3));
residual(26) = y(4)-((1-params(4))*y(4)+params(4)*y(11));
residual(27) = y(12)-(y(11)-y(3));
residual(28) = y(13)-(y(11)-y(2));
residual(29) = y(11)-(params(5)*y(3)+(1-params(5))*y(2));
residual(30) = y(8)-(params(21)*y(7)+params(6)*params(23)*y(2)+y(4)*params(13)*params(24));
residual(31) = y(8)-(y(4)+y(15)+params(9)*y(6));
residual(32) = y(14)-(params(26)*y(5)+params(1)*y(14));
residual(33) = params(6)/params(19)*(-y(13))-(params(25)/params(24)*(params(9)*y(6)+y(15)+y(5))-params(20)*(y(6)+y(9))+T173*(-y(13)));
residual(34) = y(5)+y(19)-y(9);
residual(35) = params(20)*(y(6)+y(10))-(T111*(params(9)*y(6)+y(15)+y(5)+y(16))+T141*((1+params(3))*y(6)+params(2)*y(7)-params(28)/(1-params(28))*y(16))-params(28)*params(13)*y(16)+T23*(y(1)+y(16)));
residual(36) = y(16)-(1-params(28))*y(17);
residual(37) = y(10)-(y(20)-T291*y(17));
residual(38) = y(18);
residual(39) = y(9)-(params(11)*y(9)+(1-params(11))*y(10));
residual(40) = y(15)-(params(15)*y(15)+x(1));
residual(41) = y(19)-(y(15)+y(6)*(params(9)-1));
residual(42) = y(20)-(params(2)*y(7)+params(3)*y(6));
residual(43) = y(21)-(y(19)-y(9));
residual(44) = y(22)-(y(9)-y(20));
residual(45) = y(23)-(y(4)+y(6));
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(45, 45);

  %
  % Jacobian matrix
  %

  g1(1,25)=1;
  g1(1,35)=T10*(-T23);
  g1(2,2)=(-(T35*2*(1-params(5))));
  g1(2,25)=(-1);
  g1(2,28)=1;
  g1(2,29)=(-(1-params(5)));
  g1(2,30)=(-(params(6)*params(23)));
  g1(3,3)=(-(T35*2*params(5)));
  g1(3,24)=1;
  g1(3,25)=1;
  g1(3,27)=1;
  g1(3,29)=(-params(5));
  g1(4,4)=T67*(-2);
  g1(4,6)=T76*(-(2*(1+params(3))));
  g1(4,24)=params(31)*T97;
  g1(4,26)=1+params(31)*(-(1-params(4)));
  g1(4,30)=(-(params(13)*params(24)));
  g1(4,31)=(-1);
  g1(4,45)=(-1);
  g1(5,32)=(-params(26));
  g1(5,33)=T117;
  g1(5,34)=1;
  g1(5,35)=(-T111);
  g1(6,4)=T76*(-(2*(1+params(3))));
  g1(6,6)=T76*(-((1+params(3))*2*(1+params(3))));
  g1(6,31)=(-params(9));
  g1(6,33)=T148;
  g1(6,35)=params(20)-(params(9)*T111+(1+params(3))*T141);
  g1(6,41)=(-(params(9)-1));
  g1(6,42)=(-params(3));
  g1(6,45)=(-1);
  g1(7,7)=(-(2*params(2)));
  g1(7,30)=(-params(21));
  g1(7,33)=(-(params(2)*T173))+T10*(-((-params(2))*T173));
  g1(7,35)=(-(T141*params(2)+T23*params(2)))+T10*(-(T23*(-params(2))));
  g1(7,42)=(-params(2));
  g1(8,8)=2*T67;
  g1(8,30)=1;
  g1(8,31)=1;
  g1(9,33)=params(20);
  g1(9,34)=(-1);
  g1(9,39)=1+params(31)*(-params(11));
  g1(9,43)=1;
  g1(9,44)=(-1);
  g1(10,35)=params(20);
  g1(10,37)=1;
  g1(10,39)=(-(1-params(11)));
  g1(11,11)=(-(T35*(-2)));
  g1(11,26)=(-params(4));
  g1(11,27)=(-1);
  g1(11,28)=(-1);
  g1(11,29)=1;
  g1(12,27)=1;
  g1(13,28)=1;
  g1(13,33)=(-(params(6)/params(19)))+T10*T173;
  g1(14,14)=2*(-params(7))/params(27);
  g1(14,32)=1+T10*(-params(1));
  g1(15,31)=(-1);
  g1(15,33)=T117;
  g1(15,35)=(-T111);
  g1(15,40)=1+params(31)*(-params(15));
  g1(15,41)=(-1);
  g1(16,35)=T279;
  g1(16,36)=1;
  g1(17,35)=(-(T23*(-(1-1/params(18)))))+T10*(-(T23*(1-1/params(18))));
  g1(17,36)=(-(1-params(28)));
  g1(17,37)=T291;
  g1(17,38)=(-1)+params(31);
  g1(18,38)=1;
  g1(19,34)=1;
  g1(19,41)=1;
  g1(19,43)=(-1);
  g1(20,37)=(-1);
  g1(20,42)=1;
  g1(20,44)=1;
  g1(21,43)=1;
  g1(22,44)=1;
  g1(23,45)=1;
  g1(24,3)=1;
  g1(24,4)=T97;
  g1(25,1)=1;
  g1(25,2)=(-1);
  g1(25,3)=1;
  g1(26,4)=1-(1-params(4));
  g1(26,11)=(-params(4));
  g1(27,3)=1;
  g1(27,11)=(-1);
  g1(27,12)=1;
  g1(28,2)=1;
  g1(28,11)=(-1);
  g1(28,13)=1;
  g1(29,2)=(-(1-params(5)));
  g1(29,3)=(-params(5));
  g1(29,11)=1;
  g1(30,2)=(-(params(6)*params(23)));
  g1(30,4)=(-(params(13)*params(24)));
  g1(30,7)=(-params(21));
  g1(30,8)=1;
  g1(31,4)=(-1);
  g1(31,6)=(-params(9));
  g1(31,8)=1;
  g1(31,15)=(-1);
  g1(32,5)=(-params(26));
  g1(32,14)=1-params(1);
  g1(33,5)=T117;
  g1(33,6)=T148;
  g1(33,9)=params(20);
  g1(33,13)=(-(params(6)/params(19)))-(-T173);
  g1(33,15)=T117;
  g1(34,5)=1;
  g1(34,9)=(-1);
  g1(34,19)=1;
  g1(35,1)=(-T23);
  g1(35,5)=(-T111);
  g1(35,6)=params(20)-(params(9)*T111+(1+params(3))*T141);
  g1(35,7)=(-(T141*params(2)));
  g1(35,10)=params(20);
  g1(35,15)=(-T111);
  g1(35,16)=T279;
  g1(36,16)=1;
  g1(36,17)=(-(1-params(28)));
  g1(37,10)=1;
  g1(37,17)=T291;
  g1(37,20)=(-1);
  g1(38,18)=1;
  g1(39,9)=1-params(11);
  g1(39,10)=(-(1-params(11)));
  g1(40,15)=1-params(15);
  g1(41,6)=(-(params(9)-1));
  g1(41,15)=(-1);
  g1(41,19)=1;
  g1(42,6)=(-params(3));
  g1(42,7)=(-params(2));
  g1(42,20)=1;
  g1(43,9)=1;
  g1(43,19)=(-1);
  g1(43,21)=1;
  g1(44,9)=(-1);
  g1(44,20)=1;
  g1(44,22)=1;
  g1(45,4)=(-1);
  g1(45,6)=(-1);
  g1(45,23)=1;
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],45,2025);
end
end
