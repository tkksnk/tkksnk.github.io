Replication files for "A Quantitative Analysis of Optimal Sustainable Monetary Policies."
for publication in Journal of Economic Dynamics and Control.

The program files are checked by the author with Matlab R2014a under MS Windows 7.

To replicate Figures 2-5 and Tables 2-4 in the paper, do the followings:

- Let [HOME] be the folder which contains this readme file.

- Run Fig2345.m in the folder [HOME]/Fig2345.  This creates Fig2.eps, Fig3a.eps, Fig3b.eps, Fig4.eps and Fig5.eps in the folder [HOME]/Figures.

- Run Table2.m in the folder [HOME]/Table2.  This creates Table2.xls in the folder [HOME]/Tables.

- To create Table 3 and 4, first run runpf.m in the folder [HOME]/Table34. 
This computes the policy functions for each alternative parameters.  Then run Table3.m and Table4.m, which creates Table3.xls and Table4.xls in the folder [HOME]/Tables.
Note that it takes about half an hour in total.

December 2014, Takeki Sunakawa