% commitment policy
b1 = ((1+bet+kap^2/lam)+((1+bet+kap^2/lam)^2-4*bet)^.5)/2/bet;
b2 = ((1+bet+kap^2/lam)-((1+bet+kap^2/lam)^2-4*bet)^.5)/2/bet;
cpu = 1/(bet*(b1-rho));
cxu = -kap/lam*cpu;
cpx = lam/kap*(1-b2);
cxx = b2;
% discretionary policy
dpu = 1/(1-bet*rho+kap^2/lam);
dxu = -kap/lam*dpu;

sig2u = sig^2/(1-rho^2);
sig2pd = dpu^2*sig2u;
sig2xd = dxu^2*sig2u;
sig2xc = cxu^2*sig2u/(1-cxx^2)*(1+rho*cxx)/(1-rho*cxx);
sig2pc = cpx^2*sig2xc + cpu^2*sig2u ...
    + 2*sig2u*rho*(cpu*cpx*cxu+cxx/(1-cxx^2))/(1-rho*cxx);