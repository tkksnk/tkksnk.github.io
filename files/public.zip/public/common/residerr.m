% check the error by residual function
disp(' ');
disp(' computing approximation errors...');
nb = 201;
Bgrid = linspace(Xgrid(1),Xgrid(end),nb);
% nb = nx;
% Bgrid = Xgrid;

Resid1abs = zeros(nb,nu);
Resid2abs = zeros(nb,nu);
Resid3abs = zeros(nb,nu);
Resid1rel = zeros(nb,nu);
Resid2rel = zeros(nb,nu);
Resid3rel = zeros(nb,nu);

pcond = PI*pmats;
vcond = PI*vmats;

for iu = 1:nu

    pvec = pcond(iu,:)';
    vvec = vcond(iu,:)';        
    cp = spfit(invT,pvec,r,Xgrid);    
    cv = spfit(invT,vvec,r,Xgrid);
    unow = Ugrid(iu);
    
    for ib = 1:nb

        xpast = Bgrid(ib);

        % linear interpolation
%         p1 = interp2(Xgrid,Ugrid,pmats,xpast,unow);
%         x1 = interp2(Xgrid,Ugrid,xmats,xpast,unow);
%         v1 = interp2(Xgrid,Ugrid,vmats,xpast,unow);
%         z1 = interp2(Xgrid,Ugrid,zmats,xpast,unow);
        p1 = intf2(pmats,unow,xpast,Ugrid,Xgrid);
        x1 = intf2(xmats,unow,xpast,Ugrid,Xgrid);
        v1 = intf2(vmats,unow,xpast,Ugrid,Xgrid);
        z1 = intf2(zmats,unow,xpast,Ugrid,Xgrid);
        
        Resid1abs(ib,iu) = abs(-v1 - (p1^2 + lam*x1^2) + bet*speva(cv,x1,r,Xgrid));
        Resid2abs(ib,iu) = abs(-p1 + kap*x1 + unow + bet*speva(cp,x1,r,Xgrid));
        Resid3abs(ib,iu) = abs(-x1 - (kap/lam)*p1 + z1*xpast);
        Resid1rel(ib,iu) = Resid1abs(ib,iu)/abs(v1);
        Resid2rel(ib,iu) = Resid2abs(ib,iu)/(1+abs(p1)); % p1 can be zero!
        Resid3rel(ib,iu) = Resid3abs(ib,iu)/(1+abs(x1));
        
    end
    
end

err1abs = max(max(Resid1abs));
err2abs = max(max(Resid2abs));
err3abs = max(max(Resid3abs));
err1rel = max(max(Resid1rel));
err2rel = max(max(Resid2rel));
err3rel = max(max(Resid3rel));

disp([err1abs err2abs err3abs]);
disp([err1rel err2rel err3rel]);