% Program for "Computing Optimal Sustainable Monetary Policy"
% This version: December 2014
% Takeki Sunakawa
%
% mainsp.m: main program to compute policy functions (using spline)

bet = 0.99;
kap = 0.001;
lam = 0.01;
rho = 0.0;

sig = 0.154;
m   = 6;
k   = 6;
nu  = 31;
nx  = 15;

ansol;

[Ugrid PI] = mytauchen(nu,0,rho,sig,m);
xmax = k*sig2xc^.5;
Xgrid = linspace(-xmax,xmax,nx)';

% setup spline
r = nx-2;
invT = inv(spbas(r,Xgrid));

% discretion value
A1 = (1+kap^2/lam)*eye(nu)-bet*PI;
B1 = Ugrid;
pvecd = A1\B1;
C1 = eye(nu)-bet*PI;
D1 = -(1+kap^2/lam)*pvecd.^2;
wvecd = C1\D1;

% initial values
xmat0 = zeros(nu,nx);
pmat0 = zeros(nu,nx);
vmat0 = zeros(nu,nx);
zmat0 = ones(nu,nx);
xmat1 = zeros(nu,nx);
pmat1 = zeros(nu,nx);
vmat1 = zeros(nu,nx);
zmat1 = ones(nu,nx);

crit = 1e-5;
diff = 1e+4;
iter = 0;
hopt = 0;

t = cputime;
disp(' ');
disp(' computing commitment policy...');

% for i = 1:1
while (diff>crit)

    [pmat1,xmat1,vmat1] = comm_iter(pmat0,xmat0,vmat0,invT,Ugrid,PI,Xgrid,bet,kap,lam,hopt);
    
    % update
    gdiff = max(max(abs(pmat1-pmat0)));
    vdiff = max(max(abs(vmat1-vmat0)));
    diff = max(gdiff,vdiff);
    iter = iter+1;
    pmat0 = pmat1;
    xmat0 = xmat1;
    vmat0 = vmat1;
    
    % diagnosis
    s = sprintf( ' iteration %4d:    ||v1-v0|| = %10.5f,  ||g1-g0|| = %10.5f', ...
    iter, vdiff, gdiff);
    disp(s)

%     % howard improvement algorithm
%     if (gdiff<1e-4 && hopt==0)
%         hopt = 1;
%     elseif (hopt>0 && hopt<20)
%         hopt = hopt+1;
%     elseif (hopt>=20)
%         hopt = 0;
%     end
    
end;

disp(' value function converged.');
pmatc = pmat0;
xmatc = xmat0;
vmatc = vmat0;

vmat0 = .75*vmatc;
crit = 1e-5;
diff = 1e+4;
iter = 0;
h = figure;

disp(' ');
disp(' computing sustainable policy...');

while (diff>crit)

    [pmat1,xmat1,vmat1,zmat1] = sus_iter(pmat0,xmat0,vmat0,zmat0,invT,Ugrid,PI,Xgrid,bet,kap,lam,wvecd);
    
    % update
    gdiff = max(max(abs(pmat1-pmat0)));
    vdiff = max(max(abs(vmat1-vmat0)));
    diff = max(gdiff,vdiff);
    iter = iter+1;
    pmat0 = pmat1;
    xmat0 = xmat1;
    vmat0 = vmat1;
    zmat0 = zmat1;
    
    % diagnosis
    s = sprintf( ' iteration %4d:    ||v1-v0|| = %10.5f,  ||g1-g0|| = %10.5f', ...
    iter, vdiff, gdiff);
    disp(s)
    
    figure(h);
    mesh(Ugrid,Xgrid,zmat0');
    
end;

elapsed_time = cputime-t;
disp(sprintf( ' value function converged. Elapsed time = %10.5f', elapsed_time));

vmats = vmat0;
pmats = pmat0;
xmats = xmat0;
zmats = zmat0;