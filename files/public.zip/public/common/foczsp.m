function f = foczsp(x0,cp,cv,unow,xpast,wd,Xgrid,bet,kap,lam)

r = length(Xgrid)-2;

ep = speva(cp,x0,r,Xgrid);
ev = speva(cv,x0,r,Xgrid);
p0 = kap.*x0 + unow + bet.*ep;
f = -wd - (p0.^2 + lam.*x0.^2) + bet.*ev;