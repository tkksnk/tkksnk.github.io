function f0 = focsp(xx0,cp,unow,xpast,Xgrid,bet,kap,lam)

r = length(Xgrid)-2;

x0 = xx0(1);

ep = speva(cp,x0,r,Xgrid);
p0 = -lam/kap.*(x0-xpast);
f0 = -p0 + bet.*ep + kap.*x0 + unow;