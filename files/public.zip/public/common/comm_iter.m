function [pmat1 xmat1 vmat1] = comm_iter(pmat0,xmat0,vmat0,invT,Ugrid,PI,Xgrid,bet,kap,lam)

nu = size(Ugrid,1);
nx = size(Xgrid,1);
r = nx-2;

pcond = PI*pmat0;
vcond = PI*vmat0;

for iu=1:nu

    pvec = pcond(iu,:)';
    vvec = vcond(iu,:)';        
    cp = spfit(invT,pvec,r,Xgrid);
    cv = spfit(invT,vvec,r,Xgrid);

    for ix=1:nx

        unow = Ugrid(iu);
        xpast = Xgrid(ix);
        xx0 = xmat0(iu,ix);

%         if (hopt==0)
            [x1 rc] = csolve(@focsp,xx0,[],1e-6,100,cp,unow,xpast,Xgrid,bet,kap,lam);
%            rc
%         else
%             x1 = xmat0(iu,ix);
%         end

        p1 = -lam/kap.*(x1-xpast);
        v1 = -(p1^2 + lam*x1^2) + bet*speva(cv,x1,r,Xgrid);                  

        xmat1(iu,ix) = x1;
        pmat1(iu,ix) = p1;
        vmat1(iu,ix) = v1;

    end

end