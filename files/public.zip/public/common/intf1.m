function tem1 = intf1(mat,xn,xgrid)
% 1-dim linear interpolation
ngpx = length(xgrid);

% for xn
if (xn<=xgrid(1))
    ixl = 1;
elseif (xn>=xgrid(ngpx))
    ixl = ngpx-1;
else
    n = 2;
    while (n<=ngpx)

        if (xn<xgrid(n))
            ixl=n-1;
            n=ngpx;
        end

    n=n+1;
    end
end

etax = (xn-xgrid(ixl))/(xgrid(ixl+1)-xgrid(ixl));
tem1 = (1-etax)*mat(ixl) + etax*mat(ixl+1);