function tem3 = intf2(mat,xn,zn,xgrid,zgrid)
% 2-dim linear interpolation
ngpx = length(xgrid);
ngpz = length(zgrid);

% for xn
if (xn<=xgrid(1))
    ixl = 1;
elseif (xn>=xgrid(ngpx))
    ixl = ngpx-1;
else
    n = 2;
    while (n<=ngpx)

        if (xn<xgrid(n))
            ixl=n-1;
            n=ngpx;
        end

    n=n+1;
    end
end

% for zn
if (zn<=zgrid(1))
    izl = 1;
elseif (zn>=zgrid(ngpz))
    izl = ngpz-1;
else
    n = 2;
    while (n<=ngpz)

        if (zn<zgrid(n))
            izl=n-1;
            n=ngpz;
        end

    n=n+1;
    end
end

etax = (xn-xgrid(ixl))/(xgrid(ixl+1)-xgrid(ixl));
etaz = (zn-zgrid(izl))/(zgrid(izl+1)-zgrid(izl));
tem1 = (1-etaz)*mat(ixl,izl) + etaz*mat(ixl,izl+1);
tem2 = (1-etaz)*mat(ixl+1,izl) + etaz*mat(ixl+1,izl+1);
tem3 = (1-etax)*tem1 + etax*tem2;