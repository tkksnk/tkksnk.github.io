function [pmat1,xmat1,vmat1,zmat1] = sus_iter(pmat0,xmat0,vmat0,zmat0,invT,Ugrid,PI,Xgrid,bet,kap,lam,wvecd)

nu = size(Ugrid,1);
nx = size(Xgrid,1);
r = nx-2;

pcond = PI*pmat0;
vcond = PI*vmat0;

for iu=1:nu

    wd = wvecd(iu);
    pvec = pcond(iu,:)';
    vvec = vcond(iu,:)';        
    cp = spfit(invT,pvec,r,Xgrid);
    cv = spfit(invT,vvec,r,Xgrid);

    for ix=1:nx

        unow = Ugrid(iu);
        xpast = Xgrid(ix);
        x0 = xmat0(iu,ix);
        
        if (vmat0(iu,ix)>wd)

            [x1 rc] = csolve(@focsp,x0,[],1e-6,100,cp,unow,xpast,Xgrid,bet,kap,lam);
            p1 = -lam/kap.*(x1-xpast);
            z1 = 1;
            ev = speva(cv,x1,r,Xgrid);
            w1 = -(p1^2 + lam*x1^2) + bet*speva(cv,x1,r,Xgrid);                  

        else

            [x1 rc] = csolve(@foczsp,x0,[],1e-6,100,cp,cv,unow,xpast,wd,Xgrid,bet,kap,lam);
            p1 = kap*x1 + unow + bet*speva(cp,x1,r,Xgrid);
            z1 = (x1+kap/lam*p1)/xpast;
            w1 = wd;

            % if the solution is ill, keep previous one
            if (z1<1e-4 || z1>1 || rc~=0)

                x1 = xmat0(iu,ix);
                p1 = pmat0(iu,ix);
                z1 = zmat0(iu,ix);

            end

        end

        xmat1(iu,ix) = x1;
        pmat1(iu,ix) = p1;
        vmat1(iu,ix) = w1;
        zmat1(iu,ix) = z1;

    end

end