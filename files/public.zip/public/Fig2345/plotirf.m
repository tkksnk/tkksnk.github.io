% Program for "Computing Optimal Sustainable Monetary Policy"
% This version: December 2014
% Takeki Sunakawa
%
% plotirf.m: plot impulse responce functions and policy functions


T = 6;
% initial values
uinit = 5*sig;
xinit = 0;

psvec = zeros(T+2,1);
xsvec = zeros(T+2,1);
zsvec = ones(T+2,1);
pcvec = zeros(T+2,1);
xcvec = zeros(T+2,1);
pdvec = zeros(T+2,1);
xdvec = zeros(T+2,1);
uvec  = zeros(T+2,1);

uvec(1) = uinit;
xsvec(1) = xinit;
xcvec(1) = xinit;
xdvec(1) = xinit;

for t=1:T+1

    psvec(t+1) = intf2(pmats,uvec(t),xsvec(t),Ugrid,Xgrid);
    xsvec(t+1) = intf2(xmats,uvec(t),xsvec(t),Ugrid,Xgrid);
    zsvec(t+1) = intf2(zmats,uvec(t),xsvec(t),Ugrid,Xgrid);
    pcvec(t+1) = intf2(pmatc,uvec(t),xcvec(t),Ugrid,Xgrid);
    xcvec(t+1) = intf2(xmatc,uvec(t),xcvec(t),Ugrid,Xgrid);
    pdvec(t+1) = intf1(pvecd,uvec(t),Ugrid);
    xdvec(t+1) = -kap/lam*pdvec(t+1);
   
end;

uvec = [0;uvec(1:T+1)];

% Figure 2
figure;
subplot(221);
plot([-1:T],xsvec,'bo-','LineWidth',2.0);
hold on;
plot([-1:T],xcvec,'gx-','LineWidth',2.0);
plot([-1:T],xdvec,'r+-','LineWidth',2.0);
title('Output gap');
xlim([-1 T]);
legend('quasi-sustainable','time-0 commitment','discretion','Location','SouthEast');
subplot(222);
plot([-1:T],zsvec,'bo-','LineWidth',2.0);
title('\Psi_{t-1}/\Psi_{t}');
xlim([-1 T]);
subplot(223);
plot([-1:T],4*psvec,'bo-','LineWidth',2.0);
hold on;
plot([-1:T],4*pcvec,'gx-','LineWidth',2.0);
plot([-1:T],4*pdvec,'r+-','LineWidth',2.0);
title('Inflation rate');
xlim([-1 T]);
subplot(224);
plot([-1:T],4*uvec,'m-','LineWidth',2.0);
title('Mark-up shock');
xlim([-1 T]);

print -depsc2 Fig2.eps;

% Figure 3.a
figure;
% colormap hsv;
% alpha(.25);
mesh(Ugrid,Xgrid,zmats');
hidden off;
xlabel('u'); 
ylabel('x_{-1}');
zlabel('z(u,x_{-1})');
xlim([Ugrid(1) Ugrid(end)]);
ylim([Xgrid(1) Xgrid(end)]);
hold on;
plot3(uvec(1:T),[0; xsvec(1:T-1)],zsvec(1:T),'bo-','LineWidth',2.0);
view(55,70);
text(uvec(1),0,zsvec(1),'t=-1',...
'HorizontalAlignment','left','VerticalAlignment','bottom','FontSize',16);
text(uvec(2),xsvec(1),zsvec(2),'t=0',...
'HorizontalAlignment','left','VerticalAlignment','bottom','FontSize',16);
text(uvec(3),xsvec(2),zsvec(3),'t=1',...
'HorizontalAlignment','right','VerticalAlignment','top','FontSize',16);

print -depsc2 Fig3a.eps;

% Figure 3.b
% analytical solution: social welfare
D = (cpx^2 + lam*cxx^2)/(1-bet*cxx^2);
F = D*bet*cxu^2 + cpu^2 + lam*cxu^2;
vmatc_exact = zeros(nu,nx);
vmatd_exact = zeros(nu,nx);

for iu = 1:nu
    
    for ix = 1:nx
        
        u0 = Ugrid(iu);
        x0 = Xgrid(ix);
        Duu = 1/(1-bet*rho^2)*(u0^2 + (bet/(1-bet))*sig^2);
        vmatc_exact(iu,ix) = -(D*x0^2 + F*Duu);
        vmatd_exact(iu,ix) = -(dpu^2 + lam*dxu^2)*Duu;
        
    end
    
end

figure;
% colormap hsv;
% alpha(.25);
mesh(Ugrid,Xgrid,-max((vmatc_exact./vmatd_exact-1)',0));
hidden off;
xlabel('u'); 
ylabel('x_{-1}');
zlabel('-max(V^{c}(u,x_{-1})/W^{d}(u)-1,0)');
xlim([Ugrid(1) Ugrid(end)]);
ylim([Xgrid(1) Xgrid(end)]);
zlim([-1.5 0]);
view(55,70);
hold on;
plot3(uvec(1:T),[0; xsvec(1:T-1)],zsvec(1:T)-1,'bo-','LineWidth',2.0);
text(uvec(1),0,zsvec(1)-1,'t=-1',...
'HorizontalAlignment','left','VerticalAlignment','bottom','FontSize',16);
text(uvec(2),xsvec(1),zsvec(2)-1,'t=0',...
'HorizontalAlignment','left','VerticalAlignment','bottom','FontSize',16);
text(uvec(3),xsvec(2),zsvec(3)-1,'t=1',...
'HorizontalAlignment','right','VerticalAlignment','top','FontSize',16);

print -depsc2 Fig3b.eps;

% Figure 4
midx = ceil(nx/2);

figure;
subplot(211);
plot(Ugrid,pmats(:,midx),'bo-','LineWidth',2.0);
hold on;
plot(Ugrid,cpu*Ugrid,'gx-','LineWidth',2.0);
plot(Ugrid,dpu*Ugrid,'r+-','LineWidth',2.0);
plot([Ugrid(1) Ugrid(end)],[0 0],'k:');
xlabel('u');
ylabel('\pi(u,0)');
xlim([Ugrid(1) Ugrid(end)]);
ylim([-0.8 0.8]);
legend('quasi-sustainable','time-0 commitment','discretion','Location','NorthWest');

subplot(212);
plot(Ugrid,xmats(:,midx),'bo-','LineWidth',2.0);
hold on;
plot(Ugrid,cxu*Ugrid,'gx-','LineWidth',2.0);
plot(Ugrid,dxu*Ugrid,'r+-','LineWidth',2.0);
plot([Ugrid(1) Ugrid(end)],[0 0],'k:');
xlabel('u');
ylabel('x(u,0)');
xlim([Ugrid(1) Ugrid(end)]);
ylim([-8 8]);

print -depsc2 Fig4.eps;