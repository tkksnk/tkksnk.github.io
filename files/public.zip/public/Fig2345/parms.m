bet = 0.9;
kap = 0.024;
lam = 0.003;
rho = 0.0;

sig = 0.154;
m   = 6;
k   = 6;
nu  = 31;
nx  = 15;