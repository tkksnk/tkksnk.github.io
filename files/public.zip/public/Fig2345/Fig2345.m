% replicate the case of bet = 0.9 in Figures 2-5 in the paper
clear all;
close all;

addpath(strcat(pwd,'/../common/'));

parms;
ansol;
mainsp;
save wmats_bet0.9.mat bet kap lam rho sig m k nu nx vmats pmats xmats zmats vmatc pmatc xmatc wvecd pvecd Ugrid PI Xgrid;
pause;
% load wmats_bet0.9.mat bet kap lam rho sig m k nu nx vmats pmats xmats zmats vmatc pmatc xmatc wvecd pvecd Ugrid PI Xgrid;
plotirf;
plotsim;

figure(1);
print -depsc2 ../Figures/Fig2.eps;
figure(2);
print -depsc2 ../Figures/Fig3a.eps;
figure(3);
print -depsc2 ../Figures/Fig3b.eps;
figure(4);
print -depsc2 ../Figures/Fig4.eps;
figure(5);
print -depsc2 ../Figures/Fig5.eps;