% Figure 5

load simpath uvec;
simT = size(uvec,1);
index = [500:550];
xinit = 0;
cumPI = cumsum(PI')';

% rand('state',1234);

psvec = zeros(simT,1);
xsvec = zeros(simT,1);
zsvec = ones(simT,1);
pcvec = zeros(simT,1);
xcvec = zeros(simT,1);
pdvec = zeros(simT,1);
xdvec = zeros(simT,1);

% ivec = zeros(simT,1);
% ivec(1) = ceil(nu/2); % midpoint

xsvec(1) = xinit;
xcvec(1) = xinit;
xdvec(1) = xinit;

for t=1:simT-1

%     uvec(t) = Ugrid(ivec(t));
    zsvec(t+1)  = intf2(zmats,uvec(t),xsvec(t),Ugrid,Xgrid);
    psvec(t+1) = intf2(pmats,uvec(t),xsvec(t),Ugrid,Xgrid);
    xsvec(t+1) = intf2(xmats,uvec(t),xsvec(t),Ugrid,Xgrid);
    pcvec(t+1) = intf2(pmatc,uvec(t),xcvec(t),Ugrid,Xgrid);
    xcvec(t+1) = intf2(xmatc,uvec(t),xcvec(t),Ugrid,Xgrid);
    pdvec(t+1) = intf1(pvecd,uvec(t),Ugrid);
    xdvec(t+1) = -kap/lam*pdvec(t+1);

%     % generate sequence of u by Markov chain
%     ivec(t+1) = sum(rand-cumPI(ivec(t),:)>=0);
%     ivec(t+1) = min(ivec(t+1)+1,nu);

end
    
figure;
subplot(311)
plot(index,zsvec(index),'LineWidth',2.0);
% xlabel('time');
ylabel('z');
xlim([index(1) index(end)]);
subplot(312)
hold on;
plot(index,xsvec(index),'b-','LineWidth',2.0);
plot(index,xcvec(index),'g--','LineWidth',2.0);
plot(index,xdvec(index),'r-.','LineWidth',2.0);
% legend('quasi-sustainable','timeless commitment','discreion','Location','NorthEast');
plot([index(1) index(end)],[0 0],'k-');
% xlabel('time');
ylabel('x');
xlim([index(1) index(end)]);
ylim([-5 5]);
subplot(313)
plot([index(1) index(end)],[0 0],'k-');
hold on;
plot(index,uvec(index),'m-','LineWidth',2.0);
xlabel('time');
ylabel('u');
xlim([index(1) index(end)]);
ylim([-1 1]);