% runpf.m

clear all;
addpath(strcat(pwd,'/../common/'));

parms;
kap1 = [0.005 0.01 0.05];
lam1 = [0.001 0.01 0.0625];
rho1 = [0.0 0.35];

for si=1:3

    for sj=1:3
    
        for sk=1:2

            kap = kap1(si);
            lam = lam1(sj);
            rho = rho1(sk);
            
            ansol;
            mainsp;
            
            str = ['save ./mat/wmats' num2str(si) num2str(sj) num2str(sk)];
            str = [str ' bet kap lam rho sig m k nu nx vmats pmats xmats zmats vmatc pmatc xmatc wvecd pvecd Ugrid PI Xgrid'];
            eval(str);
            
        end
        
    end
    
end