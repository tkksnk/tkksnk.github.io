% replicate Table 4 in the paper, given the policy functions of
% optimal quasi-sustainable policies

clear all;
addpath(strcat(pwd,'/../common/'));

parms;
kap1 = [0.005 0.01 0.05];
lam1 = [0.001 0.01 0.0625];
rho1 = [0.0 0.35];

psmat  = zeros(3,3,2);
pcmat  = zeros(3,3,2);
pdmat  = zeros(3,3,2);
xsmat  = zeros(3,3,2);
xcmat  = zeros(3,3,2);
xdmat  = zeros(3,3,2);
vs0mat = zeros(3,3,2);
vc0mat = zeros(3,3,2);
vd0mat = zeros(3,3,2);
vsmat  = zeros(3,3,2);
vcmat  = zeros(3,3,2);
vdmat  = zeros(3,3,2);

for si=1:3

    for sj=1:3
    
        for sk=1:2

            kap = kap1(si);
            lam = lam1(sj);
            rho = rho1(sk);
            
            disp([kap lam rho]);

            ansol;
            
            str = ['load ./mat/wmats' num2str(si) num2str(sj) num2str(sk)];
            eval(str);
            stochsim;

            psmat(si,sj,sk)  = varps0^.5*4;
            pcmat(si,sj,sk)  = varpc0^.5*4;
            pdmat(si,sj,sk)  = varpd0^.5*4;
            xsmat(si,sj,sk)  = varxs0^.5;
            xcmat(si,sj,sk)  = varxc0^.5;
            xdmat(si,sj,sk)  = varxd0^.5;
            vs0mat(si,sj,sk) = vs0;
            vc0mat(si,sj,sk) = vc0;
            vd0mat(si,sj,sk) = vd0;
            vsmat(si,sj,sk)  = vs;
            vcmat(si,sj,sk)  = vc;
            vdmat(si,sj,sk)  = vd;
            
        end
        
    end
    
end

xlswrite('../Tables/Table4.xls',psmat(:,:,1),'A2:C4')
xlswrite('../Tables/Table4.xls',pcmat(:,:,1),'A5:C7')
xlswrite('../Tables/Table4.xls',pdmat(:,:,1),'A8:C10')
xlswrite('../Tables/Table4.xls',psmat(:,:,2),'A12:C14')
xlswrite('../Tables/Table4.xls',pcmat(:,:,2),'A15:C17')
xlswrite('../Tables/Table4.xls',pdmat(:,:,2),'A18:C20')

xlswrite('../Tables/Table4.xls',xsmat(:,:,1),'E2:G4')
xlswrite('../Tables/Table4.xls',xcmat(:,:,1),'E5:G7')
xlswrite('../Tables/Table4.xls',xdmat(:,:,1),'E8:G10')
xlswrite('../Tables/Table4.xls',xsmat(:,:,2),'E12:G14')
xlswrite('../Tables/Table4.xls',xcmat(:,:,2),'E15:G17')
xlswrite('../Tables/Table4.xls',xdmat(:,:,2),'E18:G20')

xlswrite('../Tables/Table4.xls',vs0mat(:,:,1),'I2:K4')
xlswrite('../Tables/Table4.xls',vc0mat(:,:,1),'I5:K7')
xlswrite('../Tables/Table4.xls',vd0mat(:,:,1),'I8:K10')
xlswrite('../Tables/Table4.xls',vs0mat(:,:,2),'I12:K14')
xlswrite('../Tables/Table4.xls',vc0mat(:,:,2),'I15:K17')
xlswrite('../Tables/Table4.xls',vd0mat(:,:,2),'I18:K20')

xlswrite('../Tables/Table4.xls',vsmat(:,:,1),'M2:O4')
xlswrite('../Tables/Table4.xls',vcmat(:,:,1),'M5:O7')
xlswrite('../Tables/Table4.xls',vdmat(:,:,1),'M8:O10')
xlswrite('../Tables/Table4.xls',vsmat(:,:,2),'M12:O14')
xlswrite('../Tables/Table4.xls',vcmat(:,:,2),'M15:O17')
xlswrite('../Tables/Table4.xls',vdmat(:,:,2),'M18:O20')