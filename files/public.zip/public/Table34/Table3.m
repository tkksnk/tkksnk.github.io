% replicate Table 3 in the paper, given the policy functions of
% optimal quasi-sustainable policies

clear all;
addpath(strcat(pwd,'/../common/'));

parms;
kap1 = [0.005 0.01 0.05];
lam1 = [0.001 0.01 0.0625];
rho1 = [0.0 0.35];

Table3amat = zeros(3,3,2);
Table3bmat = zeros(3,3,2);
Table3cmat = zeros(3,3,2);

for si=1:3

    for sj=1:3
    
        for sk=1:2

            kap = kap1(si);
            lam = lam1(sj);
            rho = rho1(sk);
            
            disp([kap lam rho]);
            
            ansol;

            % Table 3.a. probability of binding constraints
            str = ['load ./mat/wmats' num2str(si) num2str(sj) num2str(sk)];
            eval(str);
            stochsim;
            Table3amat(si,sj,sk) = probz0*100;
            % Table 3.b. ratio of unconditional means of the output gap
            Table3bmat(si,sj,sk) = sig2xc^.5/sig2xd^.5;        
            % Table 3.c. lower bounds of discount factor (with unconditional means) 
            Table3cmat(si,sj,sk) = csolve(@diffwelf,0.99,[],1e-8,100,kap,lam,rho,sig);
            
        end
        
    end
    
end

xlswrite('../Tables/Table3.xls',Table3amat(:,:,1),'A2:C4')
xlswrite('../Tables/Table3.xls',Table3amat(:,:,2),'A6:C8')
xlswrite('../Tables/Table3.xls',Table3bmat(:,:,1),'A10:C12')
xlswrite('../Tables/Table3.xls',Table3bmat(:,:,2),'A14:C16')
xlswrite('../Tables/Table3.xls',Table3cmat(:,:,1),'A18:C20')
xlswrite('../Tables/Table3.xls',Table3cmat(:,:,2),'A22:C24')