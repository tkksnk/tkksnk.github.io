% Program for "Computing Optimal Sustainable Monetary Policy"
% This version: December 2014
% Takeki Sunakawa
%
% stochsim.m: do stochastic simulations


simN = 100;
simT = 1000;
burn = 0.05*simT;
index = burn+1:simT;
xinit = 0;
cumPI = cumsum(PI')';

rand('state',1234);

varps = zeros(simN,1); 
varxs = zeros(simN,1);
probz = zeros(simN,1);
varpc = zeros(simN,1); 
varxc = zeros(simN,1);
varpd = zeros(simN,1);
varxd = zeros(simN,1);

for i = 1:simN
    
    uvec = zeros(simT,1);
    psvec = zeros(simT,1);
    xsvec = zeros(simT,1);
    zsvec = ones(simT,1);
    pcvec = zeros(simT,1);
    xcvec = zeros(simT,1);
    pdvec = zeros(simT,1);
    xdvec = zeros(simT,1);

    ivec = zeros(simT,1);
    ivec(1) = ceil(nu/2); % midpoint

    xsvec(1) = xinit;
    xcvec(1) = xinit;
    xdvec(1) = xinit;

    for t = 1:simT-1

        uvec(t) = Ugrid(ivec(t));
        zsvec(t+1)  = intf2(zmats,uvec(t),xsvec(t),Ugrid,Xgrid);
        psvec(t+1) = intf2(pmats,uvec(t),xsvec(t),Ugrid,Xgrid);
        xsvec(t+1) = intf2(xmats,uvec(t),xsvec(t),Ugrid,Xgrid);
        pcvec(t+1) = intf2(pmatc,uvec(t),xcvec(t),Ugrid,Xgrid);
        xcvec(t+1) = intf2(xmatc,uvec(t),xcvec(t),Ugrid,Xgrid);
        pdvec(t+1) = intf1(pvecd,uvec(t),Ugrid);
        xdvec(t+1) = -kap/lam*pdvec(t+1);
        
        % generate sequence of u by Markov chain
        ivec(t+1) = sum(rand-cumPI(ivec(t),:)>=0);
        ivec(t+1) = min(ivec(t+1)+1,nu);
        
    end

    probz(i) = length(find(zsvec(index)<1))/length(index);
    varps(i) = var(psvec(index)); 
    varxs(i) = var(xsvec(index));
    varpc(i) = var(pcvec(index)); 
    varxc(i) = var(xcvec(index));
    varpd(i) = var(pdvec(index));
    varxd(i) = var(xdvec(index));

end

% save the result
probz0 = mean(probz);
varps0 = mean(varps);
varxs0 = mean(varxs);
varpc0 = mean(varpc);
varxc0 = mean(varxc);
varpd0 = mean(varpd);
varxd0 = mean(varxd);
% unconditional probabilities
vs0 = -(varps0 + lam*varxs0)/(1-bet);
vc0 = -(varpc0 + lam*varxc0)/(1-bet);
vd0 = -(varpd0 + lam*varxd0)/(1-bet);
% conditional probabilities
midu = ceil(nu/2);
midx = ceil(nx/2);
vs = vmats(midu,midx);
vc = vmatc(midu,midx);
vd = wvecd(midu);

% % relative errors from analytical solutions
% err_varxc = varxc0/sig2xc*100-100;
% err_varpc = varpc0/sig2pc*100-100;
% err_varxd = varxd0/sig2xd*100-100;
% err_varpd = varpd0/sig2pd*100-100;
% disp([err_varxc err_varpc err_varxd err_varpd]);