% replicate the stochastic simulation in Table 2 in the paper

% for bet = 0.9
clear all;
addpath(strcat(pwd,'/../common/'));
parms;
bet = 0.9;
ansol;
mainsp;
save wmats_bet0.9.mat bet kap lam rho sig m k invT Ugrid PI Xgrid nu nx r vmats pmats xmats zmats vmatc pmatc xmatc wvecd pvecd;
% load wmats_bet0.9.mat bet kap lam rho sig m k invT Ugrid PI Xgrid nu nx r vmats pmats xmats zmats vmatc pmatc xmatc wvecd pvecd;
stochsim;

simresultmat_bet09000 = [varps0^.5*4 varxs0^.5 vs0 vs probz0*100;
    varpc0^.5*4 varxc0^.5 vc0 vc NaN
    varpd0^.5*4 varxd0^.5 vd0 vd NaN];
save simresultmat_bet09000 simresultmat_bet09000;

residerr;

% for bet = 0.9913
clear all;
parms;
bet = 0.9913;
ansol;
mainsp;
save wmats_bet0.9913.mat bet kap lam rho sig m k invT Ugrid PI Xgrid nu nx r vmats pmats xmats zmats vmatc pmatc xmatc wvecd pvecd;
% load wmats_bet0.9913.mat bet kap lam rho sig m k invT Ugrid PI Xgrid nu nx r vmats pmats xmats zmats vmatc pmatc xmatc wvecd pvecd;
stochsim;

simresultmat_bet09913 = [varps0^.5*4 varxs0^.5 vs0 vs probz0*100;
    varpc0^.5*4 varxc0^.5 vc0 vc NaN
    varpd0^.5*4 varxd0^.5 vd0 vd NaN];
save simresultmat_bet09913 simresultmat_bet09913;

residerr;

load simresultmat_bet09000 simresultmat_bet09000;
load simresultmat_bet09913 simresultmat_bet09913;
disp(' ');
disp('    Simulation results with baseline parameters');
disp(simresultmat_bet09000);
disp(simresultmat_bet09913);

xlswrite('../Tables/Table2.xls',simresultmat_bet09000,'A2:E4')
xlswrite('../Tables/Table2.xls',simresultmat_bet09913,'A6:E8')